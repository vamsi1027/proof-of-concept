package com.datarewards.api.exceptions;

public class UnprocessableEntityException extends RuntimeException {

	private static final long serialVersionUID = 2704593895329765748L;

	private Object errorData;
	private String errorCode;

	public UnprocessableEntityException(String message) {
        super(message);
        
    }

	public UnprocessableEntityException(String message, Object errorData, String errorCode) {
		super(message);
		this.errorData = errorData;
		this.errorCode = errorCode;

	}

	public UnprocessableEntityException(String message, String errorCode) {
		super(message);
		this.errorCode = errorCode;

	}

	public Object getErrorData() {
		return errorData;
	}

	public void setErrorData(Object errorData) {
		this.errorData = errorData;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
}
