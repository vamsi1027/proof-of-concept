package com.datarewards.api.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@Table(name="reward")
public class Reward implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private long id;

    @Column(name = "iu_guid")
    private String iuGuid;

    @Column(name = "organization_id")
    private String organizationId;

    @Column(name = "campaign_id")
    private long campaignId;

    @Column(name = "claimed_time")
    private long claimedTime;

    @Column(name = "claimed_date")
    private Integer claimedDate;

    @Column(name = "ip_address")
    private String ipAddress;

    @Column(name = "browser_agents")
    private String browserAgents;

    //PENDING|PROCESSED|REJECTED
    @Column(name = "status")
    private String status;

    @Column(name = "reward_type")
    private String rewardType = "REGULAR";

    @Column(name = "allowance_utilized")
    private String allowanceUtilized;

    @Transient
    private Boolean redeemed;

}
