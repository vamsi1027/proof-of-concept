package com.datarewards.api.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

/**
 * @author Vamshi Gopari
 */
public class DateUtil {

    private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);
    Calendar calendar = GregorianCalendar.getInstance();
    String timeZone;

    public DateUtil(String timeZone) {
        this.timeZone = timeZone;
        calendar.clear();
        calendar.setTime(new Date());
        logger.info("Timezone: " + timeZone);
    }

    public static long getCurrentEpochTimeInSecs() {
        return System.currentTimeMillis()/1000;
    }

    private void setStartOfDayTime() {
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
    }

    private void setEndOfDayTime() {
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
    }

    private Date setTimeZoneAndGetDate() {
        calendar.setTimeZone(TimeZone.getTimeZone(timeZone));
        return calendar.getTime();
    }

    public String getCurrentDateInTimezone() {
        DateFormat df = new SimpleDateFormat(RewardConstants.CURRENT_DATE_FORMAT);
        return df.format(setTimeZoneAndGetDate());
    }

    public long getSearchStartTimeInSecsInTimezone() {
        setStartOfDayTime();
        return calendar.getTimeInMillis()/1000;
    }

    public long getSearchEndTimeInSecsInTimezone() {
        setEndOfDayTime();
        return calendar.getTimeInMillis()/1000;
    }

    public static String getCurrentDateAndTimeWithTimeZone(String timeZone) {
        SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("MM-dd-yyyy_HH.mm.ss a");
        dateTimeFormatter.setTimeZone(TimeZone.getTimeZone(timeZone));
        Date date = new Date();
        return dateTimeFormatter.format(date);
    }

    public static long getEndTimeEpochInSecsWithTimezone(String timeZone) {
        Calendar calendar = GregorianCalendar.getInstance();
        calendar.setTimeZone(TimeZone.getTimeZone(timeZone));
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.setTime(new Date());
        return calendar.getTimeInMillis()/1000;
    }


    public static String getCurrentDayWithTimezone(String timeZone) {
        String currentDate = "";
        SimpleDateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        gmtDateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
        currentDate = gmtDateFormat.format(new Date());
        return currentDate;
    }


    public static int getCurrentDayWithTimezoneInInt(String timeZone) {
        String currentDate = "";
        SimpleDateFormat gmtDateFormat = new SimpleDateFormat("yyyyMMdd");
        gmtDateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
        currentDate = gmtDateFormat.format(new Date());
        return Integer.parseInt(currentDate);
    }

    public static String getDateByTimeStampWithTimezone(long time, String timeZone) {
        String currentDate = "";
        Date date = new Date(time*1000);
        SimpleDateFormat gmtDateFormat = new SimpleDateFormat("MM-dd-yyyy");
        gmtDateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
        currentDate = gmtDateFormat.format(date);
        return currentDate;
    }

    public static String getFormattedDate(Date date, String format) {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return simpleDateFormat.format(date);
    }

    public static String getDateFromFormattedString(String date, String dateFormat) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
        try {
            return getFormattedDate(simpleDateFormat.parse(date), "yyyy-MM-dd");
        } catch (ParseException e) {
            logger.error(e.getMessage());
            return null;
        }
    }
}
