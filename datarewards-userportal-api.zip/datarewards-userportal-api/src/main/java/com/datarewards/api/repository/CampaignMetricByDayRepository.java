package com.datarewards.api.repository;

import com.datarewards.api.entity.CampaignMetricByDay;
import com.datarewards.api.entity.CampaignMetricByDayPK;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Optional;

@Repository
public interface CampaignMetricByDayRepository extends JpaRepository<CampaignMetricByDay, CampaignMetricByDayPK> {

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value = "INSERT INTO campaign_metric_by_day (campaign_id, date, total_claimed) " +
            "VALUES (:campaignId, :date, 1) " +
            "ON DUPLICATE KEY UPDATE total_claimed = total_claimed + 1;", nativeQuery = true)
    @Caching(evict = {
            @CacheEvict(value = "ucmbd1", key = "{ #campaignId, #date }"),
    })
    int updateCampaignMetricByDay(@Param("campaignId") String campaignId, @Param("date") String date);

    @Cacheable(cacheNames="ucmbd1", key = "{ #campaignId, #date }", unless = "#result == null")
    Optional<CampaignMetricByDay> findByPkCampaignIdAndPkDate(String campaignId, String date);
}
