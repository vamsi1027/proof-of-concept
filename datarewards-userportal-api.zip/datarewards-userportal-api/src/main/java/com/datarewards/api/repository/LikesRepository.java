package com.datarewards.api.repository;

import com.datarewards.api.entity.Likes;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Vamshi Gopari
 */
@Repository
public interface LikesRepository extends JpaRepository<Likes, Long> {

    @Cacheable(value = "ul1", key = "{ #iuGuid, #organizationId, #campaignId }", unless = "#result == null")
    Likes findByIuGuidAndOrganizationIdAndCampaignId(String iuGuid, String organizationId, String campaignId);

    @Caching(evict = {
            @CacheEvict(value = "ul1", key = "{ #iuGuid, #organizationId, #campaignId }"),
            @CacheEvict(value = "ual1", key = "{ #organizationId, #iuGuid }")
    })
    Integer deleteByIuGuidAndOrganizationIdAndCampaignId(String iuGuid, String organizationId, String campaignId);

    @Caching(evict = {
            @CacheEvict(value = "ul1", key = "{ #likes.iuGuid, #likes.organizationId, #likes.campaignId }"),
            @CacheEvict(value = "ual1", allEntries = true),
    })
    <S extends Likes> S save(S likes);

}
