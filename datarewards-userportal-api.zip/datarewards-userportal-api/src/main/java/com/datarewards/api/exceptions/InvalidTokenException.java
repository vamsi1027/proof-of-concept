package com.datarewards.api.exceptions;

public class InvalidTokenException extends Exception {

	private static final long serialVersionUID = 366574278867782739L;

    private String errorCode;

	public InvalidTokenException(String message) {
        super(message);
    }

    public InvalidTokenException(String message, String errorCode) {

	    super(message);
	    this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
