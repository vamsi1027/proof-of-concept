package com.datarewards.api.dto.common;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseDto<T> {

    private T data;

    private T errorData;

    private String status;

    private String message;

    private String error;

    private String errorCode;

    public ResponseDto() {}

    public ResponseDto(String error, String errorCode) {
        this.error = error;
        this.errorCode = errorCode;
    }

    public ResponseDto(String status, String error, String errorCode) {
        this.status = status;
        this.error = error;
        this.errorCode = errorCode;
    }

    public ResponseDto(String status, String error, String message, String errorCode) {
        this.status = status;
        this.error = error;
        this.message = message;
        this.errorCode = errorCode;
    }

    public ResponseDto(String status, String error, String message, T errorData, String errorCode) {
        this.status = status;
        this.error = error;
        this.message = message;
        this.errorData = errorData;
        this.errorCode = errorCode;
    }

    public ResponseDto(T data, String status, String message) {
        this.data = data;
        this.status = status;
        this.message = message;
    }
}
