package com.datarewards.api.service;

import com.datarewards.api.dto.common.ResponseDto;
import com.datarewards.api.dto.request.CampaignMetricsDTO;
import com.datarewards.api.dto.response.CampaignMetricsByDayResponse;
import com.datarewards.api.entity.Campaign;
import com.datarewards.api.entity.CampaignMetric;
import com.datarewards.api.entity.CampaignMetricByDay;
import com.datarewards.api.repository.CampaignMetricByDayRepository;
import com.datarewards.api.repository.CampaignMetricRepository;
import com.datarewards.api.repository.CampaignRepository;
import com.datarewards.api.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author Vamshi Gopari
 */
@Service
@Slf4j
public class CampaignMetricsService {

    @Autowired
    private CampaignMetricByDayRepository metricByDayRepository;

    @Autowired
    private CampaignMetricRepository metricRepository;

    @Autowired
    private CampaignRepository campaignRepository;

    public ResponseEntity<ResponseDto<CampaignMetricsByDayResponse>> updateCampaignMetricsByDay(CampaignMetricsDTO dto) {
        Optional<Campaign> campaign = campaignRepository.findById(Long.valueOf(dto.getCampaignId()));
        Optional<CampaignMetricByDay> campaignMetricByDay = metricByDayRepository.findByPkCampaignIdAndPkDate(dto.getCampaignId(), dto.getDate());
        ResponseDto<CampaignMetricsByDayResponse> response = new ResponseDto<>();
        CampaignMetricsByDayResponse metricsByDayResponse = new CampaignMetricsByDayResponse();
        if(campaign.isPresent() && campaignMetricByDay.isPresent()) {
            if (campaign.get().getDailyLimitSpecified().equalsIgnoreCase(Constants.GIGABYTE)) {
                campaign.get().setDailyLimit(String.valueOf(Long.parseLong(campaign.get().getDailyLimit()) * 1024));
            }
            if(Long.parseLong(campaign.get().getDailyLimit()) >
                    campaignMetricByDay.get().getTotalClaimed() * Long.parseLong(campaign.get().getDataPerUser())) {
                metricByDayRepository.updateCampaignMetricByDay(dto.getCampaignId(), dto.getDate());
            } else {
                response.setMessage("Total Claims per day Exceeded!");
                return ResponseEntity.ok().body(response);
            }
        } else if(!campaignMetricByDay.isPresent()) {
            metricByDayRepository.updateCampaignMetricByDay(dto.getCampaignId(), dto.getDate());
        }
        campaignMetricByDay = metricByDayRepository.findByPkCampaignIdAndPkDate(dto.getCampaignId(), dto.getDate());
        if(campaignMetricByDay.isPresent()) {
            metricsByDayResponse.setTotalClaimed(campaignMetricByDay.get().getTotalClaimed());
            metricsByDayResponse.setCampaignId(campaignMetricByDay.get().getPk().getCampaignId());
            metricsByDayResponse.setDate(campaignMetricByDay.get().getPk().getDate());
            response.setData(metricsByDayResponse);
            response.setStatus(HttpStatus.OK.toString());
            response.setMessage("Total Claims per day updated!");
        }
        return ResponseEntity.ok().body(response);
    }


    public ResponseEntity<ResponseDto<CampaignMetric>> updateTotalCampaignMetrics(CampaignMetricsDTO dto) {
        Optional<Campaign> campaign = campaignRepository.findById(Long.valueOf(dto.getCampaignId()));
        Optional<CampaignMetric> campaignMetric = metricRepository.findById(Long.valueOf(dto.getCampaignId()));
        ResponseDto<CampaignMetric> responseDto = new ResponseDto<>();
        if(campaign.isPresent() && campaignMetric.isPresent()) {
            if(campaign.get().getCampaignLimitSpecified().equalsIgnoreCase(Constants.GIGABYTE)) {
                campaign.get().setCampaignLimit(String.valueOf(Long.parseLong(campaign.get().getCampaignLimit()) * 1024));
            }
            if(Long.parseLong(campaign.get().getCampaignLimit()) > campaignMetric.get().getTotalClaimed() * Long.parseLong(campaign.get().getDataPerUser())) {
                metricRepository.updateCampaignMetric(dto.getCampaignId());
            } else {
                responseDto.setMessage("Claim Unsuccessful Total data Exceeded!");
                responseDto.setStatus(HttpStatus.BAD_REQUEST.toString());
                return ResponseEntity.ok().body(responseDto);
            }
        } else if(!campaignMetric.isPresent()){
            metricRepository.updateCampaignMetric(dto.getCampaignId());
        }
        campaignMetric = metricRepository.findById(Long.valueOf(dto.getCampaignId()));
        if(campaignMetric.isPresent()) {
            responseDto.setData(campaignMetric.get());
            responseDto.setStatus(HttpStatus.OK.toString());
            responseDto.setMessage("Successfully Claimed");
        }
        return ResponseEntity.ok().body(responseDto);
    }
}
