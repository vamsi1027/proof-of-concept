package com.datarewards.api.controllers;

import com.datarewards.api.dto.common.ResponseDto;
import com.datarewards.api.dto.request.LikesDTO;
import com.datarewards.api.entity.Likes;
import com.datarewards.api.service.ActionsService;
import com.datarewards.api.utils.RewardConstants;
import com.google.gson.Gson;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@Slf4j
@RequestMapping("/actions")
@Api(tags = "Actions")
public class ActionsController {

    @Autowired
    private ActionsService actionsService;

    @PostMapping(value="/like")
    public ResponseEntity<ResponseDto<Likes>> saveLikes(
            @RequestBody @Valid LikesDTO input) throws Exception {

        log.info(String.format("save likes: %s %s", input.getOrganizationId(), input.getIuGuid())
                + ", input= "+new Gson().toJson(input));

        return actionsService.saveLikes(input);
    }

    @PostMapping(value="/unlike")
    public ResponseEntity<ResponseDto<Likes>> updateLikes(
            @RequestBody @Valid LikesDTO input) {

        log.info(String.format("save unlikes: %s %s", input.getOrganizationId(), input.getIuGuid())
                + ", input= "+new Gson().toJson(input));

        ResponseDto<Likes> response = new ResponseDto();

        Likes unlikeResponse = actionsService.updateLikes(input);

        response.setStatus(RewardConstants.STATUS_SUCCESS);
        response.setMessage("Unliked successfully");
        response.setData(unlikeResponse);
        return ResponseEntity.ok().body(response);
    }
}
