package com.datarewards.api.service.adapter;

public interface CarrierRegistry {

    public AdapterInterface getServiceBean(String carrierId);
}
