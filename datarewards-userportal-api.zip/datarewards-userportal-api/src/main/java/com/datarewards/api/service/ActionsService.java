package com.datarewards.api.service;

import com.datarewards.api.dto.common.ResponseDto;
import com.datarewards.api.dto.request.LikesDTO;
import com.datarewards.api.entity.CampaignMetric;
import com.datarewards.api.entity.Likes;
import com.datarewards.api.exceptions.PreConditionFailedException;
import com.datarewards.api.repository.CampaignMetricRepository;
import com.datarewards.api.repository.CampaignRepository;
import com.datarewards.api.repository.LikesRepository;
import com.datarewards.api.repository.OrganizationUserRepository;
import com.datarewards.api.utils.DateUtil;
import com.datarewards.api.utils.ErrorCodeConstants;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Optional;

/**
 * @author Vamshi Gopari
 */
@Service
@Slf4j
public class ActionsService {

    @Autowired
    private CampaignRepository campaignRepository;

    @Autowired
    private LikesRepository likesRepository;

    ModelMapper mapper = new ModelMapper();

    @Autowired
    private CampaignMetricRepository campaignMetricRepository;

    @Autowired
    private OrganizationUserRepository organizationUserRepository;

    public ResponseEntity<ResponseDto<Likes>> saveLikes(LikesDTO input) {
        String campaignId = input.getCampaignId();

        Likes isAlreadyLiked = likesRepository.findByIuGuidAndOrganizationIdAndCampaignId(input.getIuGuid(), input.getOrganizationId(), campaignId);
        if (isAlreadyLiked != null) {
            throw new PreConditionFailedException("User has already liked!");
        }

        Likes entity = new Likes();
        entity.setIuGuid(input.getIuGuid());
        entity.setOrganizationId(input.getOrganizationId());
        entity.setCampaignId(input.getCampaignId());
        entity.setDateTime(DateUtil.getCurrentEpochTimeInSecs());
        entity.setLiked(Boolean.TRUE);

        entity = likesRepository.save(entity);

        organizationUserRepository.updateOrganizationUserLikes(input.getIuGuid());
        campaignMetricRepository.updateCampaignMetricLikes(Long.valueOf(campaignId));
        Optional<CampaignMetric> campaignMetric = campaignMetricRepository.findById(Long.valueOf(campaignId));
        if(campaignMetric.isPresent()) {
            entity.setTotalLikes(campaignMetric.get().getTotalLikes());
        }

        Likes likesResponse = mapper.map(entity, Likes.class);
        ResponseDto<Likes>  responseDto = new ResponseDto<>();
        responseDto.setData(likesResponse);
        responseDto.setMessage("Liked Successfully!");
        return ResponseEntity.ok().body(responseDto);
    }

    @Transactional
    public Likes updateLikes(LikesDTO input) {
        String campaignId = input.getCampaignId();

        Likes entity = likesRepository.findByIuGuidAndOrganizationIdAndCampaignId(input.getIuGuid(), input.getOrganizationId(), campaignId);
        if (entity == null) {
            throw new PreConditionFailedException("User has not liked yet", ErrorCodeConstants.USER_LIKED_UNLIKED);
        }

        likesRepository.deleteByIuGuidAndOrganizationIdAndCampaignId(input.getIuGuid(), input.getOrganizationId(), campaignId);

        organizationUserRepository.updateOrganizationUserUnLikes(input.getIuGuid());
        campaignMetricRepository.updateCampaignMetricUnLikes(Long.valueOf(campaignId));
        Optional<CampaignMetric> campaignMetric = campaignMetricRepository.findById(Long.valueOf(campaignId));
        if(campaignMetric.isPresent()) {
            entity.setLiked(Boolean.FALSE);
            entity.setTotalLikes(campaignMetric.get().getTotalLikes());
        }
        return mapper.map(entity, Likes.class);
    }

}
