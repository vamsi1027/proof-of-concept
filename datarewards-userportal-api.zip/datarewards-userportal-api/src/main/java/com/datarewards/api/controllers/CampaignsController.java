package com.datarewards.api.controllers;

import com.datarewards.api.dto.common.ResponseDto;
import com.datarewards.api.dto.response.AdListResponse;
import com.datarewards.api.entity.Organization;
import com.datarewards.api.repository.OrganizationRepository;
import com.datarewards.api.service.adapter.CarrierRegistry;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author Vamshi Gopari
 */
@Slf4j
@RestController
@RequestMapping("/campaigns")
@Api(tags = "Campaigns")
public class CampaignsController {

    @Autowired
    private CarrierRegistry carrierRegistry;

    @Autowired
    private OrganizationRepository organizationRepository;

    /**
     * Fetching all the eligible campaigns from adlist table
     */
    @GetMapping(value = "/ads/{organizationId}/{iuGuid}")
    public ResponseEntity<ResponseDto<List<AdListResponse>>> getActiveCampaigns(@PathVariable String organizationId, @PathVariable String iuGuid) {
        Organization org = organizationRepository.findById(organizationId);
        return carrierRegistry.getServiceBean(org.getName()).getEligibleCampaigns(organizationId, iuGuid);
    }
}
