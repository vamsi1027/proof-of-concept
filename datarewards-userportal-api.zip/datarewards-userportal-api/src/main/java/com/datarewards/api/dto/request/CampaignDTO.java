package com.datarewards.api.dto.request;

import com.datarewards.api.entity.AdList;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

import static com.datarewards.api.utils.RewardsMessageIds.*;

@Getter
@Setter
public class CampaignDTO {

    @NotBlank(message = ID_REQUIRED)
    private String id;

    @NotBlank(message = STATUS_REQUIRED)
    private String status;

    @NotBlank(message = NAME_REQUIRED)
    private String name;

    @NotBlank(message = ORGANIZATION_ID_REQUIRED)
    private String organizationId;

    @NotBlank(message = AD_JSON_REQUIRED)
    @Length(max=1000, message = AD_JSON_MAX_LENGTH)
    private AdList adJson;

    private String dailyLimitSpecified;
    private String dailyLimit;
    private String campaignLimitSpecified;
    private String campaignLimit;
    private String dataPerUserSpecified;
    private String dataPerUser;
    private String campaignTime;

    @NotNull(message = START_DATE_IS_REQUIRED)
    private Date startDate;

    @NotNull(message = END_DATE_IS_REQUIRED)
    private Date endDate;

    private Boolean active;
    private Integer appDownloadAllowanceInMB;
    private Integer rewardInMB;
    private String adType;
    private String agency;
    private String category;
    private String advertiser;
    private String campaignObjective;
    private String reportingEmail;
    private String organizationName;
    private String videoUrl;
    private String imageUrl;

}
