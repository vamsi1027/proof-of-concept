package com.datarewards.api.controllers;

import com.datarewards.api.dto.common.ResponseDto;
import com.datarewards.api.dto.request.CampaignMetricsDTO;
import com.datarewards.api.dto.response.CampaignMetricsByDayResponse;
import com.datarewards.api.entity.CampaignMetric;
import com.datarewards.api.service.CampaignMetricsService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Vamshi Gopari
 */
@RestController
@RequestMapping("/metrics")
@Api(tags = "Metrics")
public class CampaignMetricsController {

    @Autowired
    private CampaignMetricsService campaignMetricsService;

    @PostMapping("/day")
    public ResponseEntity<ResponseDto<CampaignMetricsByDayResponse>> updateCampaignMetricsByDay(@RequestBody CampaignMetricsDTO dto) {
        return campaignMetricsService.updateCampaignMetricsByDay(dto);
    }

    @PostMapping("/total")
    public ResponseEntity<ResponseDto<CampaignMetric>> updateTotalCampaignMetrics(@RequestBody CampaignMetricsDTO dto) {
        return campaignMetricsService.updateTotalCampaignMetrics(dto);
    }

}
