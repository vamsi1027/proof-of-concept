package com.datarewards.api.repository;

import com.datarewards.api.entity.OrganizationUser;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Optional;

@Repository
public interface OrganizationUserRepository extends JpaRepository<OrganizationUser, Integer> {

    @Cacheable(value = "uou1", key = "#iuGuid", unless = "#result == null")
    OrganizationUser findByIuGuid(String iuGuid);

    @Cacheable(value = "uou2", key = "#phoneNumber", unless = "#result == null")
    Optional<OrganizationUser> findByPhoneNumber(String phoneNumber);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE organization_user SET total_likes = total_likes + 1 " +
            "WHERE iu_guid = :iuGuid", nativeQuery = true)
    @CacheEvict(value = "uou1", key = "#iuGuid")
    int updateOrganizationUserLikes(@Param("iuGuid") String iuGuid);


    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE organization_user SET total_likes = total_likes - 1 " +
            "WHERE iu_guid = :iuGuid", nativeQuery = true)
    @CacheEvict(value = "uou1", key = "#iuGuid")
    int updateOrganizationUserUnLikes(@Param("iuGuid") String iuGuid);

    @Caching(evict = {
            @CacheEvict(value = "uou1", key = "#organizationUser.iuGuid"),
            @CacheEvict(value = "uou2", key = "#organizationUser.phoneNumber")
    })
    @Override
    <S extends OrganizationUser> S save(S organizationUser);

}
