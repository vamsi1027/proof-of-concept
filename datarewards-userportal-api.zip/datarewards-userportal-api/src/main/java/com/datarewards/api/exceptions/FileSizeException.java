package com.datarewards.api.exceptions;

/**
 * @author Vamshi Gopari
 */
public class FileSizeException extends RuntimeException {

    private String errorCode;

    public FileSizeException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}