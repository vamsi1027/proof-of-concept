package com.datarewards.api.service;

import com.datarewards.api.dto.request.CampaignDTO;
import com.datarewards.api.entity.Campaign;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * @author Vamshi Gopari
 */
@Service
public class DtoMapperService {

    @Autowired
    private ModelMapper modelMapper;

    public CampaignDTO convertToDTO(Campaign input) {
        return modelMapper.map(input, CampaignDTO.class);
    }

    public Campaign convertToEntity(CampaignDTO input) {
        return modelMapper.map(input, Campaign.class);
    }

}
