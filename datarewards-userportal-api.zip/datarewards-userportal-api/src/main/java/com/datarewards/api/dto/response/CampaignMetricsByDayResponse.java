package com.datarewards.api.dto.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CampaignMetricsByDayResponse {

    private String campaignId;
    private String date;
    private Long totalClaimed;
    private Long projection;

    public CampaignMetricsByDayResponse(String date, Long totalClaimed) {
        this.date = date;
        this.totalClaimed = totalClaimed;
    }
}
