package com.datarewards.api.service.adapter;

import com.datarewards.api.dto.common.ResponseDto;
import com.datarewards.api.dto.request.RewardsDTO;
import com.datarewards.api.dto.response.AdListResponse;
import com.datarewards.api.entity.Reward;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface AdapterInterface {

    ResponseEntity<ResponseDto<List<AdListResponse>>> getEligibleCampaigns(String organizationId, String iuGuid);
    ResponseEntity<ResponseDto<Reward>> rewardRedemption(RewardsDTO rewardsDTO);
}
