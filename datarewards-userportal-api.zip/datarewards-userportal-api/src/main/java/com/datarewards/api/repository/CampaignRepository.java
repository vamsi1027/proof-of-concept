package com.datarewards.api.repository;

import com.datarewards.api.entity.Campaign;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CampaignRepository extends JpaRepository<Campaign, Long> {

    @Cacheable(value = "uc1", key = "#campaignId", unless = "#result == null")
    Optional<Campaign> findById(Long campaignId);

    @Cacheable(value = "uc2", key = "{ #organizationId, #status }", unless = "#result == null")
    List<Campaign> findByOrganizationIdAndStatusOrderByIdDesc(String organizationId, String status);

    @Cacheable(value = "uc3", key = "#organizationId", unless = "#result == null")
    List<Campaign> findByOrganizationIdOrderByIdDesc(String organizationId);

    @Cacheable(value = "uc4", key = "#name", unless = "#result == null")
    Campaign findByName(String name);

    @Cacheable(value = "uc5", key = "#status", unless = "#result == null")
    List<Campaign> findByStatus(String status);

    @Caching(evict = {
            @CacheEvict(value = "uc1", key = "#campaign.campaignId"),
            @CacheEvict(value = "uc2", key = "{ #campaign.organizationId, #campaign.status }"),
            @CacheEvict(value = "uc3", key = "#campaign.organizationId"),
            @CacheEvict(value = "uc4", key = "#campaign.name"),
            @CacheEvict(value = "uc5", key = "#campaign.status")
    })
    @Override
    <S extends Campaign> S save(S campaign);
}
