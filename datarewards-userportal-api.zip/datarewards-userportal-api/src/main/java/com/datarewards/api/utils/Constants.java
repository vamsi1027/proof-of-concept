package com.datarewards.api.utils;

/**
 * @author Vamshi Gopari
 */
public class Constants {

    public static final String FETCH_CAMPAIGN_SUCCESS = "Campaigns fetched successfully";
    public static final String NO_CAMPAIGNS_FOUND = "No Campaigns found";
    public static final String GIGABYTE = "GB";

    private Constants() {
    }
}
