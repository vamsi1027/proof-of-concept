package com.datarewards.api.controllers;

import com.datarewards.api.dto.common.ResponseDto;
import com.datarewards.api.dto.request.RewardsDTO;
import com.datarewards.api.entity.Organization;
import com.datarewards.api.entity.Reward;
import com.datarewards.api.repository.OrganizationRepository;
import com.datarewards.api.service.adapter.CarrierRegistry;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author Vamshi Gopari
 */
@RestController
@RequestMapping("/rewards")
@Api(tags = "Rewards")
public class RewardsController {

    @Autowired
    private CarrierRegistry carrierRegistry;

    @Autowired
    private OrganizationRepository organizationRepository;

    @PostMapping("/redeem")
    public ResponseEntity<ResponseDto<Reward>> redeemReward(@RequestBody @Valid RewardsDTO rewardsDTO) {
        Organization org = organizationRepository.findById(rewardsDTO.getOrganizationId());
        return carrierRegistry.getServiceBean(org.getName()).rewardRedemption(rewardsDTO);
    }

}
