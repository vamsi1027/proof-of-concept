package com.datarewards.api.service;

import com.datarewards.api.entity.OrganizationUser;
import com.datarewards.api.repository.OrganizationUserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author Vamshi Gopari
 */
@Service
@Slf4j
public class OrganizationUserService {

    @Autowired
    private OrganizationUserRepository organizationUserRepository;

    /**
     * create a organization user if doesn;t exist
     * @param userName
     * @param phoneNumber
     * @param organizationId
     * @return
     */
    public OrganizationUser createUser(String userName, String phoneNumber, String organizationId) {
        Optional<OrganizationUser> organizationUser = organizationUserRepository.findByPhoneNumber(phoneNumber);
        if(organizationUser.isPresent()) {
            return organizationUser.get();
        } else {
            OrganizationUser user = new OrganizationUser();
            user.setPhoneNumber(phoneNumber);
            user.setUserName(userName);
            user.setOrganizationId(organizationId);
            return organizationUserRepository.save(user);
        }
    }
}
