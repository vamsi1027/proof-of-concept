package com.datarewards.api.utils;

public class RewardsMessageIds {

    public static final String USER_IDENTIFIER_REQUIRED = "userIdentifier is required field";
    public static final String CAMPAIGN_ID_REQUIRED = "campaignId is required field";
    public static final String STATUS_IS_REQUIRED = "status is required field";
    public static final String CAMPAIGN_IDS_REQUIRED = "campaignIds is required field";
    public static final String NAME_REQUIRED = "name is required field";
    public static final String ID_REQUIRED = "id is required field";
    public static final String STATUS_REQUIRED = "status is required field";
    public static final String ORGANIZATION_ID_REQUIRED = "organizationId is required field";
    public static final String AD_JSON_REQUIRED = "adJson is required field";
    public static final String AD_JSON_MAX_LENGTH = "maximum length of adJson should be 1000";
    public static final String START_DATE_IS_REQUIRED = "startDate is required field";
    public static final String END_DATE_IS_REQUIRED = "endDate is required field";

    public static final String USER_OPTIN_FALSE = "user.optin.false";
    public static final String USER_NOT_FOUND = "user.not.found";
    public static final String USER_LOGGED_IN = "user.loggedin.success";

    public static final String OPTIN_UPDATE_FAILED = "user.optin.failed";
    public static final String OPTIN_UPDATE_SUCCESS = "user.optin.success";

    public static final String DAILY_LIMIT_REACHED = "daily.limit.reached";
    public static final String INVALID_TOKEN_INPUTS = "token.invalid";
    public static final String INVALID_EXPIRED_TOKEN = "token.expired";
    public static final String ADS_NOT_FOUND = "ads.not.found";

    public static final String CAMPAIGN_NOT_FOUND = "campaign.not.found";
    public static final String ORGANIZATION_NOT_FOUND = "organization.not.found";
    public static final String ORGANIZATION_USER_NOT_FOUND = "organization.user.not.found";
    public static final String REWARD_NOT_FOUND = "reward.not.found";
    public static final String REWARD_CLAIMED = "reward.claimed";
    public static final String REWARDED_ALLOWANCE = "rewarded.allowance";
    public static final String REWARD_PROCESSED_1 = "reward.processed.1";
    public static final String REWARD_PROCESSED_2 = "reward.processed.2";
    public static final String REWARD_STATUS_UPDATE_ERROR="reward.status.update.error";
    public static final String REWARD_STATUS_UPDATE_SUCCESS="reward.status.update.status";
    public static final String REWARD_LIST_SUCCESS = "reward.list.success";

    public static final String INVALID_ORGID = "invalid.orgid";
    public static final String INVALID_ORGNAME = "invalid.orgname";
    public static final String INVALID_IUGUID = "invalid.iuguid";
    public static final String INVALID_PAGE_PARAMS = "invalid.page.params";
    public static final String INVALID_ORGID_IUGUID = "invalid.orgid.iuguid";
    public static final String INVALID_RSA_KEY = "invalid.rsa.key";

    public static final String INVALID_COLOR_SCHEME = "org.color.invalid";
    public static final String ORG_COLOR_UPDATE_FAILED = "org.color.failed";
    public static final String ORG_COLOR_UPDATE_SUCCESS = "org.color.success";
    public static final String YOU_ARE_NOT_ALLOWED_TO_CLAIM = "you.are.not.eligible.to.claim";
    public static final String YOU_ARE_BLOCKED_TILL = "you.are.blocked.till";
    public static final String YOU_ARE_ALREADY_CLAIMED = "you.are.already.claimed";
    public static final String SUCCESS = "success";
}
