package com.datarewards.api.dto.request;

import lombok.Data;

@Data
public class LikesDTO {

    private String campaignId;
    private String organizationId;
    private String iuGuid;

}
