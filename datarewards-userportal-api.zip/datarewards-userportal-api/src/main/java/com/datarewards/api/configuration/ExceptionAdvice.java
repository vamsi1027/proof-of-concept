package com.datarewards.api.configuration;

import com.datarewards.api.dto.common.ResponseDto;
import com.datarewards.api.exceptions.*;
import com.datarewards.api.utils.ErrorCodeConstants;
import com.google.gson.Gson;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import static com.datarewards.api.utils.RewardConstants.*;
import static com.datarewards.api.utils.RewardsMessageIds.DAILY_LIMIT_REACHED;
import static com.datarewards.api.utils.RewardsMessageIds.USER_OPTIN_FALSE;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@ControllerAdvice
public class ExceptionAdvice {

    private Log log = LogFactory.getLog(ExceptionAdvice.class);

    @ExceptionHandler({InvalidTokenException.class})
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ResponseBody
    public ResponseDto<Object> processUnAuthorizedError(InvalidTokenException ex) {
        return new ResponseDto<>(STATUS_FAILURE, ex.getMessage(), ex.getErrorCode());
    }

    @ExceptionHandler({MethodArgumentNotValidException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseDto<Object> processMethodArgumentNotValidError(MethodArgumentNotValidException ex) {

        String message;

        if(ex.getBindingResult().getAllErrors().size() > 1) {

            message = ex.getBindingResult().getAllErrors().stream()
                    .map((e) -> e.getDefaultMessage() + ", ").collect(Collectors.joining());
        } else {

            message = ex.getBindingResult().getAllErrors().stream()
                    .map((e) -> e.getDefaultMessage()).collect(Collectors.joining());
        }

        return new ResponseDto<>(STATUS_FAILURE, message, ErrorCodeConstants.INVALID_INPUT);
    }

    @ExceptionHandler({HttpMessageNotReadableException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseDto<Object> processMethodMessageNotReadable(HttpMessageNotReadableException ex) {

        return new ResponseDto<>(STATUS_FAILURE, ex.getMessage(), ex.getErrorCode());
    }

    @ExceptionHandler({UnprocessableEntityException.class})
    @ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
    @ResponseBody
    public ResponseDto<Object> processUnProcessableEntityError(UnprocessableEntityException ex) {

        if (ex.getMessage().equalsIgnoreCase(USER_OPTIN_FALSE)) {
            return new ResponseDto<>(STATUS_FAILURE, FAILED, USER_OPTIN_FALSE, ex.getErrorCode());
        }

        if (ex.getMessage().equalsIgnoreCase(DAILY_LIMIT_REACHED)) {
            return new ResponseDto<>(STATUS_FAILURE, FAILED, DAILY_LIMIT_REACHED,
                    new Gson().fromJson(ex.getErrorData().toString(), Object.class), ex.getErrorCode());
        }

        return new ResponseDto<>(STATUS_FAILURE, ex.getMessage(), ex.getErrorCode());
    }

    @ExceptionHandler({PreConditionFailedException.class})
    @ResponseStatus(HttpStatus.PRECONDITION_FAILED)
    @ResponseBody
    public ResponseDto<Object> processPreConditionFailedException(PreConditionFailedException ex) {
        return new ResponseDto<>(STATUS_FAILURE, ex.getMessage(), ex.getErrorCode());
    }

    @ExceptionHandler({ResourceNotFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ResponseBody
    public ResponseDto<Object> processResourceNotFoundException(ResourceNotFoundException ex) {
        return new ResponseDto<>(STATUS_FAILURE, ex.getMessage(), ex.getErrorCode());
    }

    @ExceptionHandler({NoSuchElementException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ResponseBody
    public ResponseDto<Object> processResourceNotFoundError(NoSuchElementException ex) {
        return new ResponseDto<>(STATUS_FAILURE, ex.getMessage(), ErrorCodeConstants.INVALID_INPUT);
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(INTERNAL_SERVER_ERROR)
    @ResponseBody
    public ResponseDto<Object> processAllError(Exception ex) {
        ex.printStackTrace();
        log.error("Internal Server Error == "+ex.getMessage());
        return new ResponseDto<>(STATUS_FAILURE, INTERNAL_SERVER_ERROR.getReasonPhrase(), ex.getMessage(), ErrorCodeConstants.INTERNAL_SERVER_ERROR);
    }

}
