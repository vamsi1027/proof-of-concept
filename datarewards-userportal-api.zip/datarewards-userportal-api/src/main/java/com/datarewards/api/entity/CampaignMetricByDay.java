package com.datarewards.api.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "campaign_metric_by_day")
public class CampaignMetricByDay {

    @EmbeddedId
    private CampaignMetricByDayPK pk;

    @Column(name = "total_claimed")
    private Long totalClaimed;
}
