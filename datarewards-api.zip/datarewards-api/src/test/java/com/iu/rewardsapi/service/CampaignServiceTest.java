package com.iu.rewardsapi.service;

import com.iu.rewardsapi.entity.Campaign;
import com.iu.rewardsapi.repository.CampaignRepository;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class CampaignServiceTest {

    @Mock
    CampaignRepository campaignRepository;

    private MockMvc mockMvc;

    @InjectMocks
    CampaignService campaignService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(campaignService).build();
    }

    @Test
    void testCampaignsByOrgId() {
        List<Campaign> campaigns = new ArrayList<Campaign>();
        Campaign campaign1 = new Campaign(912023123324234L, "MockTestCampaign", "5a294f81993c8f1570c2550d", "waiting for approval",
                "{   \"id\" : 912023123,   \"organizationId\" : \"5a294f81993c8f1570c2550d\",   \"status\" : \"waiting for approval\",   " +
                        "\"videoURL\" : \"https://digitalreef-datarewards-test.s3.amazonaws.com/IU/481/videos/Campaign_04-06-2022_05.51.58 AM.mp4\",   " +
                        "\"imageURL\" : \"https://digitalreef-datarewards-test.s3.amazonaws.com/IU/481/thumbnails/Campaign_04-06-2022_05.51.58 AM.png\",  " +
                        " \"adType\" : \"video\",   \"claimed\" : false,   \"expiresAt\" : 1649217600000,   \"confirmationInterval\" : null,   " +
                        "\"confirmationType\" : null,   \"rewardDisplay\" : null,   \"dataPerUserSpecified\" : \"MB\",   \"dataPerUser\" : \"10\"  }",
                "MB", "30", "", new Date(), new Date(), false,  "video", "agency1",
                "category`", "advertiser1", "campaignObj1", "test@email.com");
        campaigns.add(campaign1);
        when(campaignRepository.findByOrganizationIdOrderByIdDesc("5a294f81993c8f1570c2550d")).thenReturn(campaigns);
        List<Campaign> empList = campaignService.getAllCampaigns("all", "5a294f81993c8f1570c2550d").getBody().getData();
        assertEquals(1, empList.size());
        verify(campaignRepository, times(1)).findByOrganizationIdOrderByIdDesc("5a294f81993c8f1570c2550d");

    }
}