package com.iu.rewardsapi.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import java.io.Serializable;

@Data
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class CampaignMetricByDayPK implements Serializable {

    @GeneratedValue
    @Column(name = "campaign_id")
    private String campaignId;

    @GeneratedValue
    @Column(name = "date")
    private String date;
}
