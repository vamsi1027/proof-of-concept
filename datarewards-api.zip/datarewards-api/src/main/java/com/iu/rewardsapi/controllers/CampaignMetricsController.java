package com.iu.rewardsapi.controllers;

import com.iu.rewardsapi.dto.common.ResponseDto;
import com.iu.rewardsapi.dto.request.CampaignMetricsDTO;
import com.iu.rewardsapi.dto.response.CampaignMetricsByDayResponse;
import com.iu.rewardsapi.entity.CampaignMetric;
import com.iu.rewardsapi.service.CampaignMetricsService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @author Vamshi Gopari
 */
@RestController
@RequestMapping("/metrics")
@Api(tags = "Metrics")
public class CampaignMetricsController {

    @Autowired
    private CampaignMetricsService campaignMetricsService;

    @PostMapping("/day")
    public ResponseEntity<ResponseDto<CampaignMetricsByDayResponse>> updateCampaignMetricsByDay(@RequestBody CampaignMetricsDTO dto) {
        return campaignMetricsService.updateCampaignMetricsByDay(dto);
    }

    @PostMapping("/total")
    public ResponseEntity<ResponseDto<CampaignMetric>> updateTotalCampaignMetrics(@RequestBody CampaignMetricsDTO dto) {
        return campaignMetricsService.updateTotalCampaignMetrics(dto);
    }

}
