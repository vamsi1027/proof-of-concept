package com.iu.rewardsapi.service;

import com.iu.rewardsapi.dto.common.ResponseDto;
import com.iu.rewardsapi.dto.response.AnalyticsResponse;
import com.iu.rewardsapi.dto.response.TotalDataConsumption;
import com.iu.rewardsapi.utils.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * @author Vamshi Gopari
 */
@Service
@Slf4j
public class AnalyticsService {

    @Autowired CampaignMetricsService campaignMetricsService;

    public ResponseEntity<ResponseDto<AnalyticsResponse>> getAnalytics(String campaignId) {
        log.info("In Analytics Service!");
        ResponseDto<AnalyticsResponse> responseDto = new ResponseDto<>();
        AnalyticsResponse analyticsResponse = new AnalyticsResponse();
        TotalDataConsumption totalDataConsumption = campaignMetricsService.getTotalDataConsumption(campaignId);
        if(totalDataConsumption != null) {
            analyticsResponse.setTotalDataConsumption(totalDataConsumption);
            responseDto.setData(analyticsResponse);
            responseDto.setMessage(Constants.ANALYTICS_FETCH_SUCCESS);
        } else {
            responseDto.setMessage(Constants.NO_ANALYTICS);
        }
        return ResponseEntity.ok().body(responseDto);
    }
}