package com.iu.rewardsapi.utils;

import java.util.List;
import java.util.Optional;

/**
 * @author Vamshi Gopari
 */
public class CommonUtility {

    public static String checkNull(List<String> value) {
        if (null != value) {
            String param = Optional.ofNullable(value.get(0)).orElse("");
            return param.trim();
        } else {
            return "";
        }
    }

}
