package com.iu.rewardsapi.entity;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Data
@Entity
@Table(name="organization_user")
public class OrganizationUser implements Serializable {

    @Id
    @Column(name = "iu_guid")
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    private String iuGuid;

    @Column(name = "organization_id")
    private String organizationId = "NA";

    @Column(name = "organization_user_id")
    private String organizationUserId = "NA";

    @Column(name = "user_name")
    private String userName = "NA";

    @Column(name = "phone_number")
    private String phoneNumber;

    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    @Column(name = "created_at")
    private Date createdAt;

    @Column(name = "opt_in")
    private boolean optIn = false;

    @Column(name = "daily_limit_reached")
    private boolean dailyLimitReached = false;

    @Column(name = "daily_limit_reset_epoch")
    private long dailyLimitResetEpoch = 0;

    @Column(name = "todays_date")
    private String todaysDate;

    @Column(name = "last_app_download_allowance_date")
    private int lastAppDownloadAllowanceDate = 0;

    @Column(name = "ada_blocked")
    private boolean adaBlocked = false;

    @Column(name = "ada_blocked_till")
    private int adaBlockedTill = 0;

    @Column(name = "ada_blocked_reason")
    private String adaBlockedReason = "NA";

    @Column(name = "todays_claims")
    private int todaysClaims = 0;

    @Column(name = "total_claimed_in_mb")
    private int totalClaimedInMB = 0;

    @Column(name = "total_likes")
    private long totalLikes = 0;

    @Column(name = "ada_continuous_claims_count")
    private int adaContinuousClaimsCount = 0;

}
