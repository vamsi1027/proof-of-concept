package com.iu.rewardsapi.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @author Vamshi Gopari
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="campaign")
public class Campaign implements Serializable {


    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @Column(columnDefinition = "varchar(255) not null default 'NA'")
    private String name = "NA";

    @Column(columnDefinition = "varchar(255) not null default 'NA'")
    private String organizationId = "NA";

    @Column(columnDefinition = "varchar(45) not null")
    private String status;

    @Column(columnDefinition = "varchar(1000)")
    private String adJson = "{}";

    @Column(columnDefinition = "varchar(10) null")
    private String dailyLimitSpecified;

    @Column(columnDefinition = "varchar(100) null")
    private String dailyLimit;

    @Column(columnDefinition = "varchar(10) null")
    private String campaignLimitSpecified;

    @Column(columnDefinition = "varchar(100)")
    private String campaignLimit;

    @Column(columnDefinition = "varchar(10) null")
    private String dataPerUserSpecified;

    @Column(columnDefinition = "varchar(100)")
    private String dataPerUser;

    @Column(columnDefinition = "varchar(100)")
    private String campaignTime;

    @Column(columnDefinition = "datetime")
    @JsonFormat(pattern="MM/dd/yyyy")
    private Date startDate;

    @Column(columnDefinition = "datetime")
    @JsonFormat(pattern="MM/dd/yyyy")
    private Date endDate;

    @Column(columnDefinition = "boolean null default false")
    private boolean active;

    @Column(name="reward_in_mb", columnDefinition = "int null default 0")
    private int rewardInMB;

    //VIDEO, BANNER, SURVEY, INSTALL_APP;
    @Column(columnDefinition = "varchar(255) null default 'VIDEO'")
    private String adType = "VIDEO";

    @Column(name="app_download_allowance_in_mb", columnDefinition = "int null default 0")
    private int appDownloadAllowanceInMB = 0;

    @Column(name="agency")
    private String agency;

    @Column(name = "category")
    private String category;

    @Column(name = "advertiser")
    private String advertiser;

    @Column(name = "campaign_objective")
    private String campaignObjective;

    @Column(name = "reporting_email")
    private String reportingEmail;

    public Campaign(Long id, String name, String organizationId, String status, String adJson,
                    String campaignLimitSpecified, String campaignLimit,String campaignTime, Date startDate,
                    Date endDate, boolean active, String adType, String agency, String category,
                    String advertiser, String campaignObjective, String reportingEmail) {
        this.id = id;
        this.name = name;
        this.organizationId = organizationId;
        this.status = status;
        this.adJson = adJson;
        this.campaignLimitSpecified = campaignLimitSpecified;
        this.campaignLimit = campaignLimit;
        this.campaignTime = campaignTime;
        this.startDate = startDate;
        this.endDate = endDate;
        this.active = active;
        this.adType = adType;
        this.agency = agency;
        this.category = category;
        this.advertiser = advertiser;
        this.campaignObjective = campaignObjective;
        this.reportingEmail = reportingEmail;
    }
}
