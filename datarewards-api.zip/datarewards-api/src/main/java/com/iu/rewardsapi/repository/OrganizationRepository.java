package com.iu.rewardsapi.repository;

import com.iu.rewardsapi.entity.Organization;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrganizationRepository extends CrudRepository<Organization, Integer> {

    @Cacheable(value = "o1", key = "#id", unless = "#result == null")
    Organization findById(String id);

    @Override
    @CacheEvict(value = "o1", key = "#organization.id")
    <S extends Organization> S save(S organization);

}
