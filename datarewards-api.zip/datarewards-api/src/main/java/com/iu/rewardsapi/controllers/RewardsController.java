package com.iu.rewardsapi.controllers;

import com.iu.rewardsapi.dto.common.ResponseDto;
import com.iu.rewardsapi.dto.request.RewardsDTO;
import com.iu.rewardsapi.entity.Organization;
import com.iu.rewardsapi.entity.Reward;
import com.iu.rewardsapi.repository.OrganizationRepository;
import com.iu.rewardsapi.service.RewardService;
import com.iu.rewardsapi.service.adapter.CarrierRegistry;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author Vamshi Gopari
 */
@RestController
@RequestMapping("/rewards")
@Api(tags = "Rewards")
public class RewardsController {

    @Autowired
    private RewardService rewardService;

    @Autowired
    private CarrierRegistry carrierRegistry;

    @Autowired
    private OrganizationRepository organizationRepository;

    @PostMapping("/redeem")
    public ResponseEntity<ResponseDto<Reward>> redeemReward(@RequestBody @Valid RewardsDTO rewardsDTO) {
        Organization org = organizationRepository.findById(rewardsDTO.getOrganizationId());
        return carrierRegistry.getServiceBean(org.getName()).rewardRedemption(rewardsDTO);
    }

}
