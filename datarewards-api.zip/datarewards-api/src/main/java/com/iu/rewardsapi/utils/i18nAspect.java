package com.iu.rewardsapi.utils;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

@Aspect
@Component
public class i18nAspect {

    private static final Logger logger = LogManager.getLogger(i18nAspect.class);

    @Autowired
    private Localizer localizer;

    @Pointcut("@annotation(org.springframework.web.bind.annotation.RequestMapping)")
    public void action() {
    }

//    @Before("action()")
    public void preAction(JoinPoint joinPoint) {

        ServletRequestAttributes attributes= (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request=attributes.getRequest();

        String language = "en";

        if(request.getParameter("lang") != null){

            language = request.getParameter("lang");
        }

        localizer.setMessage("Hello world");
        localizer.setLanguage(language);

        logger.info("DEBUG: In i18nAspect" + request.getParameter("useridentifier"));

    }

    @Component
    @RequestScope
    public class Localizer {

        @Autowired
        private MessageSource messageSource;

        private String message;
        private String language;
        private Locale locale;

        public String getMessage() {
            return messageSource.getMessage("greeting",null,locale);
        }

        public String getString(String identifier) {
            return messageSource.getMessage(identifier,null,locale);
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getLanguage() {
            return language;
        }

        public void setLanguage(String language) {
            this.language = language;
            locale = new Locale(language);
        }
    }

    @Configuration
    public class StringsConfig {

        @Bean
        public ResourceBundleMessageSource messageSource() {

            ResourceBundleMessageSource source = new ResourceBundleMessageSource();
            source.setBasenames("messages/strings");
            source.setUseCodeAsDefaultMessage(true);

            return source;
        }
    }
}
