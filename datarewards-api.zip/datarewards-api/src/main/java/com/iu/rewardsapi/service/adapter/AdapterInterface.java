package com.iu.rewardsapi.service.adapter;

import com.iu.rewardsapi.dto.common.ResponseDto;
import com.iu.rewardsapi.dto.request.RewardsDTO;
import com.iu.rewardsapi.dto.response.AdListResponse;
import com.iu.rewardsapi.entity.Reward;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface AdapterInterface {

    ResponseEntity<ResponseDto<List<AdListResponse>>> getEligibleCampaigns(String organizationId, String iuGuid);
    ResponseEntity<ResponseDto<Reward>> rewardRedemption(RewardsDTO rewardsDTO);
}
