package com.iu.rewardsapi.service;

import com.iu.rewardsapi.dto.response.AdListResponse;
import com.iu.rewardsapi.service.adapter.AdapterInterface;
import com.iu.rewardsapi.dto.common.ResponseDto;
import com.iu.rewardsapi.dto.request.RewardsDTO;
import com.iu.rewardsapi.entity.Campaign;
import com.iu.rewardsapi.entity.Organization;
import com.iu.rewardsapi.entity.OrganizationUser;
import com.iu.rewardsapi.entity.Reward;
import com.iu.rewardsapi.repository.*;
import com.iu.rewardsapi.utils.Constants;
import com.iu.rewardsapi.utils.DateUtil;
import com.iu.rewardsapi.utils.RewardConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author Vamshi Gopari
 */
@Service("telcel")
@Slf4j
public class CarrierAdapterService implements AdapterInterface {

    @Autowired
    private AdListRepository adListRepository;

    @Autowired
    private OrganizationUserService organizationUserService;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private CampaignRepository campaignRepository;

    @Autowired
    private RewardRepository rewardRepository;

    @Autowired
    private OrganizationUserRepository organizationUserRepository;

    @Value("${default.organization.timezone}")
    private String defaultTimeZone;

    @Override
    public ResponseEntity<ResponseDto<List<AdListResponse>>> getEligibleCampaigns(String organizationId, String iuGuid) {
        log.info("IN TELCEL SERVICE");
        ResponseDto<List<AdListResponse>> response = new ResponseDto<>();
        List<AdListResponse> adlist = adListRepository.findEligibleCampaigns(organizationId, iuGuid);

        if (!adlist.isEmpty()) {
            response.setData(adlist);
            response.setStatus(HttpStatus.OK.toString());
            response.setMessage(Constants.FETCH_CAMPAIGN_SUCCESS);
        } else {
            response.setStatus(HttpStatus.NOT_FOUND.toString());
            response.setMessage(Constants.NO_CAMPAIGNS_FOUND);
        }
        return ResponseEntity.ok().body(response);
    }

    @Override
    public ResponseEntity<ResponseDto<Reward>> rewardRedemption(RewardsDTO rewardsDTO) {
        //create the organization user.
        OrganizationUser user = organizationUserService
                .createUser(rewardsDTO.getUserName(), rewardsDTO.getPhoneNumber(), rewardsDTO.getOrganizationId());
        //get the organization details
        Organization organization = organizationRepository.findById(rewardsDTO.getOrganizationId());
        //get the campaign details
        Optional<Campaign> campaign = campaignRepository.findById(Long.parseLong(rewardsDTO.getCampaignId()));
        ResponseDto<Reward> responseDto = new ResponseDto<>();
        if(user != null && campaign.isPresent()) {
            Optional<Reward> reward = rewardRepository.findByCampaignIdAndIuGuid(Long.parseLong(rewardsDTO.getCampaignId()), user.getIuGuid());

            //checking if the user has already redeemed the reward in rewards table
            if(!reward.isPresent() && organization!=null) {
                int toBeClaimed = user.getTotalClaimedInMB() + Integer.parseInt(campaign.get().getDataPerUser());
//                Checking the data to be claimed is less than organization's daily limit per user
//                if(!user.isDailyLimitReached() && toBeClaimed <= organization.getDailyLimitPerUser()) {
                    Reward rewardEntity = new Reward();
                    rewardEntity.setIuGuid(user.getIuGuid());
                    rewardEntity.setCampaignId(Long.parseLong(rewardsDTO.getCampaignId()));
                    rewardEntity.setOrganizationId(rewardsDTO.getOrganizationId());
                    rewardEntity.setClaimedTime(DateUtil.getCurrentEpochTimeInSecs());
                    rewardEntity.setClaimedDate(DateUtil.getCurrentDayWithTimezoneInInt(defaultTimeZone));
                    rewardEntity.setStatus(RewardConstants.REWARD_STATUS_PROCESSED);
                    rewardEntity.setRedeemed(true);
                    rewardRepository.save(rewardEntity);
                    user.setTotalClaimedInMB(toBeClaimed);
                    user.setDailyLimitReached(false);
                    organizationUserRepository.save(user);
                    responseDto.setMessage("Reward Redeemed!");
                    responseDto.setData(rewardEntity);
//                } else {
//                    user.setDailyLimitReached(true);
//                    organizationUserRepository.save(user);
//                    responseDto.setMessage("Daily limit Exceeded!");
//                }
            } else {
                responseDto.setMessage("You already Redeemed this Reward!");
            }
        }
        return ResponseEntity.ok().body(responseDto);
    }
}
