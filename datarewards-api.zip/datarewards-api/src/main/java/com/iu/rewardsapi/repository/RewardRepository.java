package com.iu.rewardsapi.repository;

import com.iu.rewardsapi.entity.Reward;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RewardRepository  extends JpaRepository<Reward, Long> {

    @Cacheable(value = "r1", key = "{ #campaignId, #iuGuid }", unless = "#result == null")
    Optional<Reward> findByCampaignIdAndIuGuid(Long campaignId, String iuGuid);

    @Cacheable(value = "r2", key = "#iuGuid", unless = "#result == null")
    List<Reward> findByIuGuid(String iuGuid);

    @Override
    @Caching(evict = {
            @CacheEvict(value = "r1", key = "{ #reward.campaignId, #reward.iuGuid }"),
            @CacheEvict(value = "r2", key = "#reward.iuGuid"),
    })
    <S extends Reward> S save(S reward);
}
