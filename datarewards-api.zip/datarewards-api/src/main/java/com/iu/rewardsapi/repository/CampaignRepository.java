package com.iu.rewardsapi.repository;

import com.iu.rewardsapi.entity.Campaign;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface CampaignRepository extends JpaRepository<Campaign, Long> {

    @Cacheable(value = "c1", key = "#campaignId", unless = "#result == null")
    Optional<Campaign> findById(Long campaignId);

    @Cacheable(value = "c2", key = "{ #organizationId, #status }", unless = "#result == null")
    List<Campaign> findByOrganizationIdAndStatusOrderByIdDesc(String organizationId, String status);

    @Cacheable(value = "c3", key = "#organizationId", unless = "#result == null")
    List<Campaign> findByOrganizationIdOrderByIdDesc(String organizationId);

    @Cacheable(value = "c4", key = "#name", unless = "#result == null")
    Campaign findByName(String name);

    @Cacheable(value = "c5", key = "#status", unless = "#result == null")
    List<Campaign> findByStatus(String status);

    @Caching(evict = {
            @CacheEvict(value = "c1", key = "#campaign.id"),
            @CacheEvict(value = "c2", key = "{ #campaign.organizationId, #campaign.status }"),
            @CacheEvict(value = "c3", key = "#campaign.organizationId"),
            @CacheEvict(value = "c4", key = "#campaign.name"),
            @CacheEvict(value = "c5", key = "#campaign.status")
    })
    @Override
    <S extends Campaign> S save(S campaign);
}
