package com.iu.rewardsapi.service;

import com.amazonaws.event.ProgressListener;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3URI;
import com.amazonaws.services.s3.model.*;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.services.s3.transfer.Upload;
import com.amazonaws.util.StringUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.gson.Gson;
import com.iu.rewardsapi.dto.common.ResponseDto;
import com.iu.rewardsapi.dto.request.CampaignDTO;
import com.iu.rewardsapi.dto.response.AdListResponse;
import com.iu.rewardsapi.dto.response.CacheAssetsResponse;
import com.iu.rewardsapi.entity.*;
import com.iu.rewardsapi.exceptions.UnprocessableEntityException;
import com.iu.rewardsapi.repository.*;
import com.iu.rewardsapi.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.net.InetAddress;
import java.net.URL;
import java.net.URLConnection;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;
import java.util.concurrent.Executors;

import static com.iu.rewardsapi.utils.RewardsMessageIds.INVALID_ORGID;

/**
 * @author Vamshi Gopari
 *
 */
@Service
@Slf4j
public class CampaignService {

    private static final Log logger = LogFactory.getLog(CampaignService.class);

    @Value("${aws.s3bucket}")
    private String awsS3Bucket;

    @Value("${default.organization.timezone}")
    private String defaultTimeZone;

    @Autowired
    private AmazonS3 s3client;

    @Autowired
    private i18nAspect.Localizer localizer;

    @Autowired
    private CampaignRepository campaignRepository;

    @Autowired
    private CampaignMetricRepository campaignMetricRepository;

    @Autowired
    private AdListRepository adListRepository;

    @Autowired
    private RewardRepository rewardRepository;

    @Autowired
    private DtoMapperService dtoMapperService;

    @Value("${default.organization.timezone}")
    private String defaultTimezone;

    /**
     * Cron Job to end the completed campaigns
     */
    @Scheduled(cron = "0 0 * ? * *")
    public void endCampaigns() {
        log.info("START of Cron Job to End Campaigns");
        Gson gsonObj = new Gson();
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        List<Campaign> campaigns = campaignRepository.findByStatus(Constants.ACTIVE);
        campaigns.forEach( campaign -> {
            if(campaign.getEndDate().before(new Date())) {
                campaign.setActive(false);
                campaign.setStatus(Constants.COMPLETED);
                AdList adList = gsonObj.fromJson(campaign.getAdJson(), AdList.class);
                adList.setStatus(Constants.COMPLETED);
                try {
                    String adJson = ow.writeValueAsString(adList);
                    campaign.setAdJson(adJson);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                }
                adListRepository.save(adList);
                campaignRepository.save(campaign);
            }
        });
        log.info("END of Cron Job to End Campaigns");
    }

    private String downloadAssetFromURL(String endPoint, Long campaignId, String organizationName, String fileType) throws IOException {
        log.info("Upload File from external URL.");
        String filename = "Campaign";
        String path = "";
        URL url = new URL(endPoint);
        URLConnection conn = url.openConnection();
        conn.setRequestProperty("User-Agent", Constants.USER_AGENT);
        conn.connect();
        String extension = FilenameUtils.getExtension(url.getPath());
        String defaultExtension = fileType.equals(Constants.VIDEO) ? "mp4" : "jpg";
        filename = filename + "_" + DateUtil.getCurrentDateAndTimeWithTimeZone(defaultTimeZone) + "." + (!extension.equals("") ? extension : defaultExtension);
        File file = new File(filename);
        if (!file.exists()) {
            file.createNewFile();
        }
        // get content from url as input stream and add it to File Obj
        try (  ReadableByteChannel rbc = Channels.newChannel(conn.getInputStream());
               FileOutputStream fos = new FileOutputStream(file)) {
            fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
        } catch (Exception e) {
            Files.deleteIfExists(Paths.get(filename));
            e.printStackTrace();
            throw new IOException(e.getMessage());
        }

        if(fileType.equalsIgnoreCase("video")) {
            path = String.format(Constants.S3_FILEPATH, organizationName, campaignId, Constants.VIDEOS, file.getName());
        } else {
            path = String.format(Constants.S3_FILEPATH, organizationName, campaignId, Constants.THUMBNAILS, file.getName());
        }
        if(file.exists()) {
            //upload object to s3 bucket & delete file from local
            s3client.putObject(awsS3Bucket, path, file);
            Files.deleteIfExists(Paths.get(filename));
            return String.format(Constants.S3_LINK, awsS3Bucket, path);
        }
        return null;
    }

    private String downloadAssetFromS3EndPoint(String endPoint, Long campaignId, String organizationName, String fileType) throws IOException {
        log.info("Upload File from s3URL.");
        String filename = "Campaign";
        String path = "";
        AmazonS3URI s3URI = new AmazonS3URI(endPoint);
        String extension = FilenameUtils.getExtension(s3URI.getKey());
        filename = filename + "_" + DateUtil.getCurrentDateAndTimeWithTimeZone(defaultTimeZone) + "." + extension;
        File localFile = new File(filename);
        if(fileType.equalsIgnoreCase("video")) {
            path = String.format(Constants.S3_FILEPATH, organizationName, campaignId, Constants.VIDEOS, localFile.getName());
        } else {
            path = String.format(Constants.S3_FILEPATH, organizationName, campaignId, Constants.THUMBNAILS, localFile.getName());
        }
        //file from s3 is being written to localFile
        s3client.getObject(new GetObjectRequest(s3URI.getBucket(), s3URI.getKey()), localFile);
        //upload object to s3 bucket
        s3client.putObject(s3URI.getBucket(), path, localFile);
        //delete file from local
        if(localFile.exists()) {
            Files.deleteIfExists(Paths.get(localFile.getName()));
        }
        return String.format(Constants.S3_LINK, s3URI.getBucket(), path);
    }

    /**
     * upload the files through s3 url
     */
    public String downloadAsset(String endPoint, Long campaignId, String organizationName, String fileType) throws IOException {
        logger.info("Uploading File to S3 ");
        if(!endPoint.contains(awsS3Bucket+".s3")) {
            return downloadAssetFromURL(endPoint, campaignId, organizationName, fileType);
        } else {
            return downloadAssetFromS3EndPoint(endPoint, campaignId, organizationName, fileType);
        }
    }

    /**
     * delete s3 objects
     */
    private void deleteS3Objects(String organizationName, String campaignId, String fileType) {
        logger.info("Delete Existing " + fileType + " in s3!");
        s3client.listObjects(awsS3Bucket, organizationName+ "/" + campaignId + "/" + fileType + "/")
                .getObjectSummaries().forEach(s3ObjectSummary -> s3client.deleteObject(awsS3Bucket, s3ObjectSummary.getKey()));
    }

    /**
     * Get All assets from S3
     */
    public ResponseEntity<ResponseDto<HashMap<String, List<String>>>> getExistingAssets(String organizationId, String organizationName) {
        List<Campaign> campaigns = campaignRepository.findByOrganizationIdOrderByIdDesc(organizationId);
        HashMap<String, List<String>> allAssets = new HashMap<>();
        String[] assetTypes = new String[]{Constants.VIDEOS, Constants.THUMBNAILS};
        for(String type: assetTypes) {
            if (campaigns != null) {
                campaigns.forEach( campaign -> {
                    ListObjectsV2Request req = new ListObjectsV2Request().withBucketName(awsS3Bucket).withPrefix(organizationName + "/" + campaign.getId() + "/" + type + "/");
                    ListObjectsV2Result listing = s3client.listObjectsV2(req);
                    listing.getObjectSummaries().forEach( summary -> {
                        if(summary.getKey().contains(Constants.VIDEOS)) {
                            allAssets.computeIfAbsent(Constants.VIDEOS, k -> new ArrayList<>()).add(String.format(Constants.S3_LINK, awsS3Bucket, summary.getKey()));
                        } else {
                            allAssets.computeIfAbsent(Constants.THUMBNAILS, k -> new ArrayList<>()).add(String.format(Constants.S3_LINK, awsS3Bucket, summary.getKey()));
                        }
                    });
                });
            }
        }
        ResponseDto<HashMap<String, List<String>>> response = new ResponseDto<>();
        if(allAssets.size() > 0) {
            response.setData(allAssets);
            response.setMessage("All assets fetched.");
            response.setStatus(HttpStatus.OK.toString());
        } else {
            response.setMessage("No assets found!");
            response.setStatus(HttpStatus.OK.toString());
        }
        return ResponseEntity.ok().body(response);
    }

    /**
     * Create / Duplicate a campaign
     */
    public ResponseEntity<ResponseDto<Campaign>> createCampaign(Map<String, MultipartFile> files, CampaignDTO campaignDTO) throws IOException {

        if (StringUtils.isNullOrEmpty(campaignDTO.getOrganizationName())) {
            throw new UnprocessableEntityException(localizer.getString(INVALID_ORGID), ErrorCodeConstants.INVALID_ORG_ID);
        }

        AdList adDto = new AdList();
        CampaignMetric campaignMetric = new CampaignMetric();
        ResponseDto<Campaign> response = new ResponseDto<>();
        Campaign entity = dtoMapperService.convertToEntity(campaignDTO);
        if(campaignRepository.findByName(campaignDTO.getName()) == null) {
            campaignDTO.setAdType(Constants.AD_TYPE);
            // By default, create as inactive
            entity.setActive(false);
            //save the campaign
            entity = campaignRepository.save(entity);
        } else {
            response.setMessage("Campaign name already exists!");
            response.setData(null);
            response.setErrorCode(String.valueOf(HttpStatus.BAD_REQUEST));
            return ResponseEntity.ok().body(response);
        }

        if(campaignDTO.getVideoUrl().length() > 0) { //if user selects from the existing assets in s3
            adDto.setVideoURL(downloadAsset(campaignDTO.getVideoUrl(), entity.getId(), campaignDTO.getOrganizationName(), Constants.VIDEO));
        }
        if(campaignDTO.getImageUrl().length() > 0) { //if user selects from the existing assets in s3
            adDto.setImageURL(downloadAsset(campaignDTO.getImageUrl(), entity.getId(), campaignDTO.getOrganizationName(), Constants.IMAGE));
        }

        if(files.size() > 0) {   //verifying whether or not the files are present
            for (Map.Entry<String, MultipartFile> file : files.entrySet()) {
                // filename of video and thumbail in s3 bucket
                String filename = file.getValue().getOriginalFilename();
                if(filename != null) {
                    filename = filename.substring(0, filename.lastIndexOf(".")) + "_" + DateUtil.getCurrentDateAndTimeWithTimeZone(defaultTimeZone) + filename.substring(filename.lastIndexOf("."));
                }

                // setting the s3 path of video and thumbnail
                String path = "";
                if(file.getKey().equalsIgnoreCase(Constants.AD_TYPE)) {
                    path = String.format(Constants.S3_FILEPATH, campaignDTO.getOrganizationName(), entity.getId(), Constants.VIDEOS, filename);
                } else {
                    path = String.format(Constants.S3_FILEPATH, campaignDTO.getOrganizationName(), entity.getId(), Constants.THUMBNAILS, filename);
                }
                InputStream fileStream = file.getValue().getInputStream();
                ObjectMetadata metadata = new ObjectMetadata();
                metadata.setContentLength(fileStream.available());

                /**
                 * TransferManager makes extensive use of Amazon S3 multipart uploads to achieve
                 * enhanced throughput, performance and reliability.
                 * uploading the video and thumbnail to s3 bucket
                 */

                TransferManager tm = TransferManagerBuilder.standard()
                        .withS3Client(s3client)
                        .withMultipartUploadThreshold((long) (5 * 1024 * 1025))
                        .withExecutorFactory(() -> Executors.newFixedThreadPool(5))
                        .build();
                File convFile = new File(file.getValue().getOriginalFilename());
                try(FileOutputStream fos = new FileOutputStream(convFile);) {
                    fos.write(file.getValue().getBytes());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ProgressListener progressListener = progressEvent -> logger.info(
                        "Transferred bytes: " + progressEvent.getBytesTransferred());
                PutObjectRequest request = new PutObjectRequest(
                        awsS3Bucket, path, convFile);
                request.setGeneralProgressListener(progressListener);
                Upload upload = tm.upload(request);

                try {
                    upload.waitForCompletion();
                } catch (Exception e) {
                    e.printStackTrace();
                    Thread.currentThread().interrupt();
                }
                Files.deleteIfExists(Paths.get(file.getValue().getOriginalFilename()));
                if (file.getKey().equalsIgnoreCase(Constants.AD_TYPE)) {
                    adDto.setVideoURL(String.format(Constants.S3_LINK, awsS3Bucket, path));
                } else {
                    adDto.setImageURL(String.format(Constants.S3_LINK, awsS3Bucket, path));
                }
            }
        }
        adDto.setStatus(campaignDTO.getStatus());
        adDto.setId(entity.getId());
        adDto.setOrganizationId(campaignDTO.getOrganizationId());
        adDto.setClaimed(false);
        if(campaignDTO.getEndDate() != null) {
            adDto.setExpiresAt(campaignDTO.getEndDate().getTime());
        }
        adDto.setAdType(Constants.AD_TYPE);
        adDto.setRewardDisplay(campaignDTO.getRewardInMB());
        adDto.setDataPerUser(campaignDTO.getDataPerUser());
        adDto.setDataPerUserSpecified(campaignDTO.getDataPerUserSpecified());
        adDto.setConfirmationInterval(campaignDTO.getConfirmationInterval());
        adDto.setConfirmationType(campaignDTO.getConfirmationType());
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String adJson = ow.writeValueAsString(adDto);

        Optional<Campaign> campaign = campaignRepository.findById(entity.getId());
        if(campaign.isPresent()) {
            campaign.get().setAdJson(adJson);
            //saving the campaign to DB
            campaignRepository.save(campaign.get());
            campaignMetric.setCampaignId(entity.getId());
            campaignMetricRepository.save(campaignMetric);
            response.setData(campaign.get());
        }
        response.setStatus(HttpStatus.OK.toString());
        response.setMessage(Constants.CAMPAIGN_CREATE_SUCCESS);
        return ResponseEntity.ok().body(response);
    }

    /**
     * Fetch the campaigns based on status and organizationID
     * TODO: Add redis cache
     */
    public ResponseEntity<ResponseDto<List<Campaign>>> getAllCampaigns(String status, String organizationId) {
        List<Campaign> campaigns = new ArrayList<>();
        ResponseDto<List<Campaign>> response = new ResponseDto<>();
        if(status.equalsIgnoreCase("all")) {
            campaignRepository.findByOrganizationIdOrderByIdDesc(organizationId).forEach(campaigns::add);
        } else {
            campaigns = campaignRepository.findByOrganizationIdAndStatusOrderByIdDesc(organizationId, status);
        }
        if(campaigns.size() > 0) {
            response.setData(campaigns);
            response.setStatus(HttpStatus.OK.toString());
            response.setMessage(Constants.FETCH_CAMPAIGN_SUCCESS);
        } else {
            response.setStatus(HttpStatus.NOT_FOUND.toString());
            response.setMessage(Constants.NO_CAMPAIGNS_FOUND);
        }
        return ResponseEntity.ok().body(response);
    }

    /**
     * Fetch the specified campaign details
     *
     * @TODO Redis cache needs to implement here
     */
    public ResponseEntity<ResponseDto<Campaign>> getCampaignById(String campaignId) {
        Optional<Campaign> campaign = campaignRepository.findById(Long.valueOf(campaignId));
        ResponseDto<Campaign> response = new ResponseDto<>();
        if (campaign.isPresent()) {
            response.setData(campaign.get());
            response.setStatus(HttpStatus.OK.toString());
            response.setMessage(Constants.FETCH_CAMPAIGN_SUCCESS);
        } else {
            response.setStatus(HttpStatus.NOT_FOUND.toString());
            response.setMessage(Constants.NO_CAMPAIGNS_FOUND);
        }
        return ResponseEntity.ok().body(response);
    }

    /**
     * Approve / stop / resume campaign details from the mysql DB
     */
    public ResponseEntity<ResponseDto<Campaign>> updateCampaignStatus(String campaignId, String status) {
        Optional<Campaign> campaign = campaignRepository.findById(Long.valueOf(campaignId));
        Campaign save = new Campaign();
        if(campaign.isPresent()) {
            campaign.get().setStatus(status);
            Gson gsonObj = new Gson();
            AdList adList = gsonObj.fromJson(campaign.get().getAdJson(), AdList.class);
            adList.setStatus(status);
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            try {
                String adJson = ow.writeValueAsString(adList);
                campaign.get().setAdJson(adJson);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            if(status.equalsIgnoreCase(Constants.ACTIVE)) {
                campaign.get().setActive(true);
                adListRepository.save(adList);
            } else if(status.equalsIgnoreCase(Constants.DRAFT)) {
                campaign.get().setActive(false);
                adListRepository.delete(adList);
            }
            save = campaignRepository.save(campaign.get());
        }
        ResponseDto<Campaign> response = new ResponseDto<>();
        if (save != null) {
            response.setData(save);
            response.setStatus(HttpStatus.OK.toString());
            response.setMessage(Constants.FETCH_CAMPAIGN_SUCCESS);
        } else {
            response.setStatus(HttpStatus.NOT_FOUND.toString());
            response.setMessage(Constants.NO_CAMPAIGNS_FOUND);
        }
        return ResponseEntity.ok().body(response);
    }

    /**
     * Edit, Edit and Approve Campaign
     */
    public ResponseEntity<ResponseDto<Campaign>> updateCampaign(Map<String, MultipartFile> files, CampaignDTO campaignDTO, String action) throws IOException {

        campaignDTO.setAdType(Constants.AD_TYPE);

        AdList adList = new AdList();
        ResponseDto<Campaign> response = new ResponseDto<>();

        if(campaignDTO.getVideoUrl().length() > 0) {
            if(campaignDTO.getVideoUrl().contains(awsS3Bucket+".s3"))  {
                //if user selects from the existing assets in s3
                // deleting ad video from s3
                AmazonS3URI s3URI = new AmazonS3URI(campaignDTO.getVideoUrl());
                String campaignIdFromS3URI = org.apache.commons.lang3.StringUtils.substringBetween(s3URI.getKey(), "/", "/" );
                if(!campaignIdFromS3URI.equalsIgnoreCase(campaignDTO.getId())) {
                    deleteS3Objects(campaignDTO.getOrganizationName(),campaignDTO.getId(), Constants.VIDEOS);
                    adList.setVideoURL(downloadAsset(campaignDTO.getVideoUrl(), Long.valueOf(campaignDTO.getId()), campaignDTO.getOrganizationName(), Constants.VIDEO));
                } else adList.setVideoURL(campaignDTO.getVideoUrl());
            } else {
                deleteS3Objects(campaignDTO.getOrganizationName(),campaignDTO.getId(), Constants.VIDEOS);
                adList.setVideoURL(downloadAsset(campaignDTO.getVideoUrl(), Long.valueOf(campaignDTO.getId()), campaignDTO.getOrganizationName(), Constants.VIDEO));
            }
        }
        if(campaignDTO.getImageUrl().length() > 0) {
            if(campaignDTO.getImageUrl().contains(awsS3Bucket+".s3"))  {
                //if user selects from the existing assets in s3
                // deleting ad thumbnail from s3
                AmazonS3URI s3URI = new AmazonS3URI(campaignDTO.getImageUrl());
                String campaignIdFromS3URI = org.apache.commons.lang3.StringUtils.substringBetween(s3URI.getKey(), "/", "/" );
                if(!campaignIdFromS3URI.equalsIgnoreCase(campaignDTO.getId())) {
                    deleteS3Objects(campaignDTO.getOrganizationName(), campaignDTO.getId(), Constants.THUMBNAILS);
                    adList.setImageURL(downloadAsset(campaignDTO.getImageUrl(), Long.valueOf(campaignDTO.getId()), campaignDTO.getOrganizationName(), Constants.IMAGE));
                } else adList.setImageURL(campaignDTO.getImageUrl());
            } else {
                deleteS3Objects(campaignDTO.getOrganizationName(), campaignDTO.getId(), Constants.THUMBNAILS);
                adList.setImageURL(downloadAsset(campaignDTO.getImageUrl(), Long.valueOf(campaignDTO.getId()), campaignDTO.getOrganizationName(), Constants.IMAGE));
            }
        }
        if(files.size() > 0) {
            if(files.get(Constants.VIDEO) != null) {
                // deleting ad video from s3
                deleteS3Objects(campaignDTO.getOrganizationName(),campaignDTO.getId(), Constants.VIDEOS);
            } else {
                adList.setVideoURL(campaignDTO.getVideoUrl());
            }
            if(files.get(Constants.IMAGE) != null) {
                // deleting ad thumbnail from s3
                deleteS3Objects(campaignDTO.getOrganizationName(), campaignDTO.getId(), Constants.THUMBNAILS);
            } else {
                adList.setImageURL(campaignDTO.getImageUrl());
            }

            for (Map.Entry<String, MultipartFile> file : files.entrySet()) {
                // filename of video and thumbail in s3 bucket
                String filename = file.getValue().getOriginalFilename();
                if(filename != null) {
                    filename = filename.substring(0, filename.lastIndexOf(".")) + " _ "
                            + DateUtil.getCurrentDateAndTimeWithTimeZone(defaultTimeZone)
                            + filename.substring(filename.lastIndexOf("."));
                }

                // setting the s3 path of video and thumbnail
                String path = "";
                if (file.getKey().equalsIgnoreCase(Constants.AD_TYPE)) {
                    path = String.format(Constants.S3_FILEPATH, campaignDTO.getOrganizationName(), campaignDTO.getId(), Constants.VIDEOS, filename);
                } else {
                    path = String.format(Constants.S3_FILEPATH, campaignDTO.getOrganizationName(), campaignDTO.getId(), Constants.THUMBNAILS, filename);
                }
                InputStream fileStream = file.getValue().getInputStream();
                ObjectMetadata metadata = new ObjectMetadata();
                metadata.setContentLength(fileStream.available());

                /**
                 * TransferManager makes extensive use of Amazon S3 multipart uploads to achieve
                 * enhanced throughput, performance and reliability.
                 * uploading the video and thumbnail to s3 bucket
                 */

                TransferManager tm = TransferManagerBuilder.standard().withS3Client(s3client)
                        .withMultipartUploadThreshold((long) (5 * 1024 * 1025))
                        .withExecutorFactory(() -> Executors.newFixedThreadPool(5)).build();
                File convFile = new File(file.getValue().getOriginalFilename());
                try(FileOutputStream fos = new FileOutputStream(convFile)) {
                    fos.write(file.getValue().getBytes());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ProgressListener progressListener = progressEvent -> logger
                        .info("Transferred bytes: " + progressEvent.getBytesTransferred());
                PutObjectRequest request = new PutObjectRequest(awsS3Bucket, path, convFile);
                request.setGeneralProgressListener(progressListener);
                Upload upload = tm.upload(request);

                try {
                    upload.waitForCompletion();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    Thread.currentThread().interrupt();
                }
                Files.deleteIfExists(Paths.get(file.getValue().getOriginalFilename()));
                if (file.getKey().equalsIgnoreCase(Constants.AD_TYPE)) {
                    adList.setVideoURL(String.format(Constants.S3_LINK, awsS3Bucket, path));
                } else {
                    adList.setImageURL(String.format(Constants.S3_LINK, awsS3Bucket, path));
                }
            }
        }

        adList.setStatus(campaignDTO.getStatus());
        adList.setId(Long.valueOf(campaignDTO.getId()));
        adList.setOrganizationId(campaignDTO.getOrganizationId());
        adList.setClaimed(false);
        if(campaignDTO.getEndDate() != null) {
            adList.setExpiresAt(campaignDTO.getEndDate().getTime());
        }
        adList.setAdType(Constants.AD_TYPE);
        adList.setRewardDisplay(campaignDTO.getRewardInMB());
        adList.setDataPerUser(campaignDTO.getDataPerUser());
        adList.setDataPerUserSpecified(campaignDTO.getDataPerUserSpecified());
        adList.setConfirmationInterval(campaignDTO.getConfirmationInterval());
        adList.setConfirmationType(campaignDTO.getConfirmationType());
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String adJson = ow.writeValueAsString(adList);

        // By default, create as inactive
        if(action.equalsIgnoreCase(Constants.APPROVE)) {
            campaignDTO.setActive(true);
            adListRepository.save(adList);
        } else {
            campaignDTO.setActive(false);
        }
        Campaign campaign = dtoMapperService.convertToEntity(campaignDTO);
        campaign.setAdJson(adJson);

        campaign = campaignRepository.save(campaign);
        response.setData(campaign);
        response.setStatus(HttpStatus.OK.toString());
        response.setMessage(Constants.CAMPAIGN_CREATE_SUCCESS);
        return ResponseEntity.ok().body(response);
    }

    public ResponseEntity<ResponseDto<List<AdListResponse>>> getActiveCampaigns(String organizationId, String iuGuid) {
        ResponseDto<List<AdListResponse>> response = new ResponseDto<>();
        List<AdListResponse> adlist = adListRepository.findEligibleCampaigns(organizationId, iuGuid);

        if (!adlist.isEmpty()) {
            response.setData(adlist);
            response.setStatus(HttpStatus.OK.toString());
            response.setMessage(Constants.FETCH_CAMPAIGN_SUCCESS);
        } else {
            response.setStatus(HttpStatus.NOT_FOUND.toString());
            response.setMessage(Constants.NO_CAMPAIGNS_FOUND);
        }
        return ResponseEntity.ok().body(response);
    }

    public ResponseEntity<ResponseDto<Campaign>> checkCampaignName(String campaignName) {
        ResponseDto<Campaign> response = new ResponseDto<>();
        Campaign campaign = campaignRepository.findByName(campaignName);
        if(campaign != null) {
            response.setData(campaign);
            response.setMessage("Campaign name already exists!");
            response.setStatus(String.valueOf(HttpStatus.BAD_REQUEST));
        } else {
            response.setData(null);
            response.setMessage("Campaign name doesn't exist!");
            response.setStatus(String.valueOf(HttpStatus.OK));
        }
        return ResponseEntity.ok().body(response);
    }

    @Value("${app.file.upload-dir}")
    private String fileStorageLocation;

    private String getFileExtension(String fileName) {
        if (fileName == null) {
            return null;
        }
        String[] fileNameParts = fileName.split("\\.");

        return fileNameParts[fileNameParts.length - 1];
    }

    public ResponseEntity<ResponseDto<CacheAssetsResponse>> storeFile(MultipartFile file, String fileUrl, String campaignName, String fileType) {
        CacheAssetsResponse cacheAssetsResponse = new CacheAssetsResponse();
        ResponseDto<CacheAssetsResponse> responseDto = new ResponseDto<>();
        String fileName = "";
        try {
            Path targetLocation = Paths.get(fileStorageLocation).toAbsolutePath().normalize();
            if(!Files.exists(targetLocation)) {
                Files.createDirectories(targetLocation);
            }
            if(fileUrl!=null && fileUrl.length()>0) {
                URL url = new URL(fileUrl);
                URLConnection conn = url.openConnection();
                conn.setRequestProperty("User-Agent", Constants.USER_AGENT);
                conn.connect();
                // TODO: to handle the redirect urls
                String contentType = conn.getContentType();
                String extension = contentType.substring(contentType.lastIndexOf('/')+1);
                fileName = campaignName + "_" + fileType + "." + extension;

                File fileFromUrl = new File(targetLocation + "/" + fileName);
                if (!fileFromUrl.exists()) {
                    fileFromUrl.createNewFile();
                }
                ReadableByteChannel rbc = Channels.newChannel(conn.getInputStream());
                FileOutputStream fos = new FileOutputStream(fileFromUrl);
                fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
                rbc.close();
                fos.close();
            } else {
                fileName = campaignName + "_" + file.getOriginalFilename();
                Files.copy(file.getInputStream(), targetLocation.resolve(fileName), StandardCopyOption.REPLACE_EXISTING);
            }
            log.info(String.valueOf(Files.exists(targetLocation.resolve(fileName))));
            log.info(String.valueOf(targetLocation.resolve(fileName)));
            if(Files.exists(targetLocation.resolve(fileName))) {
                cacheAssetsResponse.setFileName(fileName);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        responseDto.setData(cacheAssetsResponse);
        return ResponseEntity.ok().body(responseDto);
    }
}
