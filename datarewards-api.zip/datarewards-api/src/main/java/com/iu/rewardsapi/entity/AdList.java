package com.iu.rewardsapi.entity;

import com.iu.rewardsapi.dto.response.AdListResponse;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author Vamshi Gopari
 */
@NamedNativeQuery(name = "AdList.findEligibleCampaigns",
        query = "SELECT ad.id AS id, ad.organization_id AS organizationId, ad.status AS status, ad.video_url AS videoURL, " +
                "ad.image_url AS imageURL, ad.ad_type AS adType, ad.claimed AS claimed, ad.expires_at AS expiresAt, " +
                "ad.confirmation_interval AS confirmationInterval, ad.confirmation_type AS confirmationType, " +
                "ad.reward_display AS rewardDisplay, ad.data_per_user_specified AS dataPerUserSpecified, " +
                "ad.data_per_user AS dataPerUser, c.total_likes AS totalLikes, c.total_claimed AS totalClaimed, " +
                "(SELECT CASE WHEN EXISTS ( SELECT * FROM reward WHERE iu_guid=:iuGuid AND campaign_id=ad.id ) THEN 'true' ELSE 'false' END) as redeemed," +
                "(SELECT CASE WHEN EXISTS ( SELECT * FROM likes WHERE iu_guid=:iuGuid AND campaign_id=ad.id ) THEN 'true' ELSE 'false' END) AS 'like'" +
                "FROM ad_list ad, campaign_metric c, campaign cm WHERE (DATE(cm.start_date) > DATE(NOW()) AND cm.id=ad.id) AND " +
                "ad.id=c.campaign_id AND ad.organization_id=:organizationId ORDER BY ad.id DESC",
        resultSetMapping = "Mapping.AdListResponseDTO")
@SqlResultSetMapping(name = "Mapping.AdListResponseDTO",
        classes = @ConstructorResult(targetClass = AdListResponse.class,
                columns = {
                        @ColumnResult(name = "id", type = Long.class),
                        @ColumnResult(name = "organizationId", type = String.class),
                        @ColumnResult(name = "status", type = String.class),
                        @ColumnResult(name = "videoURL", type = String.class),
                        @ColumnResult(name = "imageURL", type = String.class),
                        @ColumnResult(name = "adType", type = String.class),
                        @ColumnResult(name = "claimed", type = Boolean.class),
                        @ColumnResult(name = "expiresAt", type = Long.class),
                        @ColumnResult(name = "confirmationInterval", type = String.class),
                        @ColumnResult(name = "confirmationType", type = String.class),
                        @ColumnResult(name = "rewardDisplay", type = Integer.class),
                        @ColumnResult(name = "dataPerUserSpecified", type = String.class),
                        @ColumnResult(name = "dataPerUser", type = String.class),
                        @ColumnResult(name = "totalLikes", type = Long.class),
                        @ColumnResult(name = "totalClaimed", type = Long.class),
                        @ColumnResult(name = "redeemed", type = Boolean.class),
                        @ColumnResult(name = "like", type = Boolean.class)
                }
        ))
@Getter
@Setter
@Entity
@Table(name="ad_list")
public class AdList implements Serializable {

    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "organization_id")
    private String organizationId;

    @Column(name = "status")
    private String status;

    @Column(name = "video_url")
    private String videoURL;

    @Column(name = "image_url")
    private String imageURL;

    @Column(name = "ad_type")
    private String adType;

    @Column(name = "claimed")
    private boolean claimed;

    @Column(name = "expires_at")
    private Long expiresAt;

    @Column(name = "confirmation_interval")
    private String confirmationInterval;

    @Column(name = "confirmation_type")
    private String confirmationType;

    @Column(name = "reward_display")
    private Integer rewardDisplay;

    @Column(name = "data_per_user_specified")
    private String dataPerUserSpecified;

    @Column(name = "data_per_user")
    private String dataPerUser;

}
