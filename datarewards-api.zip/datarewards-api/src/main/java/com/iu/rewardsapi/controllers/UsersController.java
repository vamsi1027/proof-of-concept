package com.iu.rewardsapi.controllers;

import com.iu.rewardsapi.repository.OrganizationRepository;
import com.iu.rewardsapi.service.adapter.CarrierRegistry;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@RestController
@RequestMapping("/users")
@Api(tags = "Users")
public class UsersController {

    @Autowired
    private CarrierRegistry carrierRegistry;

    @Value("${redirectUrl}")
    private String redirectUrl;

    @Autowired
    private OrganizationRepository organizationRepository;

    @GetMapping(value="/getrewards/{organizationId}/{userId}/{phoneNumber}")
    public RedirectView simulateThirdParty(
            @PathVariable(value="organizationId", required = true) String organizationId,
            @PathVariable(value="userId", required = true) String userId,
            @PathVariable(value="phoneNumber", required = true) String phoneNumber,
            HttpServletRequest request
    ) {
        log.info("Redirect host: " + redirectUrl);
        RedirectView redirectView = new RedirectView(redirectUrl + "/login?orgId=" + organizationId +
                "&userId=" + userId  + "&phone=" +phoneNumber,false);
        redirectView.setStatusCode(HttpStatus.MOVED_PERMANENTLY);
        return redirectView;
    }
}
