package com.iu.rewardsapi.dto.common;

import lombok.Data;

import java.util.List;

@Data
public class TokenDetail {

    private String email;
    private String name;
    private List<String> permissions;
}
