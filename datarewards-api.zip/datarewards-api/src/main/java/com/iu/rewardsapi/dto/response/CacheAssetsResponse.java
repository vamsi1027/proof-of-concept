package com.iu.rewardsapi.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CacheAssetsResponse {

    private String fileName;
}
