package com.iu.rewardsapi.utils;

public class RewardConstants {

    public static final String CURRENT_DATE_FORMAT = "yyyy-MM-dd";

    public static final String SUCCESS = "SUCCESS";
    public static final String FAILED = "FAILED";

    public static final String STATUS_SUCCESS = "0";
    public static final String STATUS_FAILURE = "1";

    public static final String X_FORWARDED_FOR = "x-forwarded-for";
    public static final String USER_AGENT = "user-agent";

    public static final String CLAIMED = "claimed";
    public static final String ID = "id";
    public static final String LIMIT_REACHED = "limitReached";
    public static final String PRELOAD_BUFFER = "preloadBuffer";

    public static final String DAILY_LIMIT_RESET_EPOCH = "dailylimitResetEpoch";
    public static final String DAILY_LIMIT_RESET_TIME_REMAINING = "dailylimitResetTimeRemaining";

    public static final String ORGANIZATION_USER_ID = "organizationUserId";
    public static final String ORGANIZATION_ID = "organizationId";
    public static final String CREATED_AT = "createdAt";
    public static final String EXPIRES_AT = "expiresAt";

    public static final String AD_TYPE_VIDEO="VIDEO";
    public static final String AD_TYPE_SURVEY="SURVEY";
    public static final String AD_TYPE_BANNER="BANNER";
    public static final String AD_TYPE_INSTALL_APP="INSTALL_APP";

    public static final String REWARD_STATUS_PENDING="PENDING";
    public static final String REWARD_STATUS_PROCESSED="PROCESSED";
    public static final String REWARD_STATUS_REJECTED="REJECTED";

    public static final String TOTALLIKES = "totalLikes";
    public static final String LIKED = "liked";
    public static final String TOTALCLAIMED = "totalClaimed";

    public static final String CLICK_ID = "clickid";
    public static final String CLIENT_ID = "clientid";
    public static final String CAMPAIGN_ID = "campaignid";

}
