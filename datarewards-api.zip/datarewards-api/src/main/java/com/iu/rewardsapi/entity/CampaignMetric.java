package com.iu.rewardsapi.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "campaign_metric")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CampaignMetric implements Serializable {

    @Id
    private Long campaignId;

    @Column(columnDefinition = "bigint not null default 0")
    private long totalClaimed = 0;

    @Column(columnDefinition = "bigint not null default 0")
    private long totalLikes = 0;

    @Column(columnDefinition = "int null default 0")
    private int impressions = 0;

    @Column(columnDefinition = "int null default 0")
    private int clicks = 0;

    @Column(columnDefinition = "int null default 0")
    private int videoClicks = 0;

    @Column(columnDefinition = "int null default 0")
    private int installAppClicks = 0;

    @Column(columnDefinition = "int null default 0")
    private int claimInitiated = 0;

}
