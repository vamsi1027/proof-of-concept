package com.iu.rewardsapi.service;

import com.iu.rewardsapi.dto.common.ResponseDto;
import com.iu.rewardsapi.dto.request.RewardsDTO;
import com.iu.rewardsapi.entity.Campaign;
import com.iu.rewardsapi.entity.Organization;
import com.iu.rewardsapi.entity.OrganizationUser;
import com.iu.rewardsapi.entity.Reward;
import com.iu.rewardsapi.repository.CampaignRepository;
import com.iu.rewardsapi.repository.OrganizationRepository;
import com.iu.rewardsapi.repository.OrganizationUserRepository;
import com.iu.rewardsapi.repository.RewardRepository;
import com.iu.rewardsapi.utils.DateUtil;
import com.iu.rewardsapi.utils.RewardConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author Vamshi Gopari
 */
@Service
@Slf4j
public class RewardService {

    @Value("${default.organization.timezone}")
    private String defaultTimeZone;

    @Autowired
    private OrganizationUserService organizationUserService;

    @Autowired
    private OrganizationUserRepository organizationUserRepository;

    @Autowired
    private RewardRepository rewardRepository;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private CampaignRepository campaignRepository;

    public ResponseEntity<ResponseDto<Reward>> redeemReward(RewardsDTO rewardsDTO) {

        //create the organization user.
        OrganizationUser user = organizationUserService
                .createUser(rewardsDTO.getUserName(), rewardsDTO.getPhoneNumber(), rewardsDTO.getOrganizationId());
        //get the organization details
        Organization organization = organizationRepository.findById(rewardsDTO.getOrganizationId());
        //get the campaign details
        Optional<Campaign> campaign = campaignRepository.findById(Long.parseLong(rewardsDTO.getCampaignId()));
        ResponseDto<Reward> responseDto = new ResponseDto<>();
        if(user != null && campaign.isPresent()) {
            Optional<Reward> reward = rewardRepository.findByCampaignIdAndIuGuid(Long.parseLong(rewardsDTO.getCampaignId()), user.getIuGuid());

            //checking if the user has already redeemed the reward in rewards table
            if(!reward.isPresent() && organization!=null) {
                int toBeClaimed = user.getTotalClaimedInMB() + Integer.parseInt(campaign.get().getDataPerUser());
                //Checking the data to be claimed is less than organization's daily limit per user
                if(!user.isDailyLimitReached() && toBeClaimed <= organization.getDailyLimitPerUser()) {
                    Reward rewardEntity = new Reward();
                    rewardEntity.setIuGuid(user.getIuGuid());
                    rewardEntity.setCampaignId(Long.parseLong(rewardsDTO.getCampaignId()));
                    rewardEntity.setOrganizationId(rewardsDTO.getOrganizationId());
                    rewardEntity.setClaimedTime(DateUtil.getCurrentEpochTimeInSecs());
                    rewardEntity.setClaimedDate(DateUtil.getCurrentDayWithTimezoneInInt(defaultTimeZone));
                    rewardEntity.setStatus(RewardConstants.REWARD_STATUS_PROCESSED);
                    rewardEntity.setRedeemed(true);
                    rewardRepository.save(rewardEntity);
                    user.setTotalClaimedInMB(toBeClaimed);
                    user.setDailyLimitReached(false);
                    organizationUserRepository.save(user);
                    responseDto.setMessage("Reward Redeemed!");
                    responseDto.setData(rewardEntity);
                } else {
                    user.setDailyLimitReached(true);
                    organizationUserRepository.save(user);
                    responseDto.setMessage("Daily limit Exceeded!");
                }
            } else {
                responseDto.setMessage("You already Redeemed this Reward!");
            }
        }
        return ResponseEntity.ok().body(responseDto);
    }

    public ResponseEntity<ResponseDto<List<Reward>>> getAllRewards(String iuGuid) {
        List<Reward> rewards = rewardRepository.findByIuGuid(iuGuid);
        ResponseDto<List<Reward>> responseDto = new ResponseDto<>();
        if(!rewards.isEmpty()) {
            responseDto.setData(rewards);
            responseDto.setMessage("Fetched Rewards successfully!");
        } else {
            responseDto.setMessage("No Rewards redeemed!");
        }
        return ResponseEntity.ok().body(responseDto);
    }
}
