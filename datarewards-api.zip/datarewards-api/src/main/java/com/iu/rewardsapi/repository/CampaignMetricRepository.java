package com.iu.rewardsapi.repository;

import com.iu.rewardsapi.entity.CampaignMetric;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Optional;

@Repository
public interface CampaignMetricRepository extends JpaRepository<CampaignMetric, Long> {


    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value = "INSERT INTO campaign_metric (campaign_id, total_claimed) VALUES (:campaignId, 1) " +
            "ON DUPLICATE KEY UPDATE total_claimed = total_claimed + 1", nativeQuery = true)
    @CacheEvict(value = "cm1", key = "#campaignId")
    int updateCampaignMetric(@Param("campaignId") String campaignId);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE campaign_metric SET total_likes = total_likes + 1 " +
            "WHERE campaign_id = :campaignId", nativeQuery = true)
    @CacheEvict(value = "cm1", key = "#campaignId")
    int updateCampaignMetricLikes(@Param("campaignId") Long campaignId);

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value = "UPDATE campaign_metric SET total_likes = total_likes - 1 " +
            "WHERE campaign_id = :campaignId", nativeQuery = true)
    @CacheEvict(value = "cm1", key = "#campaignId")
    int updateCampaignMetricUnLikes(@Param("campaignId") Long campaignId);

    @Cacheable(value = "cm1", key = "#id", unless = "#result == null")
    Optional<CampaignMetric> findById(Long id);

}
