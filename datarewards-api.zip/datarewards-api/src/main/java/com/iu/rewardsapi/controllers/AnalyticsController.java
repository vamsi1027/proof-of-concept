package com.iu.rewardsapi.controllers;

import com.iu.rewardsapi.dto.common.ResponseDto;
import com.iu.rewardsapi.dto.response.AnalyticsResponse;
import com.iu.rewardsapi.service.AnalyticsService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Vamshi G
 */
@RestController
@RequestMapping("/analytics")
@Api(tags = "Analytics")
public class AnalyticsController {

    @Autowired
    private AnalyticsService analyticsService;

    /**
     * Fetch All Analytics
     */
    @GetMapping("/{campaignId}")
    public ResponseEntity<ResponseDto<AnalyticsResponse>> getAnalytics(@PathVariable String campaignId) {
        return analyticsService.getAnalytics(campaignId);
    }
}