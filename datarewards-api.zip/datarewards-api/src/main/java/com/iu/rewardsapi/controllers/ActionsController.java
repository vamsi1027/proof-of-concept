package com.iu.rewardsapi.controllers;

import com.google.gson.Gson;
import com.iu.rewardsapi.dto.common.ResponseDto;
import com.iu.rewardsapi.dto.request.LikesDTO;
import com.iu.rewardsapi.entity.Likes;
import com.iu.rewardsapi.service.ActionsService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.List;

import static com.iu.rewardsapi.utils.RewardConstants.STATUS_SUCCESS;

@RestController
@Slf4j
@RequestMapping("/actions")
@Api(tags = "Actions")
public class ActionsController {

    @Autowired
    private ActionsService actionsService;

    @RequestMapping(value="/like", method = RequestMethod.POST)
    public ResponseEntity<ResponseDto<Likes>> saveLikes(
            @RequestBody @Valid LikesDTO input) throws Exception {

        log.info(String.format("save likes: %s %s", input.getOrganizationId(), input.getIuGuid())
                + ", input= "+new Gson().toJson(input));

        ResponseDto<Likes> response = new ResponseDto();

        return actionsService.saveLikes(input);
    }

    @RequestMapping(value="/unlike", method = RequestMethod.POST)
    public ResponseEntity<ResponseDto<Likes>> updateLikes(
            @RequestBody @Valid LikesDTO input) throws Exception {

        log.info(String.format("save unlikes: %s %s", input.getOrganizationId(), input.getIuGuid())
                + ", input= "+new Gson().toJson(input));

        ResponseDto<Likes> response = new ResponseDto();

        Likes unlikeResponse = actionsService.updateLikes(input);

        response.setStatus(STATUS_SUCCESS);
        response.setMessage("Unliked successfully");
        response.setData(unlikeResponse);
        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/likes/{organizationId}")
    public ResponseEntity<ResponseDto<List<Likes>>> getAllLikes(@PathVariable String organizationId) {
        return actionsService.getAllLikes(organizationId);
    }
}
