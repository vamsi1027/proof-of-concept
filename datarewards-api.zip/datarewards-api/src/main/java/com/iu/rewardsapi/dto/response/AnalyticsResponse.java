package com.iu.rewardsapi.dto.response;

import lombok.Data;

import java.util.List;

@Data
public class AnalyticsResponse {

    private TotalDataConsumption totalDataConsumption;
}