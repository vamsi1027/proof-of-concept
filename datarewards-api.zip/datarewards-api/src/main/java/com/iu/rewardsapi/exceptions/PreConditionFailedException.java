package com.iu.rewardsapi.exceptions;

public class PreConditionFailedException extends RuntimeException {

    private String errorCode;

    public PreConditionFailedException(String message) {
        super(message);
    }

    public PreConditionFailedException(String message, String errorCode) {

        super(message);
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
