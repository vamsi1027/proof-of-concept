package com.iu.rewardsapi.repository;

import com.iu.rewardsapi.dto.response.AdListResponse;
import com.iu.rewardsapi.entity.AdList;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Vamshi Gopari
 */
@Repository
public interface AdListRepository extends JpaRepository<AdList, Long> {

    /**
     * map total_likes and total_claimed, isLiked to ad_list response using the interface AdListResponse
     * Please find the @NamedNativeQuery findEligibleCampaigns in AdList Entity Class
     */
    @Cacheable(cacheNames="al1", key = "{ #organizationId, #iuGuid }", unless = "#result == null")
    @Query(nativeQuery = true)
    List<AdListResponse> findEligibleCampaigns(String organizationId, String iuGuid);

    @CacheEvict(value = "al1", allEntries = true)
    @Override
    <S extends AdList> S save(S adList);
}
