package com.iu.rewardsapi.service;

import com.iu.rewardsapi.dto.request.CampaignDTO;
import com.iu.rewardsapi.entity.Campaign;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * @author Vamshi Gopari
 */
@Service
public class DtoMapperService {

    @Autowired
    private ModelMapper modelMapper;

    public CampaignDTO convertToDTO(Campaign input) {
        return modelMapper.map(input, CampaignDTO.class);
    }

    public Campaign convertToEntity(CampaignDTO input) {
        return modelMapper.map(input, Campaign.class);
    }

}
