package com.iu.rewardsapi.exceptions;

public class InvalidSessionException extends RuntimeException {

    private String errorCode;

    public InvalidSessionException(String message) {
        super(message);

    }

    public InvalidSessionException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;

    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
