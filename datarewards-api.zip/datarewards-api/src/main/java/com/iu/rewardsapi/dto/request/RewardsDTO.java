package com.iu.rewardsapi.dto.request;

import lombok.Data;

@Data
public class RewardsDTO {

    private String campaignId;
    private String organizationId;
    private String userName;
    private String phoneNumber;
}
