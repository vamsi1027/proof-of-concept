package com.iu.rewardsapi.dto.response;

import lombok.Data;

@Data
public class TotalDataConsumption {

    private double percentageOfDataAvailable;
    private double dataAvailable;
}