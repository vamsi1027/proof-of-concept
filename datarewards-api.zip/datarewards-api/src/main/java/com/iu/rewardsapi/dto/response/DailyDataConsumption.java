package com.iu.rewardsapi.dto.response;

public interface DailyDataConsumption {

    void setDate(String date);
    String getDate();
    void setTotalClaimed(Long totalClaimed);
    Long getTotalClaimed();
    void setProjection(Long projection);
    Long getProjection();
}
