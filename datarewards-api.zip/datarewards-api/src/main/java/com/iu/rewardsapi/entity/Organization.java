package com.iu.rewardsapi.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@Table(name="organization")
public class Organization implements Serializable {

    @Id
    private String id;

    @Column(name = "name")
    private String name = "NA";

    @Column(name = "decryption_key")
    private String decryptionKey = "NA";

    @Column(name = "time_zone")
    private String timeZone = "America/New_York";

    @Column(name = "daily_limit_per_user")
    private int dailyLimitPerUser = 0;

    @Column(name = "language")
    private String language;

    @Column(name = "country_iso_code")
    private String countryISOCode;

    @Column(name = "blocked_list_times")
    private int blockedListTimes = 5;

    @Column(name = "blocked_list_days")
    private int blockedListDays = 5;

    @Column(name = "color_scheme")
    String colorScheme = "{}";

}
