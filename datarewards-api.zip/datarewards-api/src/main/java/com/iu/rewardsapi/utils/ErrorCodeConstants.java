package com.iu.rewardsapi.utils;

public class ErrorCodeConstants {

    public static final String INVALID_ORG_NAME="101";  //Invalid org name
    public static final String INVALID_RSA_KEY="102";   //Invalid RSA key
    public static final String ADS_NOT_FOUND="103";     //ADS not found
    public static final String INVALID_ORG_ID="104";    //Invalid org id
    public static final String INVALID_IUGUID="105";    //Invalid iuguid
    public static final String INVALID_PAGE_PARAM="106";    //Invalid page parameter
    public static final String INVALID_TOKEN="107";     //Invalid token input
    public static final String OPTIN_FALSE="108";       //User optin false
    public static final String CAMPAIGN_NOT_FOUND="109";//Campaign not found
    public static final String USER_LIKED_UNLIKED="110";//User has already liked/not liked yet
    public static final String ACTIVATION_FAILED="111";//Campaigns activation failed
    public static final String ORG_COLOR_FAILED="112";      //Org color update failed
    public static final String INVALID_COLOR_SCHEME="113";      //Invalid color scheme
    public static final String INVALID_COLOR_SCHEME_JSON="114";//Invalid color scheme json format
    public static final String OPTIN_FAILED="115";          //Optin update failed
    public static final String LIMIT_REACHED="116";         //Daily limit reached
    public static final String CLAIM_NOT_ALLOWED="117";     //You are not allowed to claim
    public static final String BLOCKED="118";               //You are blocked till date
    public static final String ALREADY_CLAIMED="119";       //You are already claimed
    public static final String STATUS_UPDATE_FAILED="120";//Rewards status update error
    public static final String TOKEN_EXPIRED="121";     //Token has expired
    public static final String INVALID_INPUT="122";     //MethodArgumentNotValidException
    public static final String INTERNAL_SERVER_ERROR="123";     //INTERNAL_SERVER_ERROR
    public static final String ORG_NOT_FOUND="124";//Org not found
    public static final String USER_NOT_FOUND="125";//User not found
    public static final String REWARDS_NOT_FOUND="126";//Rewards not found
    public static final String FILE_UPLOAD_FAILURE = "127"; //file upload failure

}
