package com.iu.rewardsapi.service.adapter;

public interface CarrierRegistry {

    public AdapterInterface getServiceBean(String carrierId);
}
