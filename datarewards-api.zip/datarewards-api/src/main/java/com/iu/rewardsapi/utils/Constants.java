package com.iu.rewardsapi.utils;

/**
 * @author Vamshi Gopari
 */
public class Constants {

    public static final String S3_LINK = "https://%s.s3.amazonaws.com/%s";
    public static final String AD_TYPE = "video";
    public static final String CAMPAIGN_CREATE_SUCCESS = "Campaign created successfully";
    public static final Long FILE_SIZE = 2097152L;
    public static final String FILE_SIZE_ERROR = "%s size is too large";
    public static final String FETCH_CAMPAIGN_SUCCESS = "Campaigns fetched successfully";
    public static final String NO_CAMPAIGNS_FOUND = "No Campaigns found";
    public static final String VIDEO = "video";
    public static final String IMAGE = "image";
    public static final String STATUS = "status";
    public static final String ID = "id";
    public static final String CAMPAIGN_NAME = "campaignName";
    public static final String CAMPAIGN_OBJECTIVE = "campaignObjective";
    public static final String ADVERTISER = "advertiser";
    public static final String CATEGORY = "category";
    public static final String AGENCY = "agency";
    public static final String START_DATE = "startDate";
    public static final String END_DATE = "endDate";
    public static final String ORGANIZATION_ID = "organizationId";
    public static final String ORGANIZATION_NAME = "organizationName";
    public static final String REPORTING_EMAIL = "reportingEmail";
    public static final String DAILY_LIMIT = "dailyLimit";
    public static final String DAILY_LIMIT_SPECIFIED = "dailyLimitSpecified";
    public static final String CAMPAIGN_LIMIT = "campaignLimit";
    public static final String CAMPAIGN_LIMIT_SPECIFIED = "campaignLimitSpecified";
    public static final String DATA_PER_USER = "dataPerUser";
    public static final String DATA_PER_USER_SPECIFIED = "dataPerUserSpecified";
    public static final String CAMPAIGN_TIME = "campaignTime";
    public static final String ACTION = "action";
    public static final String APPROVE = "approve";
    public static final String VIDEO_URL = "videoUrl";
    public static final String IMAGE_URL = "imageUrl";
    public static final String S3_FILEPATH = "%s/%s/%s/%s";
    public static final String VIDEOS = "videos";
    public static final String THUMBNAILS = "thumbnails";
    public static final String ACTIVE = "active";
    public static final String COMPLETED = "completed";
    public static final String DRAFT = "draft";
    public static final String GIGABYTE = "GB";

    public static final String CONFIRMATION_INTERVAL= "confirmationInterval";

    public static final String CONFIRMATION_TYPE= "confirmationType";
    public static final String ANALYTICS_FETCH_SUCCESS = "Analytics fetched successfully.";
    public static final String NO_ANALYTICS = "No analytics fetched.";
    public static final String USER_AGENT = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11";

    private Constants() {
    }
}
