package com.iu.rewardsapi.repository;

import com.iu.rewardsapi.dto.response.DailyDataConsumption;
import com.iu.rewardsapi.entity.CampaignMetricByDay;
import com.iu.rewardsapi.entity.CampaignMetricByDayPK;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface CampaignMetricByDayRepository extends JpaRepository<CampaignMetricByDay, CampaignMetricByDayPK> {

    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(value = "INSERT INTO campaign_metric_by_day (campaign_id, date, total_claimed) " +
            "VALUES (:campaignId, :date, 1) " +
            "ON DUPLICATE KEY UPDATE total_claimed = total_claimed + 1;", nativeQuery = true)
    @Caching(evict = {
            @CacheEvict(value = "cmbd1", key = "#campaignId"),
            @CacheEvict(value = "cmbd2", key = "{ #campaignId, #date }"),
    })
    int updateCampaignMetricByDay(@Param("campaignId") String campaignId, @Param("date") String date);

    @Query(value = "select CONCAT(day(STR_TO_DATE(c_m_day.date, '%m/%d/%Y')),'/',month(STR_TO_DATE(c_m_day.date, '%m/%d/%Y'))) as date, " +
            "total_claimed*c.data_per_user as totalClaimed from campaign_metric_by_day c_m_day, campaign c " +
            "where c.id=c_m_day.campaign_id and campaign_id=:campaignId", nativeQuery = true)
    @Cacheable(cacheNames="cmbd1", key = "#campaignId", unless = "#result == null")
    List<DailyDataConsumption> findByCampaignId(String campaignId);

    @Cacheable(cacheNames="cmbd2", key = "{ #campaignId, #date }", unless = "#result == null")
    Optional<CampaignMetricByDay> findByPkCampaignIdAndPkDate(String campaignId, String date);
}
