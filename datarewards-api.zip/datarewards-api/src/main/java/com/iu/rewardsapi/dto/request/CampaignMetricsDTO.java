package com.iu.rewardsapi.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CampaignMetricsDTO {

    private String campaignId;
    private String date;
}
