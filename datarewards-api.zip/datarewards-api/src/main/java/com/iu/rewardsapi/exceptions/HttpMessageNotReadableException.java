package com.iu.rewardsapi.exceptions;

public class HttpMessageNotReadableException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private String errorCode;

    public HttpMessageNotReadableException(String message) {
        super(message);
    }

    public HttpMessageNotReadableException(String message, String errorCode) {

        super(message);
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
