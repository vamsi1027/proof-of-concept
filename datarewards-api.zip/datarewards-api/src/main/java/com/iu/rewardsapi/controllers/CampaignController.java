package com.iu.rewardsapi.controllers;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.iu.rewardsapi.dto.response.AdListResponse;
import com.iu.rewardsapi.dto.response.CacheAssetsResponse;
import com.iu.rewardsapi.entity.Organization;
import com.iu.rewardsapi.repository.OrganizationRepository;
import com.iu.rewardsapi.service.adapter.CarrierRegistry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.iu.rewardsapi.dto.common.ResponseDto;
import com.iu.rewardsapi.dto.request.CampaignDTO;
import com.iu.rewardsapi.entity.Campaign;
import com.iu.rewardsapi.exceptions.FileSizeException;
import com.iu.rewardsapi.service.CampaignService;
import com.iu.rewardsapi.utils.Constants;
import com.iu.rewardsapi.utils.CommonUtility;
import com.iu.rewardsapi.utils.ErrorCodeConstants;

import io.swagger.annotations.Api;

import javax.servlet.http.HttpServletResponse;

/**
 * @author Vamshi Gopari
 */
@Slf4j
@RestController
@RequestMapping("/campaigns")
@Api(tags = "Campaigns")
public class CampaignController {

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private CarrierRegistry carrierRegistry;

    @Autowired
    private OrganizationRepository organizationRepository;

    @Value("${default.organization.timezone}")
    private String defaultTimezone;

    @GetMapping("/isLive")
    public String isLive() {
    	return " Yes, Data Rewards Portal is Live and Running!!!!";
    }

    /**
     * Create / duplicate a Campaign
     */
    @PostMapping(value = "/create")
    public ResponseEntity<ResponseDto<Campaign>> createCampaign (
            @RequestParam(required = false) MultipartFile video, @RequestParam(required = false) MultipartFile image,
            @RequestParam MultiValueMap<String, String> params
            ) throws ParseException, IOException {

        // Set the time zone
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
        TimeZone timeZone = TimeZone.getTimeZone(defaultTimezone);
        simpleDateFormat.setTimeZone(timeZone);

        HashMap<String, MultipartFile> filesMap = new HashMap<>();
        // check and add the video to filesMap
        if(video != null) {
            //checking the size of file
            if(video.getSize() > Constants.FILE_SIZE) {
                throw new FileSizeException(String.format(Constants.FILE_SIZE_ERROR, "video"), ErrorCodeConstants.INTERNAL_SERVER_ERROR);
            }
            filesMap.put(Constants.VIDEO, video);
        }
        // check and add the image to filesMap
        if(image != null) {
            //checking the size of file
            if (image.getSize() > Constants.FILE_SIZE) {
                throw new FileSizeException(String.format(Constants.FILE_SIZE_ERROR, "image"), ErrorCodeConstants.INTERNAL_SERVER_ERROR);
            }
            filesMap.put(Constants.IMAGE, image);
        }

        CampaignDTO campaignDTO = new CampaignDTO();
        campaignDTO.setStatus(CommonUtility.checkNull(params.get(Constants.STATUS)));
        campaignDTO.setName(CommonUtility.checkNull(params.get(Constants.CAMPAIGN_NAME)));
        campaignDTO.setCampaignObjective(CommonUtility.checkNull(params.get(Constants.CAMPAIGN_OBJECTIVE)));
        campaignDTO.setAdvertiser(CommonUtility.checkNull(params.get(Constants.ADVERTISER)));
        campaignDTO.setCategory(CommonUtility.checkNull(params.get(Constants.CATEGORY)));
        campaignDTO.setAgency(CommonUtility.checkNull(params.get(Constants.AGENCY)));
        if(CommonUtility.checkNull(params.get(Constants.START_DATE)).length() != 0) {
            campaignDTO.setStartDate(simpleDateFormat.parse(CommonUtility.checkNull(params.get(Constants.START_DATE))));
        }
        if(CommonUtility.checkNull(params.get(Constants.END_DATE)).length() != 0) {
            campaignDTO.setEndDate(simpleDateFormat.parse(CommonUtility.checkNull(params.get(Constants.END_DATE))));
        }
        campaignDTO.setOrganizationId(CommonUtility.checkNull(params.get(Constants.ORGANIZATION_ID)));
        campaignDTO.setOrganizationName(CommonUtility.checkNull(params.get(Constants.ORGANIZATION_NAME)));
        campaignDTO.setReportingEmail(CommonUtility.checkNull(params.get(Constants.REPORTING_EMAIL)));
        campaignDTO.setDailyLimit(CommonUtility.checkNull(params.get(Constants.DAILY_LIMIT)));
        campaignDTO.setDailyLimitSpecified(CommonUtility.checkNull(params.get(Constants.DAILY_LIMIT_SPECIFIED)));
        campaignDTO.setCampaignLimit(CommonUtility.checkNull(params.get(Constants.CAMPAIGN_LIMIT)));
        campaignDTO.setCampaignLimitSpecified(CommonUtility.checkNull(params.get(Constants.CAMPAIGN_LIMIT_SPECIFIED)));
        campaignDTO.setDataPerUser(CommonUtility.checkNull(params.get(Constants.DATA_PER_USER)));
        campaignDTO.setDataPerUserSpecified(CommonUtility.checkNull(params.get(Constants.DATA_PER_USER_SPECIFIED)));
        campaignDTO.setCampaignTime(CommonUtility.checkNull(params.get(Constants.CAMPAIGN_TIME)));
        campaignDTO.setVideoUrl(CommonUtility.checkNull(params.get(Constants.VIDEO_URL)));
        campaignDTO.setImageUrl(CommonUtility.checkNull(params.get(Constants.IMAGE_URL)));
        campaignDTO.setConfirmationInterval(CommonUtility.checkNull(params.get(Constants.CONFIRMATION_INTERVAL)));
        campaignDTO.setConfirmationType(CommonUtility.checkNull(params.get(Constants.CONFIRMATION_TYPE)));

        return campaignService.createCampaign(filesMap, campaignDTO);
    }

    /**
     * Edit, Edit & Approve Campaign
     */
    @PostMapping(value = "/update")
    public ResponseEntity<ResponseDto<Campaign>> updateCampaign(
            @RequestParam(required = false) MultipartFile video, @RequestParam(required = false) MultipartFile image,
            @RequestParam MultiValueMap<String, String> params
            ) throws ParseException, IOException {

        // Set the default time zone
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
        TimeZone timeZone = TimeZone.getTimeZone(defaultTimezone);
        simpleDateFormat.setTimeZone(timeZone);

        HashMap<String, MultipartFile> filesMap = new HashMap<>();

        // check and add the video to filesMap
        if(video != null) {
            //checking the size of file
            if(video.getSize() > Constants.FILE_SIZE) {
                throw new FileSizeException(String.format(Constants.FILE_SIZE_ERROR, "video"), ErrorCodeConstants.INTERNAL_SERVER_ERROR);
            }
            filesMap.put(Constants.VIDEO, video);
        }
        // check and add the image to filesMap
        if(image != null) {
            //checking the size of file
            if (image.getSize() > Constants.FILE_SIZE) {
                throw new FileSizeException(String.format(Constants.FILE_SIZE_ERROR, "image"), ErrorCodeConstants.INTERNAL_SERVER_ERROR);
            }
            filesMap.put(Constants.IMAGE, image);
        }

        //setting the campaign object from request params
        CampaignDTO campaignDTO = new CampaignDTO();
        campaignDTO.setStatus(CommonUtility.checkNull(params.get(Constants.STATUS)));
        campaignDTO.setName(CommonUtility.checkNull(params.get(Constants.CAMPAIGN_NAME)));
        campaignDTO.setCampaignObjective(CommonUtility.checkNull(params.get(Constants.CAMPAIGN_OBJECTIVE)));
        campaignDTO.setAdvertiser(CommonUtility.checkNull(params.get(Constants.ADVERTISER)));
        campaignDTO.setCategory(CommonUtility.checkNull(params.get(Constants.CATEGORY)));
        campaignDTO.setAgency(CommonUtility.checkNull(params.get(Constants.AGENCY)));
        if(CommonUtility.checkNull(params.get(Constants.START_DATE)).length() != 0) {
            campaignDTO.setStartDate(simpleDateFormat.parse(CommonUtility.checkNull(params.get(Constants.START_DATE))));
        }
        if(CommonUtility.checkNull(params.get(Constants.END_DATE)).length() != 0) {
            campaignDTO.setEndDate(simpleDateFormat.parse(CommonUtility.checkNull(params.get(Constants.END_DATE))));
        }
        campaignDTO.setOrganizationId(CommonUtility.checkNull(params.get(Constants.ORGANIZATION_ID)));
        campaignDTO.setOrganizationName(CommonUtility.checkNull(params.get(Constants.ORGANIZATION_NAME)));
        campaignDTO.setReportingEmail(CommonUtility.checkNull(params.get(Constants.REPORTING_EMAIL)));
        campaignDTO.setDailyLimit(CommonUtility.checkNull(params.get(Constants.DAILY_LIMIT)));
        campaignDTO.setDailyLimitSpecified(CommonUtility.checkNull(params.get(Constants.DAILY_LIMIT_SPECIFIED)));
        campaignDTO.setCampaignLimit(CommonUtility.checkNull(params.get(Constants.CAMPAIGN_LIMIT)));
        campaignDTO.setCampaignLimitSpecified(CommonUtility.checkNull(params.get(Constants.CAMPAIGN_LIMIT_SPECIFIED)));
        campaignDTO.setDataPerUser(CommonUtility.checkNull(params.get(Constants.DATA_PER_USER)));
        campaignDTO.setDataPerUserSpecified(CommonUtility.checkNull(params.get(Constants.DATA_PER_USER_SPECIFIED)));        campaignDTO.setCampaignTime(CommonUtility.checkNull(params.get(Constants.CAMPAIGN_TIME)));
        campaignDTO.setId(CommonUtility.checkNull(params.get(Constants.ID)));
        campaignDTO.setVideoUrl(CommonUtility.checkNull(params.get(Constants.VIDEO_URL)));
        campaignDTO.setImageUrl(CommonUtility.checkNull(params.get(Constants.IMAGE_URL)));
        campaignDTO.setConfirmationInterval(CommonUtility.checkNull(params.get(Constants.CONFIRMATION_INTERVAL)));
        campaignDTO.setConfirmationType(CommonUtility.checkNull(params.get(Constants.CONFIRMATION_TYPE)));

        // action value can be 'approve' or 'edit' a campaign
        String action = CommonUtility.checkNull(params.get(Constants.ACTION));

        return campaignService.updateCampaign(filesMap, campaignDTO, action);
    }

    /**
     * Approve / stop / resume campaign details
     */
    @GetMapping(value = "/{status}/{campaignId}")
    public ResponseEntity<ResponseDto<Campaign>> updateCampaignStatus(@PathVariable String campaignId, @PathVariable String status) {
		return campaignService.updateCampaignStatus(campaignId, status);
    }

    /**
     * Fetch the campaign details from the mysql DB
     */
    @GetMapping(value = "/ad/{campaignId}")
    public ResponseEntity<ResponseDto<Campaign>> getCampaign(@PathVariable String campaignId) {
        return campaignService.getCampaignById(campaignId);
    }

    /**
     * Fetch the campaigns based on status and organizationID
     */
    @GetMapping(value = "/{status}")
    public ResponseEntity<ResponseDto<List<Campaign>>> getAllCampaigns(@PathVariable String status, @RequestHeader String organizationId) {
        return campaignService.getAllCampaigns(status, organizationId);
    }

    /**
     * Fetch all the campaign ads from s3
     */
    @GetMapping(value = "/assets")
    public ResponseEntity<ResponseDto<HashMap<String, List<String>>>> getExistingAssets(
            @RequestHeader String organizationId, @RequestHeader String organizationName) {
        return campaignService.getExistingAssets(organizationId, organizationName);
    }

    /**
     * Fetching all the campaigns from adlist table
     */
    @GetMapping(value = "/ads/{organizationId}/{iuGuid}")
    public ResponseEntity<ResponseDto<List<AdListResponse>>> getActiveCampaigns(@PathVariable String organizationId, @PathVariable String iuGuid) {
        Organization org = organizationRepository.findById(organizationId);
        return carrierRegistry.getServiceBean(org.getName()).getEligibleCampaigns(organizationId, iuGuid);
    }

    /**
     * verify duplication of campaign name
     */
    @GetMapping(value = "/verify/{campaignName}")
    public ResponseEntity<ResponseDto<Campaign>> checkCampaignName(@PathVariable String campaignName) {
        return campaignService.checkCampaignName(campaignName);
    }

    /**
     * Upload the file to resource folder and return the same
     * @return
     */
    @PostMapping("/echoAssets")
    public ResponseEntity<ResponseDto<CacheAssetsResponse>> cacheAssets(@RequestParam(required = false) MultipartFile file,
                                                                        @RequestParam(required = false) String fileUrl,
                                                                        @RequestParam String campaignName,
                                                                        @RequestParam String fileType) throws IOException {

        return campaignService.storeFile(file, fileUrl, campaignName, fileType);
    }

    @GetMapping(value = "/assets/{fileName}")
    public void getAssetsFromResources(HttpServletResponse response, @PathVariable String fileName) throws IOException {

        FileSystemResource file = new FileSystemResource("./assets/" + fileName);
        StreamUtils.copy(file.getInputStream(), response.getOutputStream());
    }
}





