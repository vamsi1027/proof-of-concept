package com.iu.rewardsapi.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="likes")
@Data
public class Likes implements Serializable {

    @Id
    @GeneratedValue
    private long id;

    @Column(columnDefinition = "varchar(255) not null default 'NA'")
    private String iuGuid = "NA";

    @Column(columnDefinition = "varchar(255) not null default 'NA'")
    private String organizationId = "NA";

    @Column(columnDefinition = "varchar(255) not null")
    private String campaignId;

    @Transient
    private long totalLikes;

    @Column(columnDefinition = "boolean null default false")
    private boolean isLiked = false;

    @Column(columnDefinition = "bigint null default 0")
    private long dateTime = 0;
}
