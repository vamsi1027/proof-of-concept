package com.iu.rewardsapi.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AdListResponse {

    private long id;
    private String organizationId;
    private String status;
    private String videoURL;
    private String imageURL;
    private String adType;
    private Boolean claimed;
    private Long expiresAt;
    private String confirmationInterval;
    private String confirmationType;
    private Integer rewardDisplay;
    private String dataPerUserSpecified;
    private String dataPerUser;
    private long totalLikes;
    private long totalClaimed;
    private Boolean redeemed;
    private Boolean like;

}
