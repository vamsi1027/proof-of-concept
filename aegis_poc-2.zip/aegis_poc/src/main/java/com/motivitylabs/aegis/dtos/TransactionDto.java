package com.motivitylabs.aegis.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionDto {

    private String transactionGuid;
    private String accountGuid;
    private String accountId;
    private String transactionId;
    private String category;
    private String merchantGuid;
    private String type;
    private Double amount;
    private String status;
    private LocalDateTime updatedAt;
    private LocalDate date;
}