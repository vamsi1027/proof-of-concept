package com.motivitylabs.aegis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.motivitylabs.aegis.entities.Transaction;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ListTransactionResponse {

    @JsonProperty("transactions")
    private List<Transaction> transactionList;

    @JsonProperty(value = "pagination")
    private Pagination pagination;
}