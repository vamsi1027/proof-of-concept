package com.motivitylabs.aegis.dtos;

import com.motivitylabs.aegis.entities.Member;
import com.motivitylabs.aegis.entities.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.modelmapper.ModelMapper;

import java.util.HashSet;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
    private String email;
    private String firstName;
    private String lastName;
    private String mobileNumber;
    private String address;
    private String aggregator;
    private Set<MemberDto> memberDto;

    public static UserDto convertToUserDto(User user) {
        ModelMapper mapper = new ModelMapper();
        UserDto userDto = mapper.map(user, UserDto.class);
        Set<MemberDto> memberDtoSet = new HashSet<>();
        if (user.getMembers() != null) {
            for (Member member : user.getMembers()) {
                memberDtoSet.add(mapper.map(member, MemberDto.class));
            }
        }
        userDto.setMemberDto(memberDtoSet);
        return userDto;
    }
}