package com.motivitylabs.aegis.controller;

import com.motivitylabs.aegis.dtos.ErrorResponseDto;
import com.motivitylabs.aegis.service.InstitutionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/institutions")
public class InstitutionController {

    private static final Logger LOGGER = LoggerFactory.getLogger(InstitutionController.class);
    @Autowired
    private InstitutionService institutionService;

    @Operation(
            summary = "List of Institutions",
            description = "Returns a list of institutions"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @GetMapping("/list-institutions")
    public ResponseEntity listInstitutions() throws Exception {
        LOGGER.info("Fetching all institution details from MX");
        return ResponseEntity.ok(institutionService.getListOfInstitutions());
    }
}