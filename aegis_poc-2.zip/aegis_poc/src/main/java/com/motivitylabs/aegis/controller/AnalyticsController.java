package com.motivitylabs.aegis.controller;

import com.motivitylabs.aegis.dtos.AccountAnalyticsDto;
import com.motivitylabs.aegis.dtos.ErrorResponseDto;
import com.motivitylabs.aegis.dtos.TransactionAnalyticsDto;
import com.motivitylabs.aegis.service.AnalyticsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/analytics")
public class AnalyticsController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AnalyticsController.class);
    @Autowired
    private AnalyticsService analyticsService;

    @Operation(
            summary = "Accounts of User",
            description = "Return accounts for a particular user"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @GetMapping("/{email}/accounts")
    public ResponseEntity accountsAnalytics(@PathVariable("email") String email) throws Exception {
        LOGGER.info("Fetching analytics details of accounts for a user :{}", email);
        AccountAnalyticsDto accountAnalyticsDto = analyticsService.accountsAnalytics(email);
        if (accountAnalyticsDto == null) {
            return ResponseEntity.ok("Empty");
        }
        return ResponseEntity.ok(analyticsService.accountsAnalytics(email));
    }

    @Operation(
            summary = "Transaction Analytics of User",
            description = "Returns analytics of transactions of particular user"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @GetMapping("/{email}/transactions")
    public ResponseEntity transactionAnalytics(
            @PathVariable("email") String email,
            @RequestParam(required = false, value = "from_date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam(required = false, value = "to_date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
            @RequestParam(required = false, value = "accountGuid") String accountGuid
    ) throws Exception {
        LOGGER.info("Fetching analytics details of Transactions for a user :{}", email);
        List<TransactionAnalyticsDto> transactionAnalyticsDtoList = analyticsService.transactionAnalytics(email, fromDate, toDate, accountGuid);
        if (transactionAnalyticsDtoList.size() > 0) {
            return ResponseEntity.ok(transactionAnalyticsDtoList);
        } else {
            return ResponseEntity.ok("Empty");
        }
    }

}