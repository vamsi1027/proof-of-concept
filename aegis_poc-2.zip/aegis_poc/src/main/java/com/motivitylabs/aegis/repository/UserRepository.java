package com.motivitylabs.aegis.repository;

import com.motivitylabs.aegis.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * User Repository class used to connect to User Table
 *
 * @Authors Vishal Kumar, RamaTeja
 */
@Repository
public interface UserRepository extends JpaRepository<User, String> {
    User findByEmail(String email);
}
