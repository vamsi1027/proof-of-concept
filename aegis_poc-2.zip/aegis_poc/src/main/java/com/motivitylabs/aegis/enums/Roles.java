package com.motivitylabs.aegis.enums;

public enum Roles {
    USER,
    ADMIN
}
