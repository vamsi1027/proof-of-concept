package com.motivitylabs.aegis.service;

import com.motivitylabs.aegis.entities.Member;
import com.motivitylabs.aegis.model.MemberStatusResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class MemberStatusService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MemberStatusService.class);
    @Autowired
    private MxApiService mxApiService;

    @Autowired
    private MemberService memberService;

    @Autowired
    private AccountService accountService;

    @Autowired
    private TransactionService transactionService;

    @Async
    public void checkMemberStatus(String userGuid, String memberGuid) throws Exception {
        LOGGER.info("Started Executing Thread: {}", Thread.currentThread().getName());
        LOGGER.info("Checking member status for userGuid:{} and memberGuid:{}", userGuid, memberGuid);
        MemberStatusResponse memberStatusResponse;
        do {
            memberStatusResponse = mxApiService.readMemberStatus(userGuid, memberGuid);
            Thread.sleep(2000);
        } while (memberStatusResponse.getMemberStatus().isBeingAggregated());

        //update memberStatus in db
        memberService.updateMemberStatusInDB(memberStatusResponse);

        //fetch accounts and store in db
        accountService.fetchAccountsFromMx(userGuid);

        //fetch transactions and store in db
        transactionService.fetchTransactionsFromMx(userGuid);
        LOGGER.info("Completed Executing Thread: {}", Thread.currentThread().getName());
    }

    @Async
    public void triggerAggregationInAsync(String userGuid, String memberGuid) throws Exception {
        LOGGER.info("Started Executing Thread: {}", Thread.currentThread().getName());
        //check member status and update database
        MemberStatusResponse memberStatusResponse = mxApiService.readMemberStatus(userGuid, memberGuid);
        Member member = memberService.updateMemberStatusInDB(memberStatusResponse);

        LOGGER.info("Starting aggregation for userGuid:{} and memberGuid:{}", userGuid, memberGuid);
        //Start aggregation
        mxApiService.aggregateMember(userGuid, memberGuid);

        LOGGER.info("Completed aggregation for userGuid:{} and memberGuid:{}", userGuid, memberGuid);

        //Async operation check member status and update accounts and transactions in DB
        checkMemberStatus(userGuid, memberGuid);

        LOGGER.info("Completed Executing Thread: {}", Thread.currentThread().getName());
    }
}