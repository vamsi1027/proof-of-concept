package com.motivitylabs.aegis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.motivitylabs.aegis.entities.Account;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ListAccountResponse {

    @JsonProperty(value = "accounts")
    private List<Account> accountList;

    @JsonProperty(value = "pagination")
    private Pagination pagination;
}
