package com.motivitylabs.aegis.repository;

import com.motivitylabs.aegis.entities.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MemberRepository extends JpaRepository<Member, String> {

    List<Member> findByMembersEmail(String email);

    List<Member> findByUserGuid(String userGuid);

    @Query("SELECT COUNT(DISTINCT m.userGuid) FROM Member m")
    long getTotalUsersCount();

    @Query("SELECT COUNT(m.memberGuid) FROM Member m")
    long getTotalMembersCount();
}
