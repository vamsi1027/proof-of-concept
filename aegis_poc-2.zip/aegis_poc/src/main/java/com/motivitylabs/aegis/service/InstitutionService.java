package com.motivitylabs.aegis.service;

import com.motivitylabs.aegis.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class InstitutionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(InstitutionService.class);
    @Autowired
    private MxApiService mxApiService;

    @Cacheable(cacheNames = "institutionList")
    public List<MxInstitution> getListOfInstitutions() throws Exception {
        LOGGER.info("Fetching list of institutions");
        List<MxInstitution> institutionList = new ArrayList<>();
        ListInstitutionResponse response;
        int currentPage = 1;
        do {
            response = mxApiService.listInstitutions(1);
            if (!response.getInstitutionsList().isEmpty()) {
                institutionList.addAll(response.getInstitutionsList());
            }
            currentPage++;
        } while (currentPage <= response.getPagination().getTotalPages());
        return institutionList;
    }

    public List<InstitutionRequiredCredential> getInstitutionCredentials(String institutionCode) throws Exception {
        ListInstitutionRequiredCredentialResponse response = mxApiService.listInstitutionCredentials(institutionCode);
        return response.getCredentialsList();
    }
}
