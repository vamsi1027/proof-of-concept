package com.motivitylabs.aegis.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

/**
 * WebClient Configuration class for Webclient and Logging Request and Response
 *
 * @Authors Vishal Kumar, Rama Teja
 */
@Configuration
public class WebClientConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(WebClientConfiguration.class);

    @Value("${mx.auth.value}")
    private String auth;

    private static final String MX_BASE_URL= "https://int-api.mx.com";

    @Bean("mxWebClient")
    WebClient getMxWebClient() {
        return WebClient
                .builder()
                .filters(exchangeFilterFunctions -> {
                    exchangeFilterFunctions.add(logRequest());
                    exchangeFilterFunctions.add(logResponse());
                })
                .baseUrl(MX_BASE_URL)
                .defaultHeaders(httpHeaders -> {
                    httpHeaders.add(HttpHeaders.AUTHORIZATION, "Basic " + auth);
                    httpHeaders.add(HttpHeaders.ACCEPT, MediaType.valueOf("application/vnd.mx.api.v1+json").toString());
                    httpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
                })
                /*
                Codecs have limits for buffering data in memory. By default, those are set to 256KB.
                If Date is more than default limit which is 256KB it will throw
                org.springframework.core.io.buffer.DataBufferLimitException.
                To avoid that we are setting it to unlimited size
                */
                .exchangeStrategies(ExchangeStrategies.builder()
                        .codecs(clientCodeConfigure ->
                                clientCodeConfigure
                                        .defaultCodecs()
                                        .maxInMemorySize(- 1) // -1 indicates unlimited memory size
                        ).build())
                .build();
    }

    private ExchangeFilterFunction logRequest() {
        return ExchangeFilterFunction.ofRequestProcessor(clientRequest -> {
            LOGGER.info("MX API Request: Method: {}, URL: {}", clientRequest.method(), clientRequest.url());
            return Mono.just(clientRequest);
        });
    }

    private ExchangeFilterFunction logResponse() {
        return ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
            LOGGER.info("MX API Response: HTTP Status: {}", clientResponse.statusCode());
            return Mono.just(clientResponse);
        });
    }
}