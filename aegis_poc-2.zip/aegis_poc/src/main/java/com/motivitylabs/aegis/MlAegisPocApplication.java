package com.motivitylabs.aegis;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeIn;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Main application class for MlAegisPocApplication
 *
 * @Authors Vishal Kumar, RamaTeja
 */
@EnableAsync
@EnableCaching
@SpringBootApplication
public class MlAegisPocApplication {
    public static void main(String[] args) {
        SpringApplication.run(MlAegisPocApplication.class, args);
    }
}