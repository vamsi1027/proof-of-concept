package com.motivitylabs.aegis.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.motivitylabs.aegis.dtos.ErrorResponseDto;
import com.motivitylabs.aegis.dtos.RegisterUserDto;
import com.motivitylabs.aegis.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/user")
public class UserController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @Operation(
            summary = "Registration",
            description = "Registration for a user"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @PostMapping("/register")
    public ResponseEntity registerUser(@RequestBody RegisterUserDto registerUserDto) throws Exception {
        try {
            LOGGER.info("Registering a new user for email: {}", registerUserDto.getEmail());
            userService.registerUser(registerUserDto);
        } catch (Exception e) {
            if (e.getMessage().equalsIgnoreCase(UserService.USER_ALREADY_REGISTERED)) {
                LOGGER.error("User already registered for email:{}", registerUserDto.getEmail());
                return new ResponseEntity(e.getMessage(), HttpStatus.CONFLICT);
            } else {
                throw e;
            }
        }
        return new ResponseEntity("created", HttpStatus.CREATED);
    }

    @Operation(
            summary = "To get user details by Email",
            description = "Returns all details of user along with Member details"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @PostMapping("/find-by-email/{email}")
    public ResponseEntity getUserByEmail(@PathVariable("email") String email) throws Exception {
        LOGGER.info("Fetching user details for email:{}", email);
        return ResponseEntity.ok(userService.findByEmail(email));
    }


    @GetMapping("/add-user-from-mx")
    public ResponseEntity fetchAndAddUserFromMx(@RequestParam("userGuid") String userGuid, @RequestParam("email") String email) throws Exception {
        return ResponseEntity.ok(userService.fetchAndAddUserFromMx(userGuid, email));
    }

    @GetMapping("/ping")
    public String isLive() {
        return "Yes, Service is up and running!";
    }
}