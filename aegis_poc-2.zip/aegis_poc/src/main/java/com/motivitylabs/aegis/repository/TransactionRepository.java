package com.motivitylabs.aegis.repository;

import com.motivitylabs.aegis.dtos.TransactionAnalyticsDto;
import com.motivitylabs.aegis.entities.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Transaction Repository class used to connect to Transaction Table
 *
 * @Authors Vishal Kumar, RamaTeja
 */
@Repository
public interface TransactionRepository extends JpaRepository<Transaction, String> {

    /**
     * This method returns the list of Transactions based on userGuid
     *
     * @param userGuid
     * @return List<Transaction>
     */
    List<Transaction> getByUserGuid(String userGuid);

    /**
     * This method returns the Latest Transaction Date for Particular UserGuid
     *
     * @param userGuid
     * @return LocalDate
     */
    @Query("SELECT MAX(t.date) "
            + "FROM Transaction t "
            + "WHERE t.userGuid = :userGuid")
    LocalDate getLatestTransactionDateByUserGuid(@Param("userGuid") String userGuid);

    @Query("SELECT new com.motivitylabs.aegis.dtos.TransactionAnalyticsDto(t.category, SUM(t.amount)) "
            + "FROM Transaction t "
            + "WHERE (t.date between :fromDate  and :toDate) and (t.userGuid = :userGuid) and (:accountGuid IS NULL OR t.accountGuid = :accountGuid)"
            + "GROUP BY t.category")
    List<TransactionAnalyticsDto> getTransactionAnalytics(
            @Param("userGuid") String userGuid,
            @Param("fromDate") LocalDate fromDate,
            @Param("toDate") LocalDate toDate,
            @Param("accountGuid") String accountGuid
    );

    List<Transaction> findByUserGuidAndMemberGuid(String userGuid, String memberGuid);
}
