package com.motivitylabs.aegis.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Member {

    @Id
    private String memberGuid;
    private String userGuid;
    private String institutionCode;
    private String institutionName;
    private boolean isBeingAggregated;
    private boolean isManagedByUser;
    private LocalDateTime successfullyAggregatedAt;
    private LocalDateTime aggregatedAt;
    private String connectionStatus;
    @Column(name = "members_email")
    private String membersEmail;
}