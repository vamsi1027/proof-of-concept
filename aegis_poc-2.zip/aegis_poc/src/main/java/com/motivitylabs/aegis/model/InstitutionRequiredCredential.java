package com.motivitylabs.aegis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InstitutionRequiredCredential {

    @JsonProperty("field_name")
    private String fieldName;

    @JsonProperty("guid")
    private String guid;

    @JsonProperty("label")
    private String label;

    @JsonProperty("display_order")
    private int displayOrder;

    @JsonProperty("field_type")
    private String fieldType;

    @JsonProperty("type")
    private String type;
}