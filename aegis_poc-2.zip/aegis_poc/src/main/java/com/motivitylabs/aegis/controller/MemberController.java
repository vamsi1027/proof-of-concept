package com.motivitylabs.aegis.controller;

import com.motivitylabs.aegis.dtos.CreateMemberDto;
import com.motivitylabs.aegis.dtos.ErrorResponseDto;
import com.motivitylabs.aegis.dtos.UserDto;
import com.motivitylabs.aegis.service.MemberService;
import com.motivitylabs.aegis.service.MemberStatusService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/member")
public class MemberController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MemberController.class);
    @Autowired
    private MemberService memberService;

    @Autowired
    private MemberStatusService memberStatusService;

    @Operation(
            summary = "Creates a Member",
            description = "Registers a member for a user"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @PostMapping("/create")
    public ResponseEntity createMember(@RequestBody CreateMemberDto createMemberDto) throws Exception {
        LOGGER.info("Creating a member for institution:{} for user:{}", createMemberDto.getInstitutionCode(), createMemberDto.getEmail());
        if (createMemberDto.isOauth()) {
            return ResponseEntity.ok(memberService.createMemberWithOauth(createMemberDto));
        } else {
            UserDto user = memberService.createMemberWithCredentials(createMemberDto);
            return ResponseEntity.ok(user);
        }
    }

    @Operation(
            summary = "",
            description = ""
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @GetMapping("/check-oauth-status/{email}")
    public ResponseEntity checkOauthMemberStatus(@PathVariable("email") String email, @RequestParam("member_guid") String memberGuid, @RequestParam("status") String status) throws Exception {
        UserDto userDto = null;
        LOGGER.info("Checking member status");
        if (status.equalsIgnoreCase("success")) {
            userDto = memberService.updateOauthMemberToDataBase(memberGuid, email);
            return ResponseEntity.ok(userDto);
        } else {
            memberService.removeMember(memberGuid);
            return new ResponseEntity(status, HttpStatus.UNAUTHORIZED);
        }
    }

    @Operation(
            summary = "To update Member",
            description = "Updates member credentials for particular user"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @PutMapping("/update")
    public ResponseEntity updateMember(@RequestBody CreateMemberDto createMemberDto) throws Exception {
        LOGGER.info("Updating credentials of a particular user:{}", createMemberDto.getEmail());
        memberService.updateMemberCredentials(createMemberDto);
        return new ResponseEntity(HttpStatus.OK);
    }

    @DeleteMapping("/delete/{memberGuid}")
    public ResponseEntity removeMember(@PathVariable("memberGuid") String memberGuid) throws Exception {
        memberService.removeMember(memberGuid);
        return ResponseEntity.ok("Successfully deleted member");
    }
}