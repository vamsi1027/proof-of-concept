package com.motivitylabs.aegis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MxInstitution {

    @JsonProperty("code")
    private String institutionCode;

    @JsonProperty("name")
    private String institutionName;

    @JsonProperty("instructional_text")
    private String instructionalText;

    @JsonProperty("medium_logo_url")
    private String mediumLogoUrl;

    @JsonProperty("small_logo_url")
    private String smallLogoUrl;

    @JsonProperty("url")
    private String institutionUrl;

    @JsonProperty("supports_account_identification")
    private boolean supportsAccountIdentification;

    @JsonProperty("supports_account_statement")
    private boolean supportsAccountStatement;

    @JsonProperty("supports_account_verification")
    private boolean supportsAccountVerification;

    @JsonProperty("supports_oauth")
    private boolean supportsOauth;

    @JsonProperty("supports_transaction_history")
    private boolean supportsTransactionHistory;
}