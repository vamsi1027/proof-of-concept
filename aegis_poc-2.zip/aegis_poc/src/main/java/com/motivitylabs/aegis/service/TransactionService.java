package com.motivitylabs.aegis.service;

import com.motivitylabs.aegis.dtos.TransactionDto;
import com.motivitylabs.aegis.entities.Transaction;
import com.motivitylabs.aegis.model.ListTransactionResponse;
import com.motivitylabs.aegis.repository.TransactionRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * TransactionService class
 *
 * @Authors Vishal Kumar, RamaTeja
 */
@Service
public class TransactionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransactionService.class);

    @Autowired
    private MxApiService mxApiService;

    @Autowired
    private TransactionRepository transactionRepository;

    /**
     * This method is used to fetch the list of transactions from MX API for particular userGuid and stores it in Database
     * @param userGuid
     * @return String
     * @throws Exception
     */
    public String fetchTransactionsFromMx(String userGuid) throws Exception {

        // Fetching Latest transaction date from Database
        LocalDate lastTransactionDate = transactionRepository.getLatestTransactionDateByUserGuid(userGuid);

        int currentPage = 1;
        ListTransactionResponse transactionResponse = null;
        List<Transaction> transactionList = new ArrayList<>();

        do {
            try {
                transactionResponse = mxApiService.listTransactionsByUserGuid(userGuid, currentPage, lastTransactionDate);
                LOGGER.info("Response Received from MX Transactions API for user: {}, currentPage: {}, totalPages: {} ", userGuid, currentPage, transactionResponse.getPagination().getTotalPages());
            } catch (Exception e) {
                LOGGER.error("Exception MX Transactions API for user: {} message: {}", userGuid, e.getMessage());
                throw e;
            }
            if (! transactionResponse.getTransactionList().isEmpty()) {
                transactionList.addAll(transactionResponse.getTransactionList());
            }
            currentPage++;
        } while (currentPage <= transactionResponse.getPagination().getTotalPages());

        List<Transaction> result = null;
        if (! transactionList.isEmpty()) {
            LOGGER.info("Saving Transactions in DB for userGuid: {}", userGuid);
            result = transactionRepository.saveAll(transactionList);
            LOGGER.info("Successfully Saved Transactions in DB for userGuid: {}", userGuid);
        }

        if (result != null) return "success";
        else return "failed";
    }

    /**
     * This method is used to retrieve the records from Database for particular userGuid
     * @param userGuid
     * @return List<TransactionDto>
     */
    public List<TransactionDto> getListOfTransactions(String userGuid) throws Exception {
        LOGGER.info("Loading transactions from DB for userGuid: {}", userGuid);
        List<Transaction> transactionList = transactionRepository.getByUserGuid(userGuid);

        ModelMapper mapper = new ModelMapper();
        List<TransactionDto> transactionDtoList = new ArrayList<>();
        for (Transaction transaction : transactionList) {
            TransactionDto transactionDto = mapper.map(transaction, TransactionDto.class);
            transactionDtoList.add(transactionDto);
        }
        LOGGER.info("Successfully Loaded transactions from DB for userGuid: {}", userGuid);
        return transactionDtoList;
    }

    public List<TransactionDto> getListOfTransactionsForUserAndMember(String userGuid, String memberGuid) throws Exception {
        LOGGER.info("Loading transactions from DB for userGuid: {} and memberGuid: {}", userGuid, memberGuid);
        List<Transaction> transactionList = transactionRepository.findByUserGuidAndMemberGuid(userGuid, memberGuid);

        ModelMapper mapper = new ModelMapper();
        List<TransactionDto> transactionDtoList = new ArrayList<>();
        for (Transaction transaction : transactionList) {
            TransactionDto transactionDto = mapper.map(transaction, TransactionDto.class);
            transactionDtoList.add(transactionDto);
        }
        LOGGER.info("Successfully Loaded transactions from DB for userGuid: {} and memberGuid: {}", userGuid, memberGuid);
        return transactionDtoList;
    }
}
