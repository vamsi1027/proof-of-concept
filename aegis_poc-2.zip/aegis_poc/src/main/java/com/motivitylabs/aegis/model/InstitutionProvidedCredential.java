package com.motivitylabs.aegis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InstitutionProvidedCredential {

    @JsonProperty("guid")
    private String guid;

    @JsonProperty("value")
    private String value;
}
