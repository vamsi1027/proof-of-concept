package com.motivitylabs.aegis.entities;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "userTable")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    private String email;
    private String password;
    private String firstName;
    private String lastName;
    private boolean isOauth;
    private String mobileNumber;
    @Column(length = 1000)
    private String address;
    private String roles;
    private String aggregator;
    private String relationship;
    private String relationshipId;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn
    private Set<Member> members;

    public Set<String> getRoles() {
        return convertStringToSet(roles);
    }

    public void setRoles(Set<String> roles) {
        this.roles = convertSetToString(roles);
    }

    public String convertSetToString(Set<String> roles) {
        String json;
        try {
            json = new ObjectMapper().writeValueAsString(roles);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return json;
    }

    public Set<String> convertStringToSet(String roles) {
        Set<String> roleSet;
        try {
            roleSet = new ObjectMapper().readValue(roles, Set.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return roleSet;
    }
}