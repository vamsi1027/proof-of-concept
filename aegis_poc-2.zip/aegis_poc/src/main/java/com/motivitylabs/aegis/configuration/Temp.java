package com.motivitylabs.aegis.configuration;

import com.motivitylabs.aegis.model.ListUserResponse;
import com.motivitylabs.aegis.model.MxUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import javax.annotation.PostConstruct;

@Component
public class Temp {

    @Autowired
    @Qualifier("mxWebClient")
    private WebClient mxWebClient;

    //@PostConstruct
    public void delete() {
        ListUserResponse users = mxWebClient
                .get()
                .uri(uriBuilder -> uriBuilder.path("/users")
                        .queryParam("records_per_page", 100)
                        .build())
                .retrieve()
                .bodyToMono(ListUserResponse.class)
                .block();
        System.out.println("Total Users: " + users.getUsers().size());
        int size = users.getUsers().size();
        for (MxUser mxUser : users.getUsers()) {
            mxWebClient
                    .delete()
                    .uri(uriBuilder -> uriBuilder.path("/users/{userGuid}").build(mxUser.getUserGuid()))
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();
            System.out.println("Deleted User: " + size + "  " + mxUser.getUserGuid());
            size--;
        }
    }
}
