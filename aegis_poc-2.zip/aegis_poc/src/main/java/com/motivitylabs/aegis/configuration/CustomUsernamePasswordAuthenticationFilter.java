package com.motivitylabs.aegis.configuration;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.motivitylabs.aegis.dtos.RegisterUserDto;
import com.motivitylabs.aegis.dtos.UserDto;
import com.motivitylabs.aegis.entities.User;
import com.motivitylabs.aegis.model.LoginResponse;
import com.motivitylabs.aegis.service.UserService;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Custom class to accept the UserName and Password in Json Format for UsernamePasswordAuthentication
 * we are also overriding the successful and unsuccessful authentication methods to return our custom response
 *
 * @Authors Vishal Kumar, RamaTeja
 */
public class CustomUsernamePasswordAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomUsernamePasswordAuthenticationFilter.class);

    private AuthenticationManager authenticationManager;
    private UserService userService;

    CustomUsernamePasswordAuthenticationFilter(AuthenticationManager authenticationManager, UserService userService) {
        this.authenticationManager = authenticationManager;
        this.userService = userService;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException {

        boolean isOauth = Boolean.parseBoolean(request.getHeader("isOauth"));

        try {
            BufferedReader reader = request.getReader();
            StringBuffer sb = new StringBuffer();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            String parsedReq = sb.toString();
            if (parsedReq != null) {
                ObjectMapper mapper = new ObjectMapper();

                if (isOauth) {
                    OAuthRequest oAuthRequest = mapper.readValue(parsedReq, OAuthRequest.class);
                    User user = userService.findByEmailForFilter(oAuthRequest.getEmail());

                    if (user == null) {
                        RegisterUserDto registerUserDto = new RegisterUserDto();
                        registerUserDto.setEmail(oAuthRequest.getEmail());
                        registerUserDto.setFirstName(oAuthRequest.getFirstName());
                        registerUserDto.setLastName(oAuthRequest.getLastName());
                        UserDto result = userService.registerUser(registerUserDto);
                        user = userService.findByEmailForFilter(result.getEmail());
                    }

                    Set<String> roles = user.getRoles();
                    List<SimpleGrantedAuthority> authorities = new ArrayList<>();
                    for (String role : roles) {
                        authorities.add(new SimpleGrantedAuthority("ROLE_" +role));
                    }

                    return new UsernamePasswordAuthenticationToken(user.getEmail(), null, authorities);

                } else {
                    UserNamePasswordAuthenticationRequest authReq = mapper.readValue(parsedReq, UserNamePasswordAuthenticationRequest.class);
                    return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authReq.getUserName(), authReq.getPassword()));
                }
            }
        } catch (Exception e) {
            if (e instanceof JsonProcessingException | e instanceof JsonMappingException | e instanceof JsonParseException) {
                LOGGER.error("Failed to parse authentication request body");
                throw new InternalAuthenticationServiceException("Failed to parse authentication request body");
            }
            LOGGER.error("Invalid Credentials: " + e.getMessage());
            throw new InternalAuthenticationServiceException(e.getMessage());
        }
        return null;
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authResult) throws IOException {
        SecurityContextHolder.getContext().setAuthentication(authResult);
        response.setStatus(HttpServletResponse.SC_OK);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(new ObjectMapper().writeValueAsString(new LoginResponse(true, authResult.getAuthorities())));
    }

    @Override
    protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException {
        SecurityContextHolder.getContext().setAuthentication(null);
        LOGGER.info("Failed to login: {}", failed.getMessage());
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().print(new ObjectMapper().writeValueAsString(new LoginResponse(false, null)));
    }

    @Data
    public static class OAuthRequest {
        private String email;
        private String firstName;
        private String lastName;
    }

    @Data
    public static class UserNamePasswordAuthenticationRequest {
        String userName;
        String password;
    }
}