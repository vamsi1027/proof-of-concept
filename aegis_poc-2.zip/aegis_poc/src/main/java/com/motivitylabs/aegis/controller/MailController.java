package com.motivitylabs.aegis.controller;

import com.motivitylabs.aegis.dtos.ChatDetailsDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;


@RestController
@RequestMapping("/mail")
public class MailController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MailController.class);

    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    private String sendTo;



    @PostMapping("/chat")
    private ResponseEntity sendEmailToUser(@RequestBody ChatDetailsDto chatDetails) throws MessagingException, UnsupportedEncodingException {
        LOGGER.info("Sending an email to user:{}", chatDetails.getEmail());
        SimpleMailMessage mailMessage = new SimpleMailMessage();
        mailMessage.setTo(chatDetails.getEmail());
        mailMessage.setText("Hi " + chatDetails.getName() + '\n' + "We have received your query, we are working on it!!" +'\n'+" Thanks " );
        mailMessage.setSubject("Received your message");
        javaMailSender.send(mailMessage);
        sendEmailToAdmin(chatDetails);
        return ResponseEntity.ok("success");
    }

    private void sendEmailToAdmin(ChatDetailsDto chatDetails) throws MessagingException, UnsupportedEncodingException {
        LOGGER.info("Sending an email to admin");
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
        mimeMessageHelper.setTo(sendTo);
        mimeMessageHelper.setText("Hi Admin" + '\n' + chatDetails.getMessage() +'\n'+"Received from "+ chatDetails.getEmail());
        mimeMessageHelper.setFrom(new InternetAddress(sendTo,chatDetails.getEmail()));
        javaMailSender.send(mimeMessageHelper.getMimeMessage());
    }


}
