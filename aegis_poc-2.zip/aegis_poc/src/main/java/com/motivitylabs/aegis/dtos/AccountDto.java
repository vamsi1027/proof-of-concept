package com.motivitylabs.aegis.dtos;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountDto {

    private String accountGuid;
    private String memberGuid;
    private String userGuid;
    private String accountId;
    private String accountNumber;
    private String accountType;
    private Double balance;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime paymentDueAt;
    private LocalDateTime lastPaymentAt;
    private String accountName;
    private String institutionCode;
}