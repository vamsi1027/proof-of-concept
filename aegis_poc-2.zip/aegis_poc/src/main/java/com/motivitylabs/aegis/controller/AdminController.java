package com.motivitylabs.aegis.controller;

import com.motivitylabs.aegis.dtos.ErrorResponseDto;
import com.motivitylabs.aegis.service.AdminService;
import com.motivitylabs.aegis.service.MemberService;
import com.motivitylabs.aegis.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);
    @Autowired
    private AdminService adminService;

    @Operation(
            summary = "List of Users",
            description = "Returns List of All Users"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @GetMapping("/users")
    public ResponseEntity getListOfUsers() throws Exception {
        LOGGER.info("Fetching all users details");
        return ResponseEntity.ok(adminService.getListOfUsers());
    }

    @Operation(
            summary = "Aggregate",
            description = "Aggregate a particular member of User"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @PostMapping("/aggregate")
    public ResponseEntity triggerAggregation(@RequestParam("userGuid") String userGuid, @RequestParam("memberGuid") String memberGuid) throws Exception {
        LOGGER.info("Starting Aggregation for memberGuid: {} ,userGuid: {}", memberGuid, userGuid);
        adminService.triggerAggregation(userGuid, memberGuid);
        return ResponseEntity.ok("success");
    }

    @Operation(
            summary = "Statistics",
            description = "Returns the stats data about Accounts , User and Members "
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @GetMapping("/stats")
    public ResponseEntity adminStats() throws Exception {
        LOGGER.info("Getting statistics details of all users");
        return ResponseEntity.ok(adminService.getStats());
    }
}
