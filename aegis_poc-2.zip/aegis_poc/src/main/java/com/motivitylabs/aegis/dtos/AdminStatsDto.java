package com.motivitylabs.aegis.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminStatsDto {

    private long totalNumberOfUsers;
    private long totalNumberOfMembers;
    private long totalNumberOfAccounts;
    private List<FinancialInstitutionAnalytics> financialInstitutionAnalytics;

}