package com.motivitylabs.aegis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemberStatusResponse {

    @JsonProperty("member")
    private MemberStatus memberStatus;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public class MemberStatus {

        @JsonProperty("guid")
        private String memberGuid;

        @JsonProperty("aggregated_at")
        private LocalDateTime aggregatedAt;

        @JsonProperty("is_being_aggregated")
        private boolean isBeingAggregated;

        @JsonProperty("successfully_aggregated_at")
        private LocalDateTime SuccessfullyAggregatedAt;

        @JsonProperty("connection_status")
        private String connectionStatus;

        @JsonProperty("is_authenticated")
        private boolean isAuthenticated;
    }
}
