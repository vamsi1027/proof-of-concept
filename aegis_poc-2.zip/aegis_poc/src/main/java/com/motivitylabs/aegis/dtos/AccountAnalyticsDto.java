package com.motivitylabs.aegis.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountAnalyticsDto {

    private int totalNoOfAccounts;
    private double totalBalanceInAllAccounts;
    private List<AccountDto> accountList;
}
