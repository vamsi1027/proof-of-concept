package com.motivitylabs.aegis.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Account {

    @Id
    @JsonProperty(value = "guid")
    private String accountGuid;

    @JsonProperty(value = "member_guid")
    private String memberGuid;

    @JsonProperty(value = "user_guid")
    private String userGuid;

    @JsonProperty(value = "id")
    private String accountId;

    @JsonProperty(value = "account_number")
    private String accountNumber;

    @JsonProperty(value = "type")
    private String accountType;

    @JsonProperty(value = "balance")
    private Double balance;

    @JsonProperty(value = "created_at")
    private LocalDateTime createdAt;

    @JsonProperty(value = "updated_at")
    private LocalDateTime updatedAt;

    @JsonProperty(value = "payment_due_at")
    private LocalDateTime paymentDueAt;

    @JsonProperty(value = "last_payment_at")
    private LocalDateTime lastPaymentAt;

    @JsonProperty(value = "institution_code")
    private String institutionCode;

    @JsonProperty(value = "name")
    private String accountName;
}