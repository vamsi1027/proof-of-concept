package com.motivitylabs.aegis.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

    @Id
    @JsonProperty(value = "guid")
    private String transactionGuid;

    @JsonProperty(value = "account_guid")
    private String accountGuid;

    @JsonProperty(value = "member_guid")
    private String memberGuid;

    @JsonProperty(value = "user_guid")
    private String userGuid;

    @JsonProperty(value = "account_id")
    private String accountId;

    @JsonProperty(value = "id")
    private String transactionId;

    @JsonProperty(value = "category")
    private String category;

    @JsonProperty(value = "merchant_guid")
    private String merchantGuid;

    @JsonProperty(value = "type")
    private String type;

    @JsonProperty(value = "updated_at")
    private LocalDateTime updatedAt;

    @JsonProperty(value = "currency_code")
    private String currencyCode;

    @JsonProperty(value = "transacted_at")
    private String transactedAt;

    @JsonProperty(value = "date")
    private LocalDate date;

    @JsonProperty(value = "is_subscription")
    private boolean isSubscription;

    @JsonProperty(value = "amount")
    private Double amount;

    @JsonProperty(value = "status")
    private String status;

    @JsonProperty(value = "description")
    private String description;

    @JsonProperty(value = "top_level_category")
    private String topLevelCategory;
}