package com.motivitylabs.aegis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MxMember {

    @JsonProperty("guid")
    private String memberGuid;

    @JsonProperty("id")
    private String memberId;

    @JsonProperty("user_guid")
    private String userGuid;

    @JsonProperty("user_id")
    private String userId;

    @JsonProperty("aggregated_at")
    private LocalDateTime aggregatedAt;

    @JsonProperty("institution_code")
    private String institutionCode;

    @JsonProperty("is_being_aggregated")
    private boolean isBeingAggregated;

    @JsonProperty("is_managed_by_user")
    private boolean isManagedByUser;

    @JsonProperty("is_oauth")
    private boolean isOauth;

    @JsonProperty("metadata")
    private String metadata;

    @JsonProperty("name")
    private String institutionName;

    @JsonProperty("successfully_aggregated_at")
    private LocalDateTime successfullyAggregatedAt;

    @JsonProperty("connection_status")
    private String connectionStatus;

    @JsonProperty("oauth_window_uri")
    private String oAuthWindowUri;
}