package com.motivitylabs.aegis.controller;

import com.motivitylabs.aegis.dtos.ErrorResponseDto;
import com.motivitylabs.aegis.service.AccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AccountController.class);
    @Autowired
    private AccountService accountService;

    @Operation(
            summary = "List of Accounts",
            description = "Returns List of All Accounts with Details"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @GetMapping("/user/{userGuid}")
    public ResponseEntity getListOfAccounts(@PathVariable("userGuid") String userGuid) {
        LOGGER.info("Fetching accounts of a userGuid:{}", userGuid);
        return ResponseEntity.ok(accountService.getListOfAccounts(userGuid));
    }

    @Operation(
            summary = "List of Accounts Of Particular User",
            description = "Returns List of All Accounts of a User and particular member"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @GetMapping("/user/{userGuid}/member/{memberGuid}")
    public ResponseEntity fetchAccountsForMember(@PathVariable("userGuid") String userGuid, @PathVariable("memberGuid") String memberGuid) {
        LOGGER.info("Fetching accounts of a userGuid:{},memberGuid:{}", userGuid, memberGuid);
        return ResponseEntity.ok(accountService.getListOfAccountsForMember(userGuid, memberGuid));
    }

    @GetMapping("/mx/user/{userGuid}")
    public ResponseEntity fetchAccountsFromMx(@PathVariable("userGuid") String userGuid) throws Exception {
        return ResponseEntity.ok(accountService.fetchAccountsFromMx(userGuid));
    }
}
