package com.motivitylabs.aegis.service;

import com.motivitylabs.aegis.dtos.AdminStatsDto;
import com.motivitylabs.aegis.dtos.FinancialInstitutionAnalytics;
import com.motivitylabs.aegis.dtos.UserDto;
import com.motivitylabs.aegis.repository.AccountRepository;
import com.motivitylabs.aegis.repository.MemberRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdminService.class);
    @Autowired
    private UserService userService;

    @Autowired
    private MemberService memberService;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private AccountRepository accountRepository;

    public List<UserDto> getListOfUsers() throws Exception {
        LOGGER.info("Fetching all users from DB");
        return userService.getListOfMLUsers();
    }

    public void triggerAggregation(String userGuid, String memberGuid) throws Exception {
        memberService.triggerAggregation(userGuid, memberGuid);
    }

    public AdminStatsDto getStats() throws Exception {
        long totalNumberOfUsers = memberRepository.getTotalUsersCount();
        long totalNumberOfMembers = memberRepository.getTotalMembersCount();
        long totalNumberOfAccounts = accountRepository.getTotalAccountsCount();
        List<FinancialInstitutionAnalytics> financialInstitutionData = accountRepository.getAccountsCountByFI();
        return new AdminStatsDto(totalNumberOfUsers, totalNumberOfMembers, totalNumberOfAccounts, financialInstitutionData);
    }
}
