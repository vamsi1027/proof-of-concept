package com.motivitylabs.aegis.service;

import com.motivitylabs.aegis.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.Optional;

/**
 * This Class is used to connect to MX APIs using webClient.
 *
 * @Authors Vishal Kumar, RamaTeja
 */
@Service
public class MxApiService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MxApiService.class);
    private static final String LIST_ACCOUNTS_BY_USER_API = "/users/{userGuid}/accounts";
    private static final String LIST_TRANSACTIONS_BY_USER_API = "/users/{userGuid}/transactions";
    private static final String LIST_INSTITUTIONS_API = "/institutions";
    private static final String LIST_INSTITUTION_CREDENTIALS_API = "/institutions/{institutionCode}/credentials";
    private static final String CREATE_USER_API = "/users";
    private static final String CREATE_MEMBER_API = "/users/{userGuid}/members";
    private static final String READ_MEMBER_DETAILS_API = "/users/{userGuid}/members/{memberGuid}";
    private static final String READ_USER_DETAILS_API = "/users/{userGuid}";
    private static final String LIST_MEMBERS_BY_USER_API = "/users/{userGuid}/members";
    private static final String DELETE_MEMBER_API = "/users/{userGuid}/members/{memberGuid}";
    private static final String READ_MEMBER_STATUS_API = "/users/{userGuid}/members/{memberGuid}/status";
    private static final String AGGREGATION_API = "/users/{userGuid}/members/{memberGuid}/aggregate";
    private static final String UPDATE_MEMBER_API = "/users/{userGuid}/members/{memberGuid}";
    private static final String DELETE_USER_API="/users/{userGuid}";
    private static final String RECORDS_PER_PAGE = "records_per_page";
    private static final int RECORDS_PER_PAGE_VALUE_MAX = 1000;
    private static final int RECORDS_PER_PAGE_VALUE = 100;
    private static final String PAGE = "page";
    private static final String FROM_DATE = "from_date";

    @Autowired
    @Qualifier("mxWebClient")
    private WebClient mxWebClient;

    /**
     * This method is used to make the call to accounts API of MX platform
     * @param userGuid
     * @return AccountResponse
     * @throws Exception
     */
    public ListAccountResponse listAccountsByUserGuid(String userGuid) throws Exception {
        return mxWebClient
                .get()
                .uri(uriBuilder -> uriBuilder.path(LIST_ACCOUNTS_BY_USER_API)
                        .queryParam(RECORDS_PER_PAGE, RECORDS_PER_PAGE_VALUE_MAX)
                        .build(userGuid))
                .retrieve()
                .bodyToMono(ListAccountResponse.class)
                .block();
    }

    /**
     * This method is used to make the call to transaction API of MX platform
     * @param userGuid
     * @param page
     * @param fromDate
     * @return TransactionResponse
     * @throws Exception
     */
    public ListTransactionResponse listTransactionsByUserGuid(String userGuid, int page, LocalDate fromDate) throws Exception {
        return mxWebClient
                .get()
                .uri(uriBuilder -> uriBuilder.path(LIST_TRANSACTIONS_BY_USER_API)
                        .queryParam(RECORDS_PER_PAGE, RECORDS_PER_PAGE_VALUE_MAX)
                        .queryParam(PAGE, page)
                        .queryParamIfPresent(FROM_DATE, Optional.ofNullable(fromDate))
                        .build(userGuid))
                .retrieve()
                .bodyToMono(ListTransactionResponse.class)
                .block();
    }

    public ListInstitutionResponse listInstitutions(int page) throws Exception{
        return mxWebClient
                .get()
                .uri(uriBuilder -> uriBuilder.path(LIST_INSTITUTIONS_API)
                        .queryParam(RECORDS_PER_PAGE, RECORDS_PER_PAGE_VALUE)
                        .queryParam(PAGE, page)
                        .build())
                .retrieve()
                .bodyToMono(ListInstitutionResponse.class)
                .block();
    }

    public ListInstitutionRequiredCredentialResponse listInstitutionCredentials(String institutionCode) throws Exception{
        return mxWebClient
                .get()
                .uri(uriBuilder -> uriBuilder.path(LIST_INSTITUTION_CREDENTIALS_API)
                        .build(institutionCode))
                .retrieve()
                .bodyToMono(ListInstitutionRequiredCredentialResponse.class)
                .block();
    }

    public MxUserRequestResponse createMxUser(MxUserRequestResponse mxUserRequestResponse) throws Exception{
        return mxWebClient
                .post()
                .uri(uriBuilder -> uriBuilder.path(CREATE_USER_API).build())
                .body(Mono.just(mxUserRequestResponse), MxUserRequestResponse.class)
                .retrieve()
                .bodyToMono(MxUserRequestResponse.class)
                .block();
    }

    public CreateMemberResponse createMember(CreateMemberRequest createMember, String userGuid) throws Exception{
       return mxWebClient
                .post()
                .uri(uriBuilder -> uriBuilder.path(CREATE_MEMBER_API).build(userGuid))
                .body(Mono.just(createMember), CreateMemberRequest.class)
                .retrieve()
                .bodyToMono(CreateMemberResponse.class)
                .block();
    }

    public CreateMemberResponse getMemberDetails(String userGuid, String memberGuid) throws Exception {
        return mxWebClient
                .get()
                .uri(uriBuilder -> uriBuilder.path(READ_MEMBER_DETAILS_API).build(userGuid,memberGuid))
                .retrieve()
                .bodyToMono(CreateMemberResponse.class)
                .block();
    }

    public MxUserRequestResponse fetchUserDetails(String userGuid) throws Exception {
        return mxWebClient
                .get()
                .uri(uriBuilder -> uriBuilder.path(READ_USER_DETAILS_API).build(userGuid))
                .retrieve()
                .bodyToMono(MxUserRequestResponse.class)
                .block();
    }

    public ListMemberResponse fetchMembersBasedOnUserGuid(String userGuid) throws Exception {
        return mxWebClient
                .get()
                .uri(uriBuilder -> uriBuilder.path(LIST_MEMBERS_BY_USER_API)
                        .queryParam(RECORDS_PER_PAGE, RECORDS_PER_PAGE_VALUE)
                        .build(userGuid))
                .retrieve()
                .bodyToMono(ListMemberResponse.class)
                .block();
    }

    public String deleteMember(String userGuid, String memberGuid) throws Exception {
        return mxWebClient
                .delete()
                .uri(uriBuilder -> uriBuilder.path(DELETE_MEMBER_API).build(userGuid, memberGuid))
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }

    public MemberStatusResponse readMemberStatus(String userGuid, String memberGuid) throws Exception {
        return mxWebClient
                .get()
                .uri(uriBuilder -> uriBuilder.path(READ_MEMBER_STATUS_API).build(userGuid, memberGuid))
                .retrieve()
                .bodyToMono(MemberStatusResponse.class)
                .block();
    }

    public CreateMemberResponse aggregateMember(String userGuid, String memberGuid) throws Exception{
        return mxWebClient
                .post()
                .uri(uriBuilder -> uriBuilder.path(AGGREGATION_API).build(userGuid, memberGuid))
                .retrieve()
                .bodyToMono(CreateMemberResponse.class)
                .block();
    }

    public CreateMemberResponse updateMember(String memberGuid, String userGuid, UpdateMemberRequest createMember) throws Exception{
        return mxWebClient
                .put()
                .uri(uriBuilder -> uriBuilder.path(UPDATE_MEMBER_API).build(userGuid,memberGuid))
                .body(Mono.just(createMember), CreateMemberRequest.class)
                .retrieve()
                .bodyToMono(CreateMemberResponse.class)
                .block();
    }

    public String deleteUser(String userGuid){
        return mxWebClient
                .delete()
                .uri(uriBuilder -> uriBuilder.path(DELETE_USER_API).build(userGuid))
                .retrieve()
                .bodyToMono(String.class)
                .block();
    }
}