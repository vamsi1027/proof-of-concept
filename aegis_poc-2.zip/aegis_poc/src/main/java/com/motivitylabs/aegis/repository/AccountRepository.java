package com.motivitylabs.aegis.repository;

import com.motivitylabs.aegis.dtos.FinancialInstitutionAnalytics;
import com.motivitylabs.aegis.entities.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Account Repository class used to connect to Account Table
 *
 * @Authors Vishal Kumar, RamaTeja
 */
@Repository
public interface AccountRepository extends JpaRepository<Account, String> {

    /**
     * This method returns the list of accounts based on userGuid
     * @param userGuid
     * @return List<Account>
     */
    List<Account> getByUserGuid(String userGuid);

    List<Account> findByMemberGuidAndUserGuid(String memberGuid,String userGuid);

    @Query("SELECT COUNT(a.accountGuid) FROM Account a")
    long getTotalAccountsCount();

    @Query("SELECT new com.motivitylabs.aegis.dtos.FinancialInstitutionAnalytics(a.institutionCode, COUNT(a.institutionCode)) "
            + "FROM Account a "
            + "GROUP BY a.institutionCode")
    List<FinancialInstitutionAnalytics> getAccountsCountByFI();
}