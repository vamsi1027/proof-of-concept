package com.motivitylabs.aegis.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransactionAnalyticsDto {

    private String category;
    private double amount;
}
