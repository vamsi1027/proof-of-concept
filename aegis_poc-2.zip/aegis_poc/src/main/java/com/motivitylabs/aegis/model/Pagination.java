package com.motivitylabs.aegis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Pagination {

    @JsonProperty(value = "current_page")
    private int currentPage;

    @JsonProperty(value = "per_page")
    private int recordsPerPage;

    @JsonProperty(value = "total_entries")
    private int totalEntries;

    @JsonProperty(value = "total_pages")
    private int totalPages;
}