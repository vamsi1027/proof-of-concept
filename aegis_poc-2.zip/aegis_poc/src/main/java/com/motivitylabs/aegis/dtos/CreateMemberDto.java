package com.motivitylabs.aegis.dtos;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateMemberDto {

    private String email;
    private String institutionCode;
    private String userName;
    private String password;
    private boolean oauth;
    private String redirectUri;
    private String memberGuid;
}
