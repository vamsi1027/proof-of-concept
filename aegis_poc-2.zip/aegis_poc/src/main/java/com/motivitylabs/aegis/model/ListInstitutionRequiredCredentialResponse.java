package com.motivitylabs.aegis.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ListInstitutionRequiredCredentialResponse {

    @JsonProperty("credentials")
    private List<InstitutionRequiredCredential> credentialsList;

    @JsonProperty("pagination")
    private Pagination pagination;
}