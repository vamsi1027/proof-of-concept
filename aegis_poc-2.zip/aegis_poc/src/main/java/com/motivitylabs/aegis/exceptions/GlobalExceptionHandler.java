package com.motivitylabs.aegis.exceptions;

import com.motivitylabs.aegis.dtos.ErrorResponseDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.reactive.function.client.WebClientException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Map;

/**
 * Global Exception Handler to handle the exceptions in entire application
 *
 * @Authors Vishal Kumar, RamaTeja
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @Value("#{${custom-http-status}}")
    private Map<String,String> statusMap;

    /**
     * Handles the exceptions related to WebClientExceptions class
     * @param exception
     * @return ResponseEntity<ErrorResponseDto>
     * @throws Exception
     */
    @ExceptionHandler(WebClientException.class)
    public ResponseEntity<ErrorResponseDto> handleResponseException(WebClientException exception) throws Exception {
        LOGGER.info(exception.getMessage());

        if (exception instanceof WebClientResponseException) {
            String errorResponseCode = String.valueOf(((WebClientResponseException) exception).getRawStatusCode());

            ErrorResponseDto errorResponseDto = new ErrorResponseDto();
            errorResponseDto.setStatusCode(errorResponseCode);

            if (statusMap.containsKey(errorResponseCode)) {
                errorResponseDto.setErrorMessage(statusMap.get(errorResponseCode));
            } else {
                errorResponseDto.setErrorMessage(statusMap.get("default"));
            }
            return new ResponseEntity<>(errorResponseDto, HttpStatus.valueOf(Integer.parseInt(errorResponseCode)));
        } else {
            return new ResponseEntity<>(new ErrorResponseDto("500", "Internal Server Error"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Handles the Generic Exceptions
     * @param exception
     * @return ResponseEntity<ErrorResponseDto>
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponseDto> handleResponseException(Exception exception) {
        LOGGER.info(exception.getMessage());
        return new ResponseEntity<>(new ErrorResponseDto("500", "Internal Server Error"), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}