package com.motivitylabs.aegis.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemberDto {

    private String institutionName;
    private LocalDateTime successfullyAggregatedAt;
    private String connectionStatus;
    private String userGuid;
    private String memberGuid;
}
