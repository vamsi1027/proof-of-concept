package com.motivitylabs.aegis.service;

import com.motivitylabs.aegis.configuration.AuthenticateUserDetails;
import com.motivitylabs.aegis.dtos.RegisterUserDto;
import com.motivitylabs.aegis.dtos.UserDto;
import com.motivitylabs.aegis.entities.Member;
import com.motivitylabs.aegis.entities.User;
import com.motivitylabs.aegis.enums.Roles;
import com.motivitylabs.aegis.model.ListMemberResponse;
import com.motivitylabs.aegis.model.MxMember;
import com.motivitylabs.aegis.model.MxUserRequestResponse;
import com.motivitylabs.aegis.repository.UserRepository;
import io.micrometer.core.instrument.util.StringUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * UserService class
 *
 * @Authors Vishal Kumar, RamaTeja
 */
@Service
public class UserService implements UserDetailsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);
    public static final String USER_ALREADY_REGISTERED = "User Already Registered";

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private MxApiService mxApiService;

    public List<UserDto> getListOfMLUsers() throws Exception {
        List<User> userList = userRepository.findAll();
        List<UserDto> userDtoList = new ArrayList<>();
        if (userList != null) {
            for (User user : userList) {
                if (!user.getRoles().contains(Roles.ADMIN.toString())) {
                    userDtoList.add(UserDto.convertToUserDto(user));
                }
            }
        }
        LOGGER.info("Successfully retrieved all users from DB");
        return userDtoList;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = findByEmailForFilter(email);
        if (user == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return new AuthenticateUserDetails(user);
    }

    public UserDto registerUser(RegisterUserDto registerUserDto) throws Exception {

        UserDto existingUser = findByEmail(registerUserDto.getEmail());

        if (existingUser != null) {
            throw new Exception(USER_ALREADY_REGISTERED);
        }

        User user = new User();
        user.setFirstName(registerUserDto.getFirstName());
        user.setLastName(registerUserDto.getLastName());
        user.setEmail(registerUserDto.getEmail());
        user.setRoles(Stream.of(Roles.USER.toString()).collect(Collectors.toSet()));
        user.setMobileNumber(registerUserDto.getMobileNumber());
        user.setAddress(registerUserDto.getAddress());
        user.setAggregator("MX");

        if (StringUtils.isEmpty(registerUserDto.getPassword())) {
            user.setOauth(true);
        } else {
            user.setPassword(passwordEncoder.encode(registerUserDto.getPassword()));
            user.setOauth(false);
        }

        User result = userRepository.save(user);
        return UserDto.convertToUserDto(result);
    }

    public UserDto findByEmail(String email) throws Exception {
        User result = userRepository.findByEmail(email);
        if (result != null) return UserDto.convertToUserDto(result);
        else return null;
    }

    public User findByEmailForFilter(String email) {
        return userRepository.findByEmail(email);
    }

    public UserDto fetchAndAddUserFromMx(String userGuid, String email) throws Exception {
        MxUserRequestResponse response = mxApiService.fetchUserDetails(userGuid);
        response.getMxUser().getUserGuid();
        ListMemberResponse listMemberResponse = mxApiService.fetchMembersBasedOnUserGuid(userGuid);
        Set<Member> members = new HashSet<>();
        for (MxMember mxMember : listMemberResponse.getMxMemberList()) {
            members.add(new ModelMapper().map(mxMember, Member.class));
        }
        User user = userRepository.findByEmail(email);
        user.setMembers(members);
        User result = userRepository.save(user);
        return UserDto.convertToUserDto(result);
    }
}