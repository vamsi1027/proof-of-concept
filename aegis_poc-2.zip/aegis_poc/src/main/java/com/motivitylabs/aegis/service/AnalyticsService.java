package com.motivitylabs.aegis.service;

import com.motivitylabs.aegis.dtos.AccountAnalyticsDto;
import com.motivitylabs.aegis.dtos.AccountDto;
import com.motivitylabs.aegis.dtos.TransactionAnalyticsDto;
import com.motivitylabs.aegis.entities.Account;
import com.motivitylabs.aegis.entities.Member;
import com.motivitylabs.aegis.repository.AccountRepository;
import com.motivitylabs.aegis.repository.MemberRepository;
import com.motivitylabs.aegis.repository.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class AnalyticsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AnalyticsService.class);
    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    public AccountAnalyticsDto accountsAnalytics(String email) throws Exception {
        LOGGER.info("Fetching account analytics data for email:{}", email);
        AccountAnalyticsDto accountAnalyticsDto = new AccountAnalyticsDto();
        List<AccountDto> accountDtoList = new ArrayList<>();
        String userGuid = findUserGuidByEmail(email);

        if (userGuid == null) {
            return null;
        }

        List<Account> accountList = accountRepository.getByUserGuid(userGuid);
        if (accountList == null || accountList.size() == 0) {
            return null;
        }
        double totalBalanceInAllAccounts = accountList.stream().mapToDouble(Account::getBalance).sum();
        int totalNoOfAccounts = accountList.size();
        accountAnalyticsDto.setTotalNoOfAccounts(totalNoOfAccounts);
        accountAnalyticsDto.setTotalBalanceInAllAccounts(totalBalanceInAllAccounts);
        for (Account a : accountList) {
            AccountDto accountDto = new AccountDto();
            accountDto.setAccountNumber(a.getAccountNumber());
            accountDto.setBalance(a.getBalance());
            accountDto.setAccountType(a.getAccountType());
            accountDto.setAccountName(a.getAccountName());
            accountDto.setAccountGuid(a.getAccountGuid());
            accountDtoList.add(accountDto);
        }

        accountAnalyticsDto.setAccountList(accountDtoList);
        return accountAnalyticsDto;
    }

    public List<TransactionAnalyticsDto> transactionAnalytics(String email, LocalDate fromDate, LocalDate toDate, String accountGuid) throws Exception {
        LOGGER.info("Fetching transaction analytics data for email:{}", email);
        TransactionAnalyticsDto transactionAnalyticsDto = new TransactionAnalyticsDto();

        if (fromDate == (null)) {
            fromDate = LocalDate.now().withDayOfMonth(1);
        }

        if (toDate == (null)) {
            toDate = LocalDate.now();
        }

        String userGuid = findUserGuidByEmail(email);
        List<TransactionAnalyticsDto> data = transactionRepository.getTransactionAnalytics(userGuid, fromDate, toDate, accountGuid);
        return data;
    }

    private String findUserGuidByEmail(String email) throws Exception {
        List<Member> memberList = memberRepository.findByMembersEmail(email);
        if (memberList.size() == 0) {
            return null;
        }
        return memberList.stream().findAny().get().getUserGuid();
    }
}
