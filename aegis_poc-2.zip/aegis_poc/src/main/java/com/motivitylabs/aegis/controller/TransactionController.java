package com.motivitylabs.aegis.controller;

import com.motivitylabs.aegis.dtos.ErrorResponseDto;
import com.motivitylabs.aegis.dtos.TransactionDto;
import com.motivitylabs.aegis.service.TransactionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransactionController.class);
    @Autowired
    private TransactionService transactionService;

    @Operation(
            summary = "Lists Transactions for User",
            description = "Returns List of Transactions of User"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @GetMapping("/user/{userGuid}")
    public ResponseEntity getListOfTransactions(@PathVariable("userGuid") String userGuid) throws Exception {
        LOGGER.info("Fetching transactions for a particular userGuid:{}", userGuid);
        return ResponseEntity.ok(transactionService.getListOfTransactions(userGuid));
    }

    @Operation(
            summary = "List of Transactions of a particular user and member",
            description = "Returns List of Transactions of a particular user and member"
    )
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Success"
                    ),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Internal Server Error",
                            content = @Content(schema = @Schema(implementation = ErrorResponseDto.class))
                    )
            })
    @GetMapping("/user/{userGuid}/member/{memberGuid}")
    public ResponseEntity<List<TransactionDto>> getTransactionsForMember(@PathVariable("userGuid") String userGuid, @PathVariable("memberGuid") String memberGuid) throws Exception {
        LOGGER.info("Fetching transactions for a particular memberGuid:{} of a userGuid:{}", memberGuid, userGuid);
        return ResponseEntity.ok(transactionService.getListOfTransactionsForUserAndMember(userGuid, memberGuid));
    }

    @GetMapping("/mx/user/{userGuid}")
    public ResponseEntity fetchTransactionsFromMx(@PathVariable("userGuid") String userGuid) throws Exception {
        return ResponseEntity.ok(transactionService.fetchTransactionsFromMx(userGuid));
    }
}
