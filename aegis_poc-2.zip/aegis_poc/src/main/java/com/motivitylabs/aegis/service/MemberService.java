package com.motivitylabs.aegis.service;

import com.motivitylabs.aegis.dtos.CreateMemberDto;
import com.motivitylabs.aegis.dtos.UserDto;
import com.motivitylabs.aegis.entities.Member;
import com.motivitylabs.aegis.entities.User;
import com.motivitylabs.aegis.model.*;
import com.motivitylabs.aegis.repository.MemberRepository;
import com.motivitylabs.aegis.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
public class MemberService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MemberService.class);
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MxApiService mxApiService;

    @Autowired
    private InstitutionService institutionService;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private MemberStatusService memberStatusService;

    public UserDto createMemberWithCredentials(CreateMemberDto createMemberDto) throws Exception {
        //fetching user from database
        User user = userRepository.findByEmail(createMemberDto.getEmail());

        //fetching the userGuid if exists else we will create a new user in mx and return userGuid
        String userGuid = getUserGuid(createMemberDto.getEmail(), user.getMembers());

        CreateMemberRequest createMember = new CreateMemberRequest();

        //fetch credentials which is accepted by institution i.e. username guid and password guid
        List<InstitutionRequiredCredential> institutionRequiredCredentials = institutionService.getInstitutionCredentials(createMemberDto.getInstitutionCode());

        //mapping the credentials
        List<InstitutionProvidedCredential> institutionProvidedCredentials = setInstitutionRequiredCredentials(createMemberDto);

        createMember.setMember(createMember.new MemberRequest(institutionProvidedCredentials, createMemberDto.getInstitutionCode(), false));

        //creating member
        CreateMemberResponse createMemberResponse = mxApiService.createMember(createMember, userGuid);

        //save in database
        MxMember mxMember = createMemberResponse.getMember();
        Member member = new ModelMapper().map(mxMember, Member.class);
        user.getMembers().add(member);
        User result = userRepository.save(user);

        //Async operation check member status and update accounts and transactions in DB
        memberStatusService.checkMemberStatus(mxMember.getUserGuid(), mxMember.getMemberGuid());

        return UserDto.convertToUserDto(result);
    }

    public String createMemberWithOauth(CreateMemberDto createMemberDto) throws Exception {
        //fetching user from database
        User user = userRepository.findByEmail(createMemberDto.getEmail());

        //fetching the userGuid if exists else we will create a new user in mx and return userGuid
        String userGuid = getUserGuid(createMemberDto.getEmail(), user.getMembers());

        CreateMemberRequest createMember = new CreateMemberRequest();

        createMember.setMember(createMember.new MemberRequest(null, createMemberDto.getInstitutionCode(), true));
        createMember.setReferralSource("APP");
        createMember.setRedirectUri(createMemberDto.getRedirectUri());
        CreateMemberResponse createMemberResponse = mxApiService.createMember(createMember, userGuid);

        MxMember mxMember = createMemberResponse.getMember();
        Member member = new ModelMapper().map(mxMember, Member.class);
        user.getMembers().add(member);
        userRepository.save(user);

        return createMemberResponse.getMember().getOAuthWindowUri();
    }

    public UserDto updateOauthMemberToDataBase(String memberGuid, String email) throws Exception {
        Member member = memberRepository.getById(memberGuid);
        CreateMemberResponse memberResponse = mxApiService.getMemberDetails(member.getUserGuid(), member.getMemberGuid());
        MxMember mxMember = memberResponse.getMember();
        member = new ModelMapper().map(mxMember, Member.class);
        member.setMembersEmail(email);
        memberRepository.save(member);

        //Async operation check member status and update accounts and transactions in DB
        memberStatusService.checkMemberStatus(mxMember.getUserGuid(), mxMember.getMemberGuid());

        User result = userRepository.getById(email);
        return UserDto.convertToUserDto(result);
    }

    private String getUserGuid(String email, Set<Member> memberSet) throws Exception {
        String userGuid;
        if (memberSet.size() > 0) {
            userGuid = memberSet.stream().findFirst().get().getUserGuid();
        } else {
            MxUser mxUser = new MxUser();
            mxUser.setEmail(email);
            MxUserRequestResponse response = mxApiService.createMxUser(new MxUserRequestResponse(mxUser));
            userGuid = response.getMxUser().getUserGuid();
        }
        return userGuid;
    }

    public void removeMember(String memberGuid) throws Exception {
        Member member = memberRepository.getById(memberGuid);
        mxApiService.deleteMember(member.getUserGuid(), member.getMemberGuid());

        memberRepository.delete(member);

        if (memberRepository.findByUserGuid(member.getUserGuid()).size() == 0) {
            mxApiService.deleteUser(member.getUserGuid());
        }
    }

    public String triggerAggregation(String userGuid, String memberGuid) throws Exception {
        LOGGER.info("Triggering aggregation for userGuid: {} and memberGuid: {}", userGuid, memberGuid);
        memberStatusService.triggerAggregationInAsync(userGuid, memberGuid);
        return "Aggregation is triggered successfully";
    }



    @Transactional
    public Member updateMemberStatusInDB(MemberStatusResponse memberStatusResponse) throws Exception {
        LOGGER.info("Updating member details in DB");
        Member member = memberRepository.getById(memberStatusResponse.getMemberStatus().getMemberGuid());
        member.setAggregatedAt(memberStatusResponse.getMemberStatus().getAggregatedAt());
        member.setBeingAggregated(memberStatusResponse.getMemberStatus().isBeingAggregated());
        member.setSuccessfullyAggregatedAt(memberStatusResponse.getMemberStatus().getSuccessfullyAggregatedAt());
        member.setConnectionStatus(memberStatusResponse.getMemberStatus().getConnectionStatus());

        return memberRepository.save(member);
    }

    private List<InstitutionProvidedCredential> setInstitutionRequiredCredentials(CreateMemberDto createMemberDto) throws Exception {
        //fetch credentials which is accepted by institution i.e. username guid and password guid
        List<InstitutionRequiredCredential> institutionRequiredCredentials = institutionService.getInstitutionCredentials(createMemberDto.getInstitutionCode());
        List<InstitutionProvidedCredential> institutionProvidedCredentials = new ArrayList<>();

        //mapping the credentials
        for (InstitutionRequiredCredential requiredCredential : institutionRequiredCredentials) {
            if (requiredCredential.getDisplayOrder() == 1) {
                institutionProvidedCredentials.add(new InstitutionProvidedCredential(requiredCredential.getGuid(), createMemberDto.getUserName()));
            } else if (requiredCredential.getDisplayOrder() == 2) {
                institutionProvidedCredentials.add(new InstitutionProvidedCredential(requiredCredential.getGuid(), createMemberDto.getPassword()));
            }
        }
        return institutionProvidedCredentials;
    }

    public UserDto updateMemberCredentials(CreateMemberDto createMemberDto) throws Exception {
        User user = userRepository.findByEmail(createMemberDto.getEmail());
        //fetching the userGuid if exists else we will create a new user in mx and return userGuid
        String userGuid = getUserGuid(createMemberDto.getEmail(), user.getMembers());
        UpdateMemberRequest updateMember = new UpdateMemberRequest();

        List<InstitutionProvidedCredential> institutionProvidedCredentials = setInstitutionRequiredCredentials(createMemberDto);
        UpdateMemberRequest.MemberRequest memberRequest = updateMember.new MemberRequest(institutionProvidedCredentials);
        updateMember.setMember(memberRequest);

        CreateMemberResponse updateMemberResponse = mxApiService.updateMember(createMemberDto.getMemberGuid(), userGuid, updateMember);
        Member member = memberRepository.findById(createMemberDto.getMemberGuid()).get();
        member = new ModelMapper().map(updateMemberResponse.getMember(), Member.class);
        member.setMembersEmail(createMemberDto.getEmail());
        memberRepository.save(member);
        User result = userRepository.findByEmail(createMemberDto.getEmail());
        return UserDto.convertToUserDto(result);
    }
}