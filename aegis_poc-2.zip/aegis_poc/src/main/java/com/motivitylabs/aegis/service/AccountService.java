package com.motivitylabs.aegis.service;

import com.motivitylabs.aegis.dtos.AccountDto;
import com.motivitylabs.aegis.entities.Account;
import com.motivitylabs.aegis.model.ListAccountResponse;
import com.motivitylabs.aegis.repository.AccountRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * AccountService class
 *
 * @Authors Vishal Kumar, RamaTeja
 */
@Service
public class AccountService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AccountService.class);

    @Autowired
    private MxApiService mxApiService;

    @Autowired
    private AccountRepository accountRepository;

    /**
     * This method fetches the accounts from MX API for particular userGuid and
     * stores it in Database and returns the list of AccountDto.
     *
     * @param userGuid
     * @return List<AccountDto>
     * @throws Exception
     */
    public String fetchAccountsFromMx(String userGuid) throws Exception {
        ListAccountResponse accountResponse = null;
        try {
            accountResponse = mxApiService.listAccountsByUserGuid(userGuid);
            LOGGER.info("Response Received From MX Accounts API for userGuid: {} ", userGuid);
        } catch (Exception e) {
            LOGGER.error("Exception MX Accounts API for userGuid: {} message: {}", userGuid, e.getMessage());
            throw e;
        }

        List<Account> result = null;
        if (! accountResponse.getAccountList().isEmpty()) {
            LOGGER.info("Saving Accounts in DB for userGuid: {}", userGuid);
            result = accountRepository.saveAll(accountResponse.getAccountList());
            LOGGER.info("Successfully Saved Accounts in DB for userGuid: {}", userGuid);
        }

        if (result != null) return "success";
        else return "failed";
    }

    public List<AccountDto> getListOfAccounts(String userGuid) {

        LOGGER.info("Fetching Accounts from DB for userGuid: {}", userGuid);
        List<Account> accountList = accountRepository.getByUserGuid(userGuid);

        ModelMapper mapper = new ModelMapper();
        List<AccountDto> accounts = new ArrayList<>();
        for (Account account : accountList) {
            AccountDto accountDto = mapper.map(account, AccountDto.class);
            accounts.add(accountDto);
        }
        LOGGER.info("Successfully Fetched Accounts from DB for userGuid: {}", userGuid);
        return accounts;
    }

    public List<AccountDto> getListOfAccountsForMember(String userGuid, String memberGuid) {
        LOGGER.info("Successfully Fetched Accounts from DB for userGuid: {} and memberGuid:{}", userGuid, memberGuid);
        List<Account> accountList = accountRepository.findByMemberGuidAndUserGuid(memberGuid, userGuid);
        ModelMapper mapper = new ModelMapper();
        List<AccountDto> accounts = new ArrayList<>();
        for (Account account : accountList) {
            AccountDto accountDto = mapper.map(account, AccountDto.class);
            accounts.add(accountDto);
        }
        LOGGER.info("Successfully Fetched Accounts from DB for userGuid: {} and memberGuid:{}", userGuid, memberGuid);
        return accounts;
    }
}
