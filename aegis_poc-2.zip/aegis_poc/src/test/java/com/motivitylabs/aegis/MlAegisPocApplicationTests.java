package com.motivitylabs.aegis;

import com.motivitylabs.aegis.entities.User;
import com.motivitylabs.aegis.enums.Roles;
import com.motivitylabs.aegis.model.ListInstitutionResponse;
import com.motivitylabs.aegis.repository.UserRepository;
import com.motivitylabs.aegis.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Test Cases for MlAegisPocApplication
 *
 * @Authors Vishal Kumar, RamaTeja
 */
@SpringBootTest
class MlAegisPocApplicationTests {

    private static final String LIST_INSTITUTIONS_API = "/institutions";

    @Autowired
    @Qualifier("mxWebClient")
    private WebClient mxWebClient;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webApplicationContext;

    public void setMockMvc() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).apply(springSecurity()).build();
    }

    @Test
    @WithMockUser(username = "admin", password = "admin", roles = {"ADMIN"})
    public void testUserController() throws Exception {
        setMockMvc();
        MvcResult mvc = mockMvc.perform(get("/admin/users").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andReturn();

        assertEquals(200, mvc.getResponse().getStatus());
    }

    @Test
    public void testMxApi() {
        ListInstitutionResponse listInstitutionResponse = mxWebClient
                .get()
                .uri(uriBuilder -> uriBuilder.path(LIST_INSTITUTIONS_API).build())
                .retrieve()
                .bodyToMono(ListInstitutionResponse.class)
                .block();

        assertNotNull(listInstitutionResponse);
        assertTrue(listInstitutionResponse.getInstitutionsList().size() > 0);
    }

    @Test
    public void testFindByEmail() throws Exception {
        User user = new User("joe@gmail.com", "joe", "joe", "joe", false, "9876543210", "Hyderabad", Roles.USER.toString(), "MX",null,null, Collections.emptySet());
        when(userRepository.findByEmail("joe@gmail.com")).thenReturn(user);

        assertNotNull(userRepository.findByEmail("joe@gmail.com"));
        assertEquals(userRepository.findByEmail("joe@gmail.com"), user);
    }
}