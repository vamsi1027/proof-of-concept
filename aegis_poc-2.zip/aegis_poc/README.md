# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

### This Repository is intended for POC Implementation for Aegis LLC customer for their MX Aggregator integration.

* About Aegis LLC :- exists to solve the critical issues facing their clients, both large and small.

* Challenge:- Currently, the existing solution requires the user to manually enter the data that limits the adoption of various features in the solution.

* Objective/Solution:- Query MX platform based on the user, get the data and populate the results into Data Layer. Build the solution on Microsoft Azure Cloud Platform.

* Scope:-  
	Build Simple API, that takes the User Id using HTTP GET REST and return the aggregation results of the user in a JSON format.
	Build a simple UI using React JS that will call REST API to get the aggregation results display them in a grid. The UI shall also enable social login/FBA. 
	API will be built using Spring boot architecture with resilient Data access layer which stores the transactional information of the user to the PostgreSQL database through an ORM framework, Hibernate.
	Leverage the Azure app services and Azure SQL for PostgreSQL Single Server for deployment.



### Mx Aggregator Definitions ###

#### The MX Platform API provides a wide range of features that allow banks, fintechs, and other financial institutions to give end users an exceptional experience. Below are few entities that are associated with MX aggregator platform ####

* Development Url for Mx Platform : Https://int-api.mx.com/
* Production url : https://api.mx.com/
* Institutions: Institution is nothing but a financial institution like wells fargo, chase etc..
* User: User represents a person using mx via his own application, be it mobile, Web app and desktop applications as well.
* Member: Member represents the relationship between user and an institution. User will be having a member for each Institution.
* Connected: The first step is to check the member's connection_status to determine whether aggregation is either necessary or possible. Each status indicates something different; some connection statuses mean that an aggregation will fail if attempted or that an aggregation is already in progress.
	Examples of Connected statuses are : CREATED,CONNECTED,DEGRADED,DISCONNECTED,EXPIRED,FAILED,IMPEDED,RECONNECTED,UPDATED.
* Account: Account represents the financial account that belongs to a financial Institution.( Banks )
* Transaction: A transaction represents any instance in which money moves into or out of an account, 
	such as a purchase at a business, a payroll deposit, a transfer from one account to another, 
	an ATM withdrawal, etc. Each transaction belongs to only one account.
* Webhooks: MX provides webhooks that send HTTPS POST callback requests to the URL of your choice. This enables you to subscribe to certain events, be notified when those events occur, and have information related to that event delivered to you. 

### Proposed architecture ###



### POC Duration ###

* Development & QA : 2 Weeks
* Deployment :  4 days
* Demo & Feedback : 1 day
* Sign off on POC completion: 1 day.

### Assumptions: ###

* Access to Azure Subscription.
* Elevated access to provision Azure Resource Groups, VNET, App Services, PostgreSQL.
* Touchpoint calls during PoC with the customer to address any info blockers.
* Any further enhancements post PoC will be considered through paid engagement model.

